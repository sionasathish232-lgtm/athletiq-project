# ⚡ TitanFit - Hypertrophy & Gamified Fitness Web App

TitanFit is a full-stack, responsive fitness web application engineered to help athletes build muscular physique through gamified challenges, live competitive leaderboards, remaining-workout metrics, 9:16 Instagram Story milestone generation, and science-backed progressive overload tools.

---

## 🚀 Quick Start & How to Run

### Option 1: 1-Click Launch (Windows)
Double-click `run.bat` in the project folder:
```cmd
run.bat
```

### Option 2: Command Line
```powershell
cd C:\Users\AKSHAY\.gemini\antigravity\scratch\titan-fitness
python app.py
```
Open your browser and navigate to:
👉 **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

---

## 🔑 Pre-Seeded Test Accounts

The app is pre-populated with ready-to-test rivals so you can test all features right away without typing:

| Role | Username | Email | Password | Rank | Division | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Demo User** | `Alex_Forge` | `alex@titan.fit` | `titan123` | **#4** | Platinum (3,450 XP) | Main test profile with active routine & past workouts |
| **Rival #1 (Ahead)**| `Sarah_Lift` | `sarah@titan.fit` | `titan123` | **#3** | Platinum (3,610 XP) | Only 160 XP ahead of Alex! |
| **Rival #2 (Ahead)**| `Marcus_Beast`| `marcus@titan.fit`| `titan123` | **#2** | Platinum (3,780 XP) | 330 XP ahead |
| **Leader** | `Viktor_Iron` | `viktor@titan.fit` | `titan123` | **#1** | Diamond (4,320 XP) | Current global champion |

> 💡 **Quick 1-Click Login:** Click the profile icon in the top right to open the Auth modal and click **"Alex Forge (Rank #4)"**, **"Viktor (Rank #1)"**, or **"Marcus (Rank #2)"** for instant switching between profiles!

---

## 📋 Features Overview

1. **User Authentication & Recovery (`/api/auth`)**:
   - Register new accounts with custom fitness goals, experience levels, and starting weights.
   - Login with session persistence and secure SHA-256 salted password hashing.
   - Forgot Password workflow with security question recovery.
   - 1-click Demo Login for fast testing.

2. **Workout Logbook & Achievements**:
   - Completed workout history detailing date, category, duration, total volume (kg), sets, and PR notes.
   - Unlocked milestone badges: *First Blood*, *Century Club*, *Iron Titan Streak*, *Podium Contender*, etc.

3. **"How Much Workout Remains" Engine**:
   - Interactive SVG circular progress gauge showing percentage of today's target completed.
   - Real-time metric pills: **Remaining Sets**, **Sets Done**, and **Volume Remaining (kg)**.
   - **Interactive Live Session Tracker**: Tap any set in today's active routine to mark it completed. It immediately updates remaining work, logs volume, awards +25 XP, and syncs with the server.

4. **Leaderboard & Competitive Rivalry Gap Analysis**:
   - Top 3 Visual Podium (Gold, Silver, Bronze) with animated tier crowns.
   - Dynamic Rival Alert: Explicitly shows the user directly ahead of you (e.g. *"Target to Beat: @Sarah_Lift — 160 XP ahead (1 workout away to overtake!)"*).
   - Global roster showing XP, streaks, total volume, and tier divisions (*Diamond*, *Platinum*, *Gold*, *Silver*, *Bronze*).

5. **9:16 Instagram Story Milestone Generator**:
   - In-app canvas studio rendering high-definition 1080×1920 vertical posters.
   - Customizable color palettes: *Emerald Titan*, *Cyber Cyan*, *Crimson Fury*, and *Golden Champion*.
   - Preset milestone types: *New Personal Record (PR)*, *Iron Discipline Streak*, *Leaderboard Promotion*, and *Massive Volume Crush*.
   - 1-Click **"Download Story (PNG)"** and **"Copy Caption"** buttons.

6. **Punchy Motivational Micro-Cues (4–6 Words)**:
   - Dynamic motivational mantras placed in the header, workout cards, and story exporter:
     - *"Pain today, strength tomorrow."*
     - *"Earn your body every day."*
     - *"Discipline outlasts motivation every time."*
     - *"Heavy weights build unbreakable iron."*
     - *"One more rep changes everything."*
     - *"Champions are forged in sweat."*
   - Tap the top flame pill to cycle through quotes on demand.

7. **"Develop Faster" Hypertrophy & Science Hub**:
   - **Progressive Overload Calculator**: Calculates next session's target load and reps using the Epley 1RM equation and Reps In Reserve (RIR).
   - **Protein & Calorie Calculator**: Optimized daily protein (1.8–2.4 g/kg), per-meal leucine threshold (~3g) for maximal mTOR stimulation, and caloric targets.
   - **The 4 Hypertrophy Pillars**: Stretch-mediated tension, volume landmarks, rest intervals, and deep sleep protocols.

---

## 🛠️ How to Modify Features or Add New Pages Later

TitanFit is designed to be clean, modular, and easy to extend:

### 1. How to Add a New Page / Tab
1. **Add the HTML Section**:
   In `templates/index.html`, add a new navigation button in `<nav class="main-nav-tabs">`:
   ```html
   <button class="nav-tab-btn" data-tab="nutrition">
     <span>🥗</span> Nutrition Meal Planner
   </button>
   ```
   Then create the matching tab view section below:
   ```html
   <section class="tab-view" id="nutritionView" style="display: none;">
     <h2>My Custom Nutrition Plan</h2>
     <!-- Your UI components here -->
   </section>
   ```
2. **Tab Switching**:
   The tab router in `static/js/app.js` automatically activates any view matching `${tabName}View` when a button with `data-tab="name"` is clicked. No extra routing code needed!

### 2. How to Add a New Backend REST API Endpoint
In `app.py`, define a new route:
```python
@app.route('/api/custom-endpoint', methods=['GET', 'POST'])
def custom_endpoint():
    conn = get_db()
    user = get_current_user(conn)
    # Perform database query or calculation
    conn.close()
    return jsonify({"success": True, "data": "Your result here"})
```

### 3. How to Add a New Database Table or Column
In `database.py`:
1. Add the column or table definition inside `init_db()` in `cursor.executescript(...)`.
2. For example, to track daily water intake:
   ```sql
   CREATE TABLE IF NOT EXISTS water_logs (
       id INTEGER PRIMARY KEY AUTOINCREMENT,
       user_id INTEGER NOT NULL,
       date TEXT NOT NULL,
       milliliters INTEGER DEFAULT 0,
       FOREIGN KEY (user_id) REFERENCES users(id)
   );
   ```
3. Run `python database.py` to apply the changes.

### 4. How to Add New Exercises or Challenges
In `database.py`, expand the `challenges` or `today_routine` arrays in the `seed_data()` function:
```python
("New Challenge Name", "Description here", "Category", 500, "reps", 400, "Badge Name", "🏋️", "Medium", 14)
```

---

## 📁 File Structure

```
titan-fitness/
├── app.py                   # Flask REST server, route handlers, session auth
├── database.py              # SQLite schema, tables, hashing, and sample seed data
├── requirements.txt         # Dependencies (Flask >= 3.0.0)
├── run.bat                  # 1-click Windows runner
├── test_app.py              # Automated test suite (8 tests, 100% pass)
├── README.md                # Documentation and extension guide
├── static/
│   ├── css/
│   │   └── style.css        # Dark obsidian & electric neon athletic theme
│   ├── js/
│   │   ├── api.js           # API fetch client
│   │   ├── auth.js          # Authentication and session manager
│   │   ├── story_card.js    # 9:16 Instagram Story HTML5 Canvas generator
│   │   ├── develop.js       # Hypertrophy overload & macro calculators
│   │   └── app.js           # Main UI controller, live set logger, and tabs
│   └── favicon.svg          # Dumbbell icon
└── templates/
    └── index.html           # Single Page Application HTML interface
```
