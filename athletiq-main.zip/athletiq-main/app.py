"""
app.py - Main Flask Application and REST API backend for AthletiQ.
"TRACK. IMPROVE. CONQUER."
"""
import os
import json
import math
from datetime import datetime
from flask import Flask, request, jsonify, render_template, session, send_from_directory
from database import get_db, init_db, hash_password

# Gemini AI via direct HTTP — more reliable on Vercel serverless than SDK
import requests as _requests

def _call_gemini(prompt: str) -> str:
    """Call Gemini via REST — uses correct current model names."""
    key = os.environ.get('GEMINI_API_KEY', '').strip()
    if not key:
        return None

    models = [
        "gemini-3.6-flash",
        "gemini-2.5-flash",
        "gemini-2.0-flash-exp",
        "gemini-1.5-flash-002",
    ]
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"maxOutputTokens": 2048, "temperature": 0.85}
    }
    for model in models:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
        try:
            r = _requests.post(url, json=payload, timeout=15)
            if r.status_code == 200:
                return r.json()['candidates'][0]['content']['parts'][0]['text'].strip()
        except Exception:
            continue
    return None


app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = "athletiq_conquer_secret_key_2026"


@app.route('/static/<path:filename>')
def serve_static(filename):
    """Explicit static file handler - required for Vercel serverless deployment."""
    return send_from_directory(app.static_folder, filename)

MOTIVATIONAL_QUOTES = [
    "Track. Improve. Conquer every day.",
    "Pain today, strength tomorrow.",
    "Earn your body every day.",
    "Discipline outlasts motivation every time.",
    "Heavy weights build unbreakable iron.",
    "Doubt kills more than failure.",
    "One more rep changes everything.",
    "Champions are forged in sweat.",
    "Excuses don't build muscular armor.",
    "Small daily wins compound massively.",
    "Conquer the mind, conquer iron.",
    "Sweat is weakness leaving muscle."
]

def get_current_user(conn):
    """Retrieve current logged in user from session. Returns None if unauthenticated."""
    user_id = session.get('user_id')
    if user_id:
        user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if user:
            return dict(user)
    return None

def recalculate_division(xp: int) -> str:
    """Calculate tier division from XP."""
    if xp >= 4000:
        return "Diamond"
    elif xp >= 3000:
        return "Platinum"
    elif xp >= 2000:
        return "Gold"
    elif xp >= 1000:
        return "Silver"
    return "Bronze"

# ----------------- AUTHENTICATION ROUTES ----------------- #

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    username    = data.get('username', '').strip()
    full_name   = data.get('full_name', username).strip()
    password    = data.get('password', '').strip()
    email       = data.get('email', f"{username.lower()}@athletiq.fit").strip().lower()
    fitness_goal     = data.get('fitness_goal', 'build_muscle').strip()
    experience_level = data.get('experience_level', 'Intermediate').strip()
    weight_kg        = float(data.get('weight_kg', 70.0))
    security_answer  = data.get('security_answer', 'athletiq').strip().lower()

    if not username or not password:
        return jsonify({"success": False, "error": "Username and password are required."}), 400

    conn = get_db()
    existing = conn.execute("SELECT id FROM users WHERE username = ? OR email = ?", (username, email)).fetchone()
    if existing:
        conn.close()
        return jsonify({"success": False, "error": "Username already taken. Try another one."}), 400

    hashed       = hash_password(password)
    avatar_color = "#ef233c"

    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO users (username, email, password_hash, security_answer, fitness_goal, experience_level, weight_kg, xp, current_streak, division, avatar_color)
        VALUES (?, ?, ?, ?, ?, ?, ?, 100, 1, 'Bronze', ?)
    """, (username, email, hashed, security_answer, fitness_goal, experience_level, weight_kg, avatar_color))
    new_id = cursor.lastrowid

    # Create initial today's goal for new user
    today_str = datetime.now().strftime("%Y-%m-%d")
    default_routine = [
        {"id": "ex_1", "name": "Push-Ups (Activation)", "target_sets": 3, "muscle": "Chest", "sets": [{"set_num": 1, "reps": 15, "weight_kg": 0, "completed": False}, {"set_num": 2, "reps": 15, "weight_kg": 0, "completed": False}, {"set_num": 3, "reps": 15, "weight_kg": 0, "completed": False}]},
        {"id": "ex_2", "name": "Dumbbell Bench Press", "target_sets": 4, "muscle": "Chest", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 20, "completed": False}, {"set_num": 2, "reps": 10, "weight_kg": 20, "completed": False}, {"set_num": 3, "reps": 8, "weight_kg": 22, "completed": False}, {"set_num": 4, "reps": 8, "weight_kg": 22, "completed": False}]},
        {"id": "ex_3", "name": "Standing Overhead Press", "target_sets": 3, "muscle": "Shoulders", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 30, "completed": False}, {"set_num": 2, "reps": 10, "weight_kg": 30, "completed": False}, {"set_num": 3, "reps": 8, "weight_kg": 35, "completed": False}]}
    ]
    cursor.execute("""
        INSERT INTO daily_goals (user_id, date, target_sets, completed_sets, target_volume_kg, completed_volume_kg, target_duration_min, completed_duration_min, active_split_title, active_split_category, routine_json)
        VALUES (?, ?, 10, 0, 3000, 0, 45, 0, 'Starter Power Push Routine', 'Chest & Shoulders', ?)
    """, (new_id, today_str, json.dumps(default_routine)))

    # Auto join first challenge
    first_chal = conn.execute("SELECT id FROM challenges ORDER BY id LIMIT 1").fetchone()
    if first_chal:
        cursor.execute("INSERT OR IGNORE INTO user_challenges (user_id, challenge_id, progress) VALUES (?, ?, 0)", (new_id, first_chal['id']))

    conn.commit()
    conn.close()

    session['user_id'] = new_id
    return jsonify({
        "success": True,
        "message": f"Welcome to AthletiQ, {username}! Track. Improve. Conquer.",
        "user": {"id": new_id, "username": username, "email": email, "xp": 100, "division": "Bronze",
                 "current_streak": 1, "avatar_color": avatar_color, "onboarding_complete": False}
    })



@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    identifier = data.get('identifier', '').strip()
    password = data.get('password', '').strip()

    if not identifier or not password:
        return jsonify({"success": False, "error": "Email/Username and password required."}), 400

    conn = get_db()
    user = conn.execute("""
        SELECT * FROM users WHERE LOWER(email) = LOWER(?) OR LOWER(username) = LOWER(?)
    """, (identifier, identifier)).fetchone()

    if not user or user['password_hash'] != hash_password(password):
        conn.close()
        return jsonify({"success": False, "error": "Invalid email/username or password."}), 401

    session['user_id'] = user['id']
    user_dict = dict(user)
    del user_dict['password_hash']
    conn.close()

    return jsonify({
        "success": True,
        "message": f"Welcome back, {user['username']}!",
        "user": user_dict
    })

@app.route('/api/auth/demo-login', methods=['POST'])
def demo_login():
    """1-click login for test drive as Alex_Forge or chosen user."""
    data = request.get_json() or {}
    username = data.get('username', 'Alex_Forge').strip()
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    if not user:
        user = conn.execute("SELECT * FROM users ORDER BY id ASC LIMIT 1").fetchone()

    session['user_id'] = user['id']
    user_dict = dict(user)
    del user_dict['password_hash']
    conn.close()
    return jsonify({"success": True, "message": f"Logged in as demo user {user_dict['username']}", "user": user_dict})

@app.route('/api/auth/forgot-password', methods=['POST'])
def forgot_password():
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    new_password = data.get('new_password', '').strip()
    security_answer = data.get('security_answer', '').strip().lower()

    if not email or not new_password:
        return jsonify({"success": False, "error": "Email and new password are required."}), 400

    conn = get_db()
    user = conn.execute("SELECT id, security_answer FROM users WHERE LOWER(email) = ?", (email,)).fetchone()
    if not user:
        conn.close()
        return jsonify({"success": False, "error": "No account found with this email."}), 404

    if security_answer and user['security_answer'] and security_answer != user['security_answer']:
        conn.close()
        return jsonify({"success": False, "error": "Security verification answer does not match."}), 400

    conn.execute("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password(new_password), user['id']))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Password successfully reset! You can now log in."})

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({"success": True, "message": "Logged out successfully."})

@app.route('/api/auth/onboarding', methods=['POST'])
def save_onboarding():
    """Save multi-step onboarding wizard data for the current user."""
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    data = request.get_json() or {}

    # Map goal values to display strings
    goal_map = {
        'lose_weight':     'Lose Weight',
        'build_muscle':    'Build Muscle (Hypertrophy)',
        'stay_fit':        'Stay Fit & Active',
        'maintain_weight': 'Maintain Weight'
    }
    freq_map = {
        'beginner':  'Beginner (1-2x/week)',
        'regular':   'Regular (3-4x/week)',
        'dedicated': 'Dedicated (5-6x/week)',
        'elite':     'Elite (Daily)'
    }

    fitness_goal = goal_map.get(data.get('goal', ''), data.get('goal', 'Build Muscle (Hypertrophy)'))
    experience_level = freq_map.get(data.get('workout_frequency', ''), 'Intermediate')

    updates = {
        'fitness_goal':       fitness_goal,
        'experience_level':   experience_level,
        'weight_kg':          float(data.get('weight_kg', user.get('weight_kg', 70))),
    }

    # Build SET clause dynamically for extra columns (safe columns only)
    safe_extra = {
        'gender':              data.get('gender'),
        'age':                 data.get('age'),
        'height_cm':           data.get('height_cm'),
        'goal_weight_kg':      data.get('goal_weight_kg'),
        'current_body_shape':  data.get('current_body_shape'),
        'goal_body_shape':     data.get('goal_body_shape'),
        'workout_frequency':   data.get('workout_frequency'),
        'lifestyle_role':      data.get('lifestyle_role'),
        'onboarding_complete': 1
    }

    try:
        # First update always-present columns
        conn.execute("""
            UPDATE users SET fitness_goal=?, experience_level=?, weight_kg=? WHERE id=?
        """, (updates['fitness_goal'], updates['experience_level'], updates['weight_kg'], user['id']))

        # Try to update extended columns — they may not exist on older DB
        for col, val in safe_extra.items():
            if val is not None:
                try:
                    conn.execute(f"UPDATE users SET {col}=? WHERE id=?", (val, user['id']))
                except Exception:
                    pass  # Column doesn't exist yet — safe to ignore

        conn.commit()
    except Exception as e:
        conn.close()
        return jsonify({"success": False, "error": str(e)}), 500

    conn.close()
    return jsonify({"success": True, "message": "Profile setup complete! Time to conquer."})



@app.route('/api/auth/me', methods=['GET'])
def get_me():
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"authenticated": False}), 200

    del user['password_hash']
    rank = conn.execute("SELECT COUNT(*) + 1 FROM users WHERE xp > ?", (user['xp'],)).fetchone()[0]
    user['rank'] = rank
    conn.close()
    return jsonify({"authenticated": True, "user": user})

# ----------------- DASHBOARD & WORKOUT ROUTES ----------------- #

@app.route('/api/dashboard', methods=['GET'])
def get_dashboard():
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 401

    today_str = datetime.now().strftime("%Y-%m-%d")

    daily = conn.execute("SELECT * FROM daily_goals WHERE user_id = ? AND date = ?", (user['id'], today_str)).fetchone()
    if not daily:
        routine = [
            {"id": "ex_1", "name": "Barbell Bench Press", "target_sets": 4, "muscle": "Chest", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 75, "completed": False}, {"set_num": 2, "reps": 8, "weight_kg": 80, "completed": False}, {"set_num": 3, "reps": 8, "weight_kg": 80, "completed": False}, {"set_num": 4, "reps": 6, "weight_kg": 85, "completed": False}]},
            {"id": "ex_2", "name": "Incline Dumbbell Press", "target_sets": 4, "muscle": "Chest", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 30, "completed": False}, {"set_num": 2, "reps": 10, "weight_kg": 30, "completed": False}, {"set_num": 3, "reps": 8, "weight_kg": 32, "completed": False}, {"set_num": 4, "reps": 8, "weight_kg": 32, "completed": False}]},
            {"id": "ex_3", "name": "Overhead Tricep Extension", "target_sets": 3, "muscle": "Triceps", "sets": [{"set_num": 1, "reps": 12, "weight_kg": 25, "completed": False}, {"set_num": 2, "reps": 12, "weight_kg": 25, "completed": False}, {"set_num": 3, "reps": 10, "weight_kg": 28, "completed": False}]}
        ]
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO daily_goals (user_id, date, target_sets, completed_sets, target_volume_kg, completed_volume_kg, target_duration_min, completed_duration_min, active_split_title, active_split_category, routine_json)
            VALUES (?, ?, 11, 0, 4800, 0, 50, 0, 'Hypertrophy Push Session', 'Chest & Triceps', ?)
        """, (user['id'], today_str, json.dumps(routine)))
        conn.commit()
        daily = conn.execute("SELECT * FROM daily_goals WHERE user_id = ? AND date = ?", (user['id'], today_str)).fetchone()

    daily_dict = dict(daily)
    routine_data = json.loads(daily_dict['routine_json']) if daily_dict.get('routine_json') else []

    completed_sets = daily_dict['completed_sets']
    target_sets = daily_dict['target_sets']
    remaining_sets = max(0, target_sets - completed_sets)
    target_volume = daily_dict['target_volume_kg']
    completed_volume = daily_dict['completed_volume_kg']
    remaining_volume = max(0, target_volume - completed_volume)

    all_users = conn.execute("SELECT id, username, xp, division, current_streak, avatar_color FROM users ORDER BY xp DESC").fetchall()
    user_rank = 1
    rival_ahead = None
    leader = dict(all_users[0]) if all_users else None

    for idx, u in enumerate(all_users):
        if u['id'] == user['id']:
            user_rank = idx + 1
            if idx > 0:
                prev_user = all_users[idx - 1]
                xp_diff = prev_user['xp'] - user['xp']
                workouts_needed = max(1, math.ceil(xp_diff / 180.0))
                rival_ahead = {
                    "username": prev_user['username'],
                    "xp": prev_user['xp'],
                    "xp_ahead": xp_diff,
                    "workouts_needed": workouts_needed,
                    "rank": idx
                }
            break

    recent_workouts = conn.execute("""
        SELECT * FROM workouts WHERE user_id = ? ORDER BY date DESC, id DESC LIMIT 5
    """, (user['id'],)).fetchall()
    workouts_list = [dict(w) for w in recent_workouts]

    challenges = conn.execute("""
        SELECT c.*, uc.progress, uc.is_completed, uc.joined_at
        FROM challenges c
        JOIN user_challenges uc ON c.id = uc.challenge_id
        WHERE uc.user_id = ? AND uc.is_completed = 0
        ORDER BY c.id ASC
    """, (user['id'],)).fetchall()
    challenges_list = [dict(c) for c in challenges]

    ach_count = conn.execute("SELECT COUNT(*) FROM user_achievements WHERE user_id = ?", (user['id'],)).fetchone()[0]
    total_ach = conn.execute("SELECT COUNT(*) FROM achievements").fetchone()[0]

    stats = conn.execute("""
        SELECT COUNT(*) as total_workouts, COALESCE(SUM(total_volume_kg), 0) as total_volume, COALESCE(SUM(duration_min), 0) as total_minutes
        FROM workouts WHERE user_id = ?
    """, (user['id'],)).fetchone()

    conn.close()

    del user['password_hash']
    return jsonify({
        "success": True,
        "user": {
            **user,
            "rank": user_rank,
            "division": recalculate_division(user['xp']),
            "achievements_count": ach_count,
            "total_achievements": total_ach,
            "stats": dict(stats)
        },
        "today": {
            "title": daily_dict['active_split_title'],
            "category": daily_dict['active_split_category'],
            "target_sets": target_sets,
            "completed_sets": completed_sets,
            "remaining_sets": remaining_sets,
            "sets_percentage": round((completed_sets / target_sets * 100) if target_sets else 100, 1),
            "target_volume_kg": target_volume,
            "completed_volume_kg": completed_volume,
            "remaining_volume_kg": remaining_volume,
            "target_duration_min": daily_dict['target_duration_min'],
            "completed_duration_min": daily_dict['completed_duration_min'],
            "routine": routine_data
        },
        "competition": {
            "current_rank": user_rank,
            "rival_ahead": rival_ahead,
            "leader": leader,
            "points_behind_leader": (leader['xp'] - user['xp']) if leader else 0
        },
        "recent_workouts": workouts_list,
        "active_challenges": challenges_list,
        "quotes": MOTIVATIONAL_QUOTES
    })

# ----------------- WORKOUT LOGGING & SET TOGGLE ----------------- #

@app.route('/api/workouts/toggle-set', methods=['POST'])
def toggle_routine_set():
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json() or {}
    exercise_id = str(data.get('exercise_id', ''))
    set_num = int(data.get('set_num', 0))
    completed = bool(data.get('completed', True))

    today_str = datetime.now().strftime("%Y-%m-%d")
    daily = conn.execute("SELECT * FROM daily_goals WHERE user_id = ? AND date = ?", (user['id'], today_str)).fetchone()

    # Auto-create if missing — on Vercel, parallel instances each have their own temp DB
    if not daily:
        default_routine = [
            {"id": "ex_1", "name": "Barbell Bench Press",       "target_sets": 4, "muscle": "Chest",
             "sets": [{"set_num": 1, "reps": 10, "weight_kg": 75, "completed": False},
                      {"set_num": 2, "reps": 8,  "weight_kg": 80, "completed": False},
                      {"set_num": 3, "reps": 8,  "weight_kg": 80, "completed": False},
                      {"set_num": 4, "reps": 6,  "weight_kg": 85, "completed": False}]},
            {"id": "ex_2", "name": "Incline Dumbbell Press",    "target_sets": 4, "muscle": "Chest",
             "sets": [{"set_num": 1, "reps": 10, "weight_kg": 30, "completed": False},
                      {"set_num": 2, "reps": 10, "weight_kg": 30, "completed": False},
                      {"set_num": 3, "reps": 8,  "weight_kg": 32, "completed": False},
                      {"set_num": 4, "reps": 8,  "weight_kg": 32, "completed": False}]},
            {"id": "ex_3", "name": "Overhead Tricep Extension", "target_sets": 3, "muscle": "Triceps",
             "sets": [{"set_num": 1, "reps": 12, "weight_kg": 25, "completed": False},
                      {"set_num": 2, "reps": 12, "weight_kg": 25, "completed": False},
                      {"set_num": 3, "reps": 10, "weight_kg": 28, "completed": False}]}
        ]
        cursor2 = conn.cursor()
        cursor2.execute("""
            INSERT INTO daily_goals (user_id, date, target_sets, completed_sets,
              target_volume_kg, completed_volume_kg, target_duration_min,
              completed_duration_min, active_split_title, active_split_category, routine_json)
            VALUES (?, ?, 11, 0, 4800, 0, 50, 0, 'Hypertrophy Push Session', 'Chest & Triceps', ?)
        """, (user['id'], today_str, json.dumps(default_routine)))
        conn.commit()
        daily = conn.execute("SELECT * FROM daily_goals WHERE user_id = ? AND date = ?", (user['id'], today_str)).fetchone()

    if not daily:
        conn.close()
        return jsonify({"error": "Could not initialize routine."}), 500

    routine = json.loads(daily['routine_json'])
    set_volume = 0.0
    set_toggled = False

    for ex in routine:
        if str(ex.get('id', '')) == exercise_id:
            for s in ex.get('sets', []):
                if int(s.get('set_num', -1)) == set_num:
                    s['completed'] = completed
                    set_volume = float(s.get('reps', 10)) * float(s.get('weight_kg', 20))
                    set_toggled = True
                    break
        if set_toggled:
            break

    total_completed_sets = 0
    total_completed_vol = 0
    for ex in routine:
        for s in ex.get('sets', []):
            if s.get('completed'):
                total_completed_sets += 1
                total_completed_vol += s.get('reps', 0) * s.get('weight_kg', 0)

    xp_delta = 25 if completed else -25
    new_xp = max(0, user['xp'] + xp_delta)
    new_division = recalculate_division(new_xp)

    cursor = conn.cursor()
    cursor.execute("""
        UPDATE daily_goals
        SET completed_sets = ?, completed_volume_kg = ?, routine_json = ?
        WHERE id = ?
    """, (total_completed_sets, total_completed_vol, json.dumps(routine), daily['id']))

    cursor.execute("""
        UPDATE users SET xp = ?, division = ? WHERE id = ?
    """, (new_xp, new_division, user['id']))

    if total_completed_sets >= 100:
        ach = conn.execute("SELECT id FROM achievements WHERE code = 'CENTURY_CLUB'").fetchone()
        if ach:
            cursor.execute("INSERT OR IGNORE INTO user_achievements (user_id, achievement_id) VALUES (?, ?)", (user['id'], ach['id']))

    if completed:
        cursor.execute("""
            UPDATE user_challenges
            SET progress = progress + ?
            WHERE user_id = ? AND is_completed = 0 AND challenge_id IN (SELECT id FROM challenges WHERE category = 'Volume')
        """, (set_volume, user['id']))

    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "completed_sets": total_completed_sets,
        "remaining_sets": max(0, daily['target_sets'] - total_completed_sets),
        "completed_volume_kg": total_completed_vol,
        "new_xp": new_xp,
        "xp_awarded": xp_delta if completed else 0
    })

@app.route('/api/workouts', methods=['GET', 'POST'])
def handle_workouts():
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 401

    if request.method == 'GET':
        workouts = conn.execute("""
            SELECT w.*,
                   GROUP_CONCAT(we.exercise_name || ' (' || json_array_length(we.sets_json) || ' sets)', ', ') as exercise_summary
            FROM workouts w
            LEFT JOIN workout_exercises we ON w.id = we.workout_id
            WHERE w.user_id = ?
            GROUP BY w.id
            ORDER BY w.date DESC, w.id DESC
        """, (user['id'],)).fetchall()

        workout_list = []
        for w in workouts:
            w_dict = dict(w)
            exs = conn.execute("SELECT exercise_name, sets_json FROM workout_exercises WHERE workout_id = ?", (w['id'],)).fetchall()
            w_dict['exercises'] = [{"name": e['exercise_name'], "sets": json.loads(e['sets_json'])} for e in exs]
            workout_list.append(w_dict)

        conn.close()
        return jsonify({"success": True, "workouts": workout_list})

    data = request.get_json() or {}
    title = data.get('title', 'Hypertrophy Power Blast').strip()
    category = data.get('category', 'Chest & Triceps').strip()
    duration_min = int(data.get('duration_min', 45))
    notes = data.get('notes', '').strip()
    exercises = data.get('exercises', [])
    date_str = data.get('date', datetime.now().strftime("%Y-%m-%d"))

    total_sets = 0
    total_volume = 0.0

    for ex in exercises:
        sets = ex.get('sets', [])
        total_sets += len(sets)
        for s in sets:
            reps = float(s.get('reps', 10))
            weight = float(s.get('weight_kg', 0))
            total_volume += reps * weight

    xp_earned = 150 + int(total_sets * 10) + int(total_volume / 200)

    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO workouts (user_id, title, category, duration_min, total_volume_kg, sets_completed, total_sets, date, notes, xp_earned)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (user['id'], title, category, duration_min, round(total_volume, 1), total_sets, total_sets, date_str, notes, xp_earned))
    workout_id = cursor.lastrowid

    for ex in exercises:
        cursor.execute("""
            INSERT INTO workout_exercises (workout_id, exercise_name, sets_json)
            VALUES (?, ?, ?)
        """, (workout_id, ex.get('name', 'Exercise'), json.dumps(ex.get('sets', []))))

    new_streak = user['current_streak'] + 1
    new_xp = user['xp'] + xp_earned
    new_div = recalculate_division(new_xp)
    cursor.execute("UPDATE users SET current_streak = ?, xp = ?, division = ? WHERE id = ?", (new_streak, new_xp, new_div, user['id']))

    first_ach = conn.execute("SELECT id FROM achievements WHERE code = 'FIRST_BLOOD'").fetchone()
    if first_ach:
        cursor.execute("INSERT OR IGNORE INTO user_achievements (user_id, achievement_id) VALUES (?, ?)", (user['id'], first_ach['id']))

    if new_streak >= 5:
        streak_ach = conn.execute("SELECT id FROM achievements WHERE code = 'IRON_TITAN_STREAK'").fetchone()
        if streak_ach:
            cursor.execute("INSERT OR IGNORE INTO user_achievements (user_id, achievement_id) VALUES (?, ?)", (user['id'], streak_ach['id']))

    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "message": f"Workout logged! +{xp_earned} XP earned! TRACK. IMPROVE. CONQUER.",
        "workout_id": workout_id,
        "xp_earned": xp_earned,
        "new_xp": new_xp,
        "new_streak": new_streak
    })

# ----------------- LEADERBOARDS & RIVALRY ----------------- #

@app.route('/api/leaderboard', methods=['GET'])
def get_leaderboard():
    conn = get_db()
    current_user = get_current_user(conn)

    users = conn.execute("""
        SELECT u.id, u.username, u.xp, u.division, u.current_streak, u.avatar_color, u.fitness_goal,
               COUNT(w.id) as workouts_completed,
               COALESCE(SUM(w.total_volume_kg), 0) as total_volume
        FROM users u
        LEFT JOIN workouts w ON u.id = w.user_id
        GROUP BY u.id
        ORDER BY u.xp DESC
    """).fetchall()

    leaderboard = []
    user_standing = None
    rival_directly_ahead = None

    for idx, u in enumerate(users):
        rank = idx + 1
        entry = {
            "rank": rank,
            "id": u['id'],
            "username": u['username'],
            "xp": u['xp'],
            "division": recalculate_division(u['xp']),
            "streak": u['current_streak'],
            "avatar_color": u['avatar_color'],
            "fitness_goal": u['fitness_goal'],
            "workouts_completed": u['workouts_completed'],
            "total_volume": round(u['total_volume'], 0),
            "is_current_user": bool(current_user and u['id'] == current_user['id'])
        }
        leaderboard.append(entry)

        if current_user and u['id'] == current_user['id']:
            user_standing = entry
            if idx > 0:
                prev = users[idx - 1]
                gap = prev['xp'] - u['xp']
                workouts_needed = max(1, math.ceil(gap / 180.0))
                rival_directly_ahead = {
                    "rank": idx,
                    "username": prev['username'],
                    "xp": prev['xp'],
                    "xp_gap": gap,
                    "workouts_needed": workouts_needed,
                    "tip": f"Crush {workouts_needed} intense session{'s' if workouts_needed > 1 else ''} to dethrone @{prev['username']}!"
                }

    leader = leaderboard[0] if leaderboard else None
    gap_to_champion = (leader['xp'] - user_standing['xp']) if (leader and user_standing) else 0

    conn.close()
    return jsonify({
        "success": True,
        "leaderboard": leaderboard,
        "user_standing": user_standing,
        "rival_ahead": rival_directly_ahead,
        "champion_gap": {
            "champion_name": leader['username'] if leader else None,
            "points_behind": gap_to_champion,
            "workouts_behind": math.ceil(gap_to_champion / 180.0) if gap_to_champion > 0 else 0
        }
    })

# ----------------- CHALLENGES & ACHIEVEMENTS ----------------- #

@app.route('/api/challenges', methods=['GET'])
def get_challenges():
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 401

    challenges = conn.execute("""
        SELECT c.*,
               COALESCE(uc.progress, 0) as user_progress,
               COALESCE(uc.is_completed, 0) as is_joined_and_completed,
               CASE WHEN uc.id IS NOT NULL THEN 1 ELSE 0 END as is_joined
        FROM challenges c
        LEFT JOIN user_challenges uc ON c.id = uc.challenge_id AND uc.user_id = ?
        ORDER BY c.id ASC
    """, (user['id'],)).fetchall()

    result = []
    for c in challenges:
        c_dict = dict(c)
        progress = c_dict['user_progress']
        target = c_dict['target_value']
        c_dict['progress_pct'] = min(100.0, round((progress / target) * 100.0, 1)) if target else 0
        result.append(c_dict)

    conn.close()
    return jsonify({"success": True, "challenges": result})

@app.route('/api/challenges/join', methods=['POST'])
def join_challenge():
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json() or {}
    challenge_id = data.get('challenge_id')
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR IGNORE INTO user_challenges (user_id, challenge_id, progress, is_completed)
        VALUES (?, ?, 0, 0)
    """, (user['id'], challenge_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True, "message": "Joined challenge! Push your limits and conquer."})

@app.route('/api/challenges/progress', methods=['POST'])
def add_challenge_progress():
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json() or {}
    challenge_id = data.get('challenge_id')
    amount = int(data.get('amount', 10))

    cursor = conn.cursor()
    row = conn.execute("SELECT uc.*, c.target_value, c.reward_xp, c.badge_name FROM user_challenges uc JOIN challenges c ON uc.challenge_id = c.id WHERE uc.user_id = ? AND uc.challenge_id = ?", (user['id'], challenge_id)).fetchone()
    if not row:
        conn.close()
        return jsonify({"error": "Challenge not joined yet."}), 400

    new_prog = row['progress'] + amount
    is_done = 1 if new_prog >= row['target_value'] else 0
    xp_bonus = row['reward_xp'] if (is_done and not row['is_completed']) else 0

    cursor.execute("""
        UPDATE user_challenges
        SET progress = ?, is_completed = ?, completed_at = CASE WHEN ? = 1 THEN CURRENT_TIMESTAMP ELSE completed_at END
        WHERE id = ?
    """, (new_prog, is_done, is_done, row['id']))

    if xp_bonus > 0:
        new_xp = user['xp'] + xp_bonus
        cursor.execute("UPDATE users SET xp = ?, division = ? WHERE id = ?", (new_xp, recalculate_division(new_xp), user['id']))

    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "new_progress": new_prog,
        "target": row['target_value'],
        "is_completed": bool(is_done),
        "reward_xp": xp_bonus
    })

@app.route('/api/achievements', methods=['GET'])
def get_achievements():
    conn = get_db()
    user = get_current_user(conn)
    achievements = conn.execute("""
        SELECT a.*,
               CASE WHEN ua.id IS NOT NULL THEN 1 ELSE 0 END as unlocked,
               ua.unlocked_at
        FROM achievements a
        LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ?
        ORDER BY unlocked DESC, a.id ASC
    """, (user['id'] if user else -1,)).fetchall()

    conn.close()
    return jsonify({"success": True, "achievements": [dict(a) for a in achievements]})

@app.route('/api/quotes', methods=['GET'])
def get_quotes():
    return jsonify({"success": True, "quotes": MOTIVATIONAL_QUOTES})

@app.route('/api/reset-seed', methods=['POST'])
def reset_seed():
    """Reset the database to clean pre-populated sample state."""
    init_db(force_reseed=True)
    return jsonify({"success": True, "message": "AthletiQ database reseeded to pristine sample state!"})

@app.route('/')
@app.route('/login')
@app.route('/signup')
def index():
    return render_template('index.html')


# ═══════════════════════════════════════════════════════════════
#  ATHLETIQ COACH — AI CHAT BACKEND
#  API key is ONLY on the server — never sent to the browser.
# ═══════════════════════════════════════════════════════════════

def _coach_get_user_context(user, conn):
    """Build a rich context string from the user's real AthletiQ data."""
    today_str = datetime.now().strftime("%Y-%m-%d")

    # --- Today's workout ---
    daily = conn.execute(
        "SELECT * FROM daily_goals WHERE user_id = ? AND date = ?",
        (user['id'], today_str)
    ).fetchone()
    today_ctx = ""
    if daily:
        d = dict(daily)
        pct = round((d['completed_sets'] / d['target_sets'] * 100) if d['target_sets'] else 0, 1)
        remaining = max(0, d['target_sets'] - d['completed_sets'])
        today_ctx = (
            f"TODAY'S WORKOUT: {d['active_split_title']} ({d['active_split_category']})\n"
            f"  Progress: {pct}% done — {d['completed_sets']}/{d['target_sets']} sets completed, {remaining} sets remaining\n"
            f"  Volume: {d['completed_volume_kg']}kg done of {d['target_volume_kg']}kg target\n"
        )
        routine = json.loads(d['routine_json']) if d.get('routine_json') else []
        if routine:
            ex_lines = [f"    • {ex['name']}: {ex['target_sets']} sets ({ex['muscle']})" for ex in routine[:5]]
            today_ctx += "  Exercises:\n" + "\n".join(ex_lines) + "\n"

    # --- Workout history (last 7) ---
    workouts = conn.execute(
        "SELECT title, category, total_volume_kg, sets_completed, duration_min, xp_earned, date "
        "FROM workouts WHERE user_id = ? ORDER BY date DESC, id DESC LIMIT 3",
        (user['id'],)
    ).fetchall()
    hist_ctx = ""
    if workouts:
        lines = [
            f"    • {w['date']} — {w['title']} | {w['sets_completed']} sets | "
            f"{w['total_volume_kg']}kg | +{w['xp_earned']}XP"
            for w in workouts
        ]
        hist_ctx = "RECENT WORKOUTS (last 7):\n" + "\n".join(lines) + "\n"
    else:
        hist_ctx = "RECENT WORKOUTS: None logged yet — this athlete is just getting started!\n"

    # --- Leaderboard & rank ---
    all_users = conn.execute(
        "SELECT id, username, xp, division, current_streak FROM users ORDER BY xp DESC"
    ).fetchall()
    user_rank = 1
    rival_ctx = ""
    for idx, u in enumerate(all_users):
        if u['id'] == user['id']:
            user_rank = idx + 1
            if idx > 0:
                prev = all_users[idx - 1]
                gap = prev['xp'] - user['xp']
                rival_ctx = (
                    f"RIVAL DIRECTLY AHEAD: @{prev['username']} (#{idx}) — "
                    f"{gap} XP ahead (~{max(1, math.ceil(gap/180))} workouts to close gap)\n"
                )
            break
    leader = dict(all_users[0]) if all_users else None
    lb_top = "\n".join([
        f"  #{i+1} @{u['username']} — {u['xp']}XP | {u['current_streak']}d streak"
        for i, u in enumerate(all_users[:10])
    ])
    lb_ctx = f"LEADERBOARD TOP 10:\n{lb_top}\n"


    # --- Challenges ---
    challenges = conn.execute("""
        SELECT c.title, c.description, c.target_value, c.reward_xp, uc.progress, uc.is_completed
        FROM challenges c
        JOIN user_challenges uc ON c.id = uc.challenge_id
        WHERE uc.user_id = ? AND uc.is_completed = 0
        ORDER BY c.id ASC LIMIT 4
    """, (user['id'],)).fetchall()
    ch_ctx = ""
    if challenges:
        lines = [
            f"    • {c['title']}: {c['progress']}/{c['target_value']} (+{c['reward_xp']}XP reward)"
            for c in challenges
        ]
        ch_ctx = "ACTIVE CHALLENGES:\n" + "\n".join(lines) + "\n"

    # --- Achievements ---
    ach_count = conn.execute(
        "SELECT COUNT(*) FROM user_achievements WHERE user_id = ?", (user['id'],)
    ).fetchone()[0]
    total_ach = conn.execute("SELECT COUNT(*) FROM achievements").fetchone()[0]
    ach_ctx = f"ACHIEVEMENTS: {ach_count}/{total_ach} badges unlocked\n"

    # --- Stats summary ---
    stats = conn.execute(
        "SELECT COUNT(*) as tw, COALESCE(SUM(total_volume_kg),0) as tv, COALESCE(SUM(duration_min),0) as tm "
        "FROM workouts WHERE user_id = ?", (user['id'],)
    ).fetchone()

    context = (
        f"═══════════ ATHLETE DATA FOR: @{user['username']} ═══════════\n"
        f"NAME: {user.get('full_name', user['username'])}\n"
        f"RANK: #{user_rank} Global | Division: {recalculate_division(user['xp'])}\n"
        f"XP: {user['xp']} total | Streak: {user['current_streak']} days\n"
        f"ALL-TIME STATS: {stats['tw']} workouts | {int(stats['tv'])}kg total volume | {stats['tm']} mins trained\n"
        f"FITNESS GOAL: {user.get('fitness_goal', 'Build Muscle')}\n"
        f"══════════════════════════════════════════════\n"
        f"{today_ctx}"
        f"{rival_ctx}"
        f"{lb_ctx}"
        f"{ch_ctx}"
        f"{ach_ctx}"
        f"══════════════════════════════════════════════\n"
    )
    return context


_COACH_SYSTEM_PROMPT = """You are ATHLETIQ COACH — an elite AI fitness coach built into the AthletiQ app.

Your personality:
- Intense, direct, confident — like a world-class personal trainer
- Always reference the athlete's REAL data shown above
- Use the AthletiQ brand tone: "TRACK. IMPROVE. CONQUER."

Rules:
- NEVER give generic advice — always use the specific athlete data provided
- Keep responses under 400 words
- Use the athlete's username occasionally
- Format with line breaks — no long paragraphs
- When asked for a workout plan or exercises: list SPECIFIC exercises with sets x reps (e.g. "Barbell Curl — 4x10")
- When asked about today's workout: quote the exact exercises and set counts from the data
- When asked about rank: quote exact XP gaps and rival names
- When asked general fitness questions: give real actionable advice with numbers
- End with a short motivational line only when appropriate
- If the user is just hyping up (saying "yes", "yess" etc): keep reply short and energetic, do NOT repeat the same text
- Do not truncate mid-sentence — always complete your thought

You represent AthletiQ — premium fitness technology. Sound premium and helpful."""



@app.route('/api/coach/chat', methods=['POST'])
def coach_chat():
    """
    AthletiQ Coach AI endpoint.
    Gathers user data server-side, calls Gemini, returns coach reply.
    The GEMINI_API_KEY is never sent to the browser.
    """
    conn = get_db()
    user = get_current_user(conn)
    if not user:
        conn.close()
        return jsonify({"error": "Unauthorized — please log in first."}), 401

    data = request.get_json() or {}
    user_message = (data.get('message') or '').strip()[:500]  # cap input length

    if not user_message:
        conn.close()
        return jsonify({"error": "No message provided."}), 400

    # Build athlete context from real DB data
    try:
        context = _coach_get_user_context(user, conn)
    except Exception as e:
        conn.close()
        return jsonify({"error": f"Could not load athlete data: {str(e)}"}), 500
    finally:
        conn.close()

    # Call Gemini via REST API
    full_prompt = (
        f"{_COACH_SYSTEM_PROMPT}\n\n"
        f"{context}\n"
        f"ATHLETE SAYS: {user_message}"
    )
    reply = _call_gemini(full_prompt)
    if not reply:
        reply = _fallback_coach_response(user_message, context)

    return jsonify({"success": True, "reply": reply})


@app.route('/api/coach/debug', methods=['GET'])
def coach_debug():
    """Debug endpoint — tests both auth methods on all Gemini models."""
    key = os.environ.get('GEMINI_API_KEY', '').strip()
    if not key:
        return jsonify({"key_set": False})

    results = {}
    payload = {"contents": [{"parts": [{"text": "Say hi."}]}]}

    for model in ["gemini-3.6-flash", "gemini-2.5-flash", "gemini-2.0-flash-exp", "gemini-1.5-flash-002"]:

        base = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        # Bearer token
        try:
            r = _requests.post(base, json=payload,
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                timeout=8)
            results[f"{model}/bearer"] = {"status": r.status_code, "ok": r.status_code == 200,
                                           "error": r.json().get("error", {}).get("message", "") if r.status_code != 200 else "OK"}
        except Exception as e:
            results[f"{model}/bearer"] = {"status": "error", "msg": str(e)}
        # API key param
        try:
            r = _requests.post(f"{base}?key={key}", json=payload, timeout=8)
            results[f"{model}/apikey"] = {"status": r.status_code, "ok": r.status_code == 200,
                                           "error": r.json().get("error", {}).get("message", "") if r.status_code != 200 else "OK"}
        except Exception as e:
            results[f"{model}/apikey"] = {"status": "error", "msg": str(e)}

    return jsonify({"key_prefix": key[:12] + "...", "results": results})






def _fallback_coach_response(message: str, context: str) -> str:
    """
    Rule-based fallback when Gemini is unavailable.
    Parses the context string to return real data — never generic.
    """
    msg = message.lower()

    # Extract key lines from context
    ctx_lines = {line.split(':')[0].strip(): ':'.join(line.split(':')[1:]).strip()
                 for line in context.split('\n') if ':' in line}

    username  = ctx_lines.get('NAME', 'Athlete')
    rank      = ctx_lines.get('RANK', '#? Global')
    xp_line   = ctx_lines.get('XP', '0 total')
    streak    = ctx_lines.get('Streak', '0 days') if 'Streak' not in ctx_lines else ctx_lines.get('XP', '')
    today_line = ctx_lines.get("TODAY'S WORKOUT", '')
    rival_line = ctx_lines.get('RIVAL DIRECTLY AHEAD', '')

    # Parse XP and streak from the combined line
    xp_val = xp_line.split('total')[0].strip() if 'total' in xp_line else xp_line
    streak_val = xp_line.split('Streak:')[-1].strip() if 'Streak:' in xp_line else '?'

    if any(w in msg for w in ['today', 'workout', 'plan', 'session', 'exercise']):
        if today_line:
            return (f"⚡ TODAY'S MISSION:\n{today_line}\n\n"
                    f"Every set counts toward your rank. Lock in and execute. CONQUER.")
        return "⚡ No workout logged for today yet. Head to the Dashboard and start your session — the leaderboard waits for no one."

    if any(w in msg for w in ['rank', 'leaderboard', 'position', 'standing', 'place']):
        base = f"🏆 You're currently {rank}.\n"
        if rival_line:
            base += f"Rival: {rival_line}\n\nClose that gap. One intense session changes everything."
        return base

    if any(w in msg for w in ['xp', 'points', 'experience', 'score']):
        return (f"⚡ You've stacked {xp_val} XP — that's {rank}.\n"
                f"Every completed set adds XP. Stay consistent and you'll climb. TRACK. IMPROVE. CONQUER.")

    if any(w in msg for w in ['streak', 'days', 'consistency', 'consecutive']):
        return (f"🔥 Your streak: {streak_val}.\n"
                f"Streaks compound — every day you show up makes tomorrow easier. Don't break the chain.")

    if any(w in msg for w in ['rival', 'compete', 'beat', 'close', 'gap', 'catch']):
        if rival_line:
            return f"🎯 {rival_line}\n\nTarget locked. Grind hard this week and take that spot."
        return "🎯 You're currently leading or just getting started. Either way — push harder."

    if any(w in msg for w in ['progress', 'week', 'history', 'how am i', 'doing']):
        return (f"📊 Current standing: {rank} | {xp_val} XP\n"
                f"Check your Workout History tab for full session breakdown. Keep stacking volume.")

    if any(w in msg for w in ['improve', 'focus', 'tip', 'advice', 'should', 'better']):
        if rival_line:
            return (f"🎯 Priority: Close the gap on your rival.\n{rival_line}\n\n"
                    f"Focus on high-volume sessions — more sets = more XP = higher rank.")
        return ("💪 Priority one: consistency.\n"
                "Log every session, complete every set, and let the XP compound. "
                "The leaderboard rewards athletes who show up daily. CONQUER.")

    # Generic catch-all
    return (f"⚡ ATHLETIQ COACH here, @{username}.\n"
            f"You're at {rank} with {xp_val} XP. Ask me about today's workout, your rank, "
            f"your streak, or how to improve — I've got your real data ready.")


if __name__ == '__main__':
    init_db()
    print("AthletiQ server running on http://0.0.0.0:5000 (accessible on LAN) - TRACK. IMPROVE. CONQUER.")
    app.run(host='0.0.0.0', port=5000, debug=False)

