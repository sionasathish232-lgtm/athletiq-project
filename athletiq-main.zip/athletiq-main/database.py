"""
database.py - Database setup, SQLite connection, and initial seed data for AthletiQ.
"TRACK. IMPROVE. CONQUER."
"""
import sqlite3
import os
import json
import hashlib
import tempfile
import shutil
from datetime import datetime, timedelta

BUNDLED_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "titan_fitness.db")

def _get_db_path():
    if os.environ.get('VERCEL'):
        return os.path.join(tempfile.gettempdir(), "titan_fitness.db")
    return BUNDLED_DB

DB_FILE = _get_db_path()

def hash_password(password: str) -> str:
    """Generate salted SHA-256 hash for password."""
    salt = "athletiq_conquer_salt_2026"
    return hashlib.sha256((password + salt).encode('utf-8')).hexdigest()

def _raw_connect():
    """Create a raw database connection without triggering init_db recursion."""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def get_db():
    """Returns a SQLite database connection with row factory enabled."""
    global DB_FILE
    DB_FILE = _get_db_path()
    if os.environ.get('VERCEL') and os.path.exists(BUNDLED_DB):
        try:
            should_copy = (
                not os.path.exists(DB_FILE) or
                os.path.getmtime(BUNDLED_DB) > os.path.getmtime(DB_FILE)
            )
            if should_copy:
                shutil.copyfile(BUNDLED_DB, DB_FILE)
        except Exception:
            init_db()
    elif not os.path.exists(DB_FILE):
        init_db()
    return _raw_connect()

def init_db(force_reseed=False):
    """Initializes schema and seeds initial sample data if empty or forced."""
    global DB_FILE
    DB_FILE = _get_db_path()
    conn = _raw_connect()
    cursor = conn.cursor()

    if force_reseed:
        cursor.executescript("""
            DROP TABLE IF EXISTS user_achievements;
            DROP TABLE IF EXISTS achievements;
            DROP TABLE IF EXISTS user_challenges;
            DROP TABLE IF EXISTS challenges;
            DROP TABLE IF EXISTS workout_exercises;
            DROP TABLE IF EXISTS workouts;
            DROP TABLE IF EXISTS daily_goals;
            DROP TABLE IF EXISTS users;
        """)

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            full_name TEXT DEFAULT '',
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            security_answer TEXT DEFAULT 'gym',
            fitness_goal TEXT DEFAULT 'Hypertrophy (Muscle Gain)',
            experience_level TEXT DEFAULT 'Intermediate',
            weight_kg REAL DEFAULT 78.0,
            height_cm REAL DEFAULT 175.0,
            goal_weight_kg REAL DEFAULT 75.0,
            gender TEXT DEFAULT 'male',
            age INTEGER DEFAULT 22,
            current_body_shape TEXT DEFAULT 'average',
            goal_body_shape TEXT DEFAULT 'athletic',
            workout_frequency TEXT DEFAULT 'regular',
            lifestyle_role TEXT DEFAULT 'desk_job',
            onboarding_complete INTEGER DEFAULT 0,
            xp INTEGER DEFAULT 0,
            current_streak INTEGER DEFAULT 0,
            division TEXT DEFAULT 'Bronze',
            avatar_color TEXT DEFAULT '#ef233c',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );


        CREATE TABLE IF NOT EXISTS workouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            duration_min INTEGER DEFAULT 45,
            total_volume_kg REAL DEFAULT 0,
            sets_completed INTEGER DEFAULT 0,
            total_sets INTEGER DEFAULT 0,
            date TEXT NOT NULL,
            notes TEXT,
            xp_earned INTEGER DEFAULT 100,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS workout_exercises (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workout_id INTEGER NOT NULL,
            exercise_name TEXT NOT NULL,
            sets_json TEXT NOT NULL,
            FOREIGN KEY (workout_id) REFERENCES workouts(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS daily_goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            target_sets INTEGER DEFAULT 18,
            completed_sets INTEGER DEFAULT 0,
            target_volume_kg REAL DEFAULT 5000,
            completed_volume_kg REAL DEFAULT 0,
            target_duration_min INTEGER DEFAULT 60,
            completed_duration_min INTEGER DEFAULT 0,
            active_split_title TEXT DEFAULT 'Chest & Triceps Hypertrophy Crucible',
            active_split_category TEXT DEFAULT 'Chest & Triceps',
            routine_json TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            target_value INTEGER NOT NULL,
            unit TEXT NOT NULL,
            reward_xp INTEGER NOT NULL,
            badge_name TEXT NOT NULL,
            badge_icon TEXT NOT NULL,
            difficulty TEXT DEFAULT 'Medium',
            duration_days INTEGER DEFAULT 14
        );

        CREATE TABLE IF NOT EXISTS user_challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            challenge_id INTEGER NOT NULL,
            progress INTEGER DEFAULT 0,
            is_completed INTEGER DEFAULT 0,
            joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (challenge_id) REFERENCES challenges(id) ON DELETE CASCADE,
            UNIQUE(user_id, challenge_id)
        );

        CREATE TABLE IF NOT EXISTS achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            icon TEXT NOT NULL,
            category TEXT DEFAULT 'General',
            xp_reward INTEGER DEFAULT 150
        );

        CREATE TABLE IF NOT EXISTS user_achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            achievement_id INTEGER NOT NULL,
            unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE,
            UNIQUE(user_id, achievement_id)
        );
    """)

    conn.commit()

    # Seed initial data if users table is empty
    user_count = cursor.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if user_count == 0 or force_reseed:
        seed_data(conn)

    conn.close()

def seed_data(conn):
    """Seed comprehensive sample data for immediate rich testing."""
    cursor = conn.cursor()
    today_str = datetime.now().strftime("%Y-%m-%d")
    yesterday_str = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    two_days_ago = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d")
    four_days_ago = (datetime.now() - timedelta(days=4)).strftime("%Y-%m-%d")

    # Sample Users (Rankings and rivals)
    users = [
        # (username, email, password, goal, level, weight, xp, streak, division, avatar_color)
        ("Viktor_Iron",  "viktor@athletiq.fit",  hash_password("titan123"), "Max Strength & Density",       "Elite",        88.0, 4317, 14, "Diamond",  "#ef233c"),
        ("Marcus_Beast", "marcus@athletiq.fit",  hash_password("titan123"), "Hypertrophy (Muscle Gain)",    "Advanced",     84.5, 3783, 8,  "Platinum", "#ff0033"),
        ("Sarah_Lift",   "sarah@athletiq.fit",   hash_password("titan123"), "Athletic Conditioning",        "Advanced",     63.0, 3614, 6,  "Platinum", "#7c3aed"),
        ("Alex_Forge",   "alex@athletiq.fit",    hash_password("titan123"), "Hypertrophy (Muscle Gain)",    "Intermediate", 78.0, 3447, 4,  "Platinum", "#d90429"),  # Main Demo User
        ("Elena_Blitz",  "elena@athletiq.fit",   hash_password("titan123"), "Fat Loss & Toning",            "Intermediate", 60.5, 3098, 3,  "Platinum", "#0ea5e9"),
        ("Liam_Savage",  "liam@athletiq.fit",    hash_password("titan123"), "Hypertrophy (Muscle Gain)",    "Intermediate", 81.0, 2743, 5,  "Gold",     "#f59e0b"),
        ("Jordan_Swift", "jordan@athletiq.fit",  hash_password("titan123"), "Cardio & Hypertrophy",         "Beginner",     72.0, 2294, 2,  "Gold",     "#10b981"),
        ("Maya_Pulse",   "maya@athletiq.fit",    hash_password("titan123"), "Strength Foundations",         "Beginner",     58.0, 1953, 1,  "Silver",   "#ec4899"),
    ]

    for u in users:
        cursor.execute("""
            INSERT INTO users (username, email, password_hash, fitness_goal, experience_level, weight_kg, xp, current_streak, division, avatar_color)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, u)

    # Get Alex's user id
    alex_id = cursor.execute("SELECT id FROM users WHERE username = 'Alex_Forge'").fetchone()[0]

    # Sample Challenges
    challenges = [
        ("30-Day Push-Up Crucible", "Accumulate 1,500 strict chest-to-deck push-ups to sculpt chest and shoulders.", "Chest", 1500, "reps", 500, "Push-Up Titan", "🛡️", "Hard", 30),
        ("Century Heavy Deadlift", "Perform 100 deadlifts at 1.5x bodyweight or above for posterior chain mastery.", "Back", 100, "reps", 450, "Posterior King", "⚡", "Hard", 14),
        ("Discipline Streak: 7 Days", "Log at least one verified muscle session or active recovery every single day.", "Discipline", 7, "days", 350, "Iron Will", "🔥", "Medium", 7),
        ("15,000 kg Volume Blitz", "Lift a total weekly accumulated volume of 15,000 kilograms across compound lifts.", "Volume", 15000, "kg", 600, "Volume Beast", "🏋️", "Hard", 7),
        ("Shoulder Boulder Storm", "Complete 200 total lateral raises and overhead presses for capped delts.", "Shoulders", 200, "reps", 300, "Capped Delts", "💥", "Medium", 10),
        ("Squat Citadel 100", "Conquer 100 deep barbell squats with flawless quad depth.", "Legs", 100, "reps", 400, "Quad Destroyer", "🦵", "Medium", 14)
    ]

    for c in challenges:
        cursor.execute("""
            INSERT INTO challenges (title, description, category, target_value, unit, reward_xp, badge_name, badge_icon, difficulty, duration_days)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, c)

    # Sample Achievements
    achievements = [
        ("FIRST_BLOOD", "First Blood", "Logged your very first workout session in AthletiQ.", "⚔️", "Beginner", 100),
        ("CENTURY_CLUB", "Century Club", "Completed 100 total working sets across all muscle groups.", "💯", "Volume", 250),
        ("HEAVY_ARTILLERY", "Heavy Artillery", "Bench pressed or squatted 100+ kg in a single working set.", "💥", "Strength", 300),
        ("IRON_TITAN_STREAK", "Iron Titan Streak", "Maintained a 4+ day unbroken training discipline streak.", "🔥", "Consistency", 250),
        ("VOLUME_OVERLORD", "Volume Overlord", "Surpassed 20,000 kg of cumulative weight lifted.", "🏆", "Volume", 400),
        ("PODIUM_CONTENDER", "Podium Contender", "Climbed into the top 5 ranks of the AthletiQ global board.", "🥇", "Social", 350),
        ("STORY_BRAGGER", "Story Champion", "Generated and exported an Instagram Story milestone.", "📱", "Social", 150)
    ]

    for a in achievements:
        cursor.execute("""
            INSERT INTO achievements (code, title, description, icon, category, xp_reward)
            VALUES (?, ?, ?, ?, ?, ?)
        """, a)

    # Attach unlocked achievements to Alex
    unlocked_codes = ["FIRST_BLOOD", "CENTURY_CLUB", "IRON_TITAN_STREAK", "PODIUM_CONTENDER"]
    for code in unlocked_codes:
        ach_id = cursor.execute("SELECT id FROM achievements WHERE code = ?", (code,)).fetchone()[0]
        cursor.execute("""
            INSERT INTO user_achievements (user_id, achievement_id, unlocked_at)
            VALUES (?, ?, ?)
        """, (alex_id, ach_id, (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S")))

    # Join Alex into active challenges with progress
    chal_rows = cursor.execute("SELECT id, title, target_value FROM challenges").fetchall()
    for row in chal_rows:
        cid, title, target = row["id"], row["title"], row["target_value"]
        if "Push-Up" in title:
            cursor.execute("INSERT INTO user_challenges (user_id, challenge_id, progress, is_completed) VALUES (?, ?, ?, ?)", (alex_id, cid, 940, 0))
        elif "Discipline Streak" in title:
            cursor.execute("INSERT INTO user_challenges (user_id, challenge_id, progress, is_completed) VALUES (?, ?, ?, ?)", (alex_id, cid, 4, 0))
        elif "Volume Blitz" in title:
            cursor.execute("INSERT INTO user_challenges (user_id, challenge_id, progress, is_completed) VALUES (?, ?, ?, ?)", (alex_id, cid, 11400, 0))
        elif "Squat Citadel" in title:
            cursor.execute("INSERT INTO user_challenges (user_id, challenge_id, progress, is_completed) VALUES (?, ?, ?, ?)", (alex_id, cid, 100, 1))

    # Past Workouts for Alex
    past_workouts = [
        ("Back & Biceps Annihilation", "Back & Biceps", 55, 6800.0, 16, 16, yesterday_str, "Felt incredible pump on weighted pull-ups and lat pulldowns.", 220, [
            {"exercise_name": "Weighted Pull-Ups", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 15, "completed": True}, {"set_num": 2, "reps": 8, "weight_kg": 20, "completed": True}, {"set_num": 3, "reps": 8, "weight_kg": 20, "completed": True}, {"set_num": 4, "reps": 7, "weight_kg": 20, "completed": True}]},
            {"exercise_name": "Barbell Bent-Over Row", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 75, "completed": True}, {"set_num": 2, "reps": 10, "weight_kg": 80, "completed": True}, {"set_num": 3, "reps": 8, "weight_kg": 85, "completed": True}, {"set_num": 4, "reps": 8, "weight_kg": 85, "completed": True}]},
            {"exercise_name": "Incline Dumbbell Bicep Curl", "sets": [{"set_num": 1, "reps": 12, "weight_kg": 16, "completed": True}, {"set_num": 2, "reps": 10, "weight_kg": 18, "completed": True}, {"set_num": 3, "reps": 10, "weight_kg": 18, "completed": True}, {"set_num": 4, "reps": 9, "weight_kg": 18, "completed": True}]},
            {"exercise_name": "Cable Face Pulls", "sets": [{"set_num": 1, "reps": 15, "weight_kg": 35, "completed": True}, {"set_num": 2, "reps": 15, "weight_kg": 40, "completed": True}, {"set_num": 3, "reps": 15, "weight_kg": 40, "completed": True}, {"set_num": 4, "reps": 12, "weight_kg": 45, "completed": True}]}
        ]),
        ("Leg Day Squat Citadel", "Legs & Calves", 60, 8400.0, 16, 16, two_days_ago, "Hit PR on Barbell Back Squat (120kg x 6 reps)!", 280, [
            {"exercise_name": "Barbell Back Squat", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 100, "completed": True}, {"set_num": 2, "reps": 8, "weight_kg": 110, "completed": True}, {"set_num": 3, "reps": 6, "weight_kg": 120, "completed": True}, {"set_num": 4, "reps": 6, "weight_kg": 120, "completed": True}]},
            {"exercise_name": "Romanian Deadlift", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 90, "completed": True}, {"set_num": 2, "reps": 10, "weight_kg": 100, "completed": True}, {"set_num": 3, "reps": 8, "weight_kg": 105, "completed": True}, {"set_num": 4, "reps": 8, "weight_kg": 105, "completed": True}]},
            {"exercise_name": "Leg Press", "sets": [{"set_num": 1, "reps": 12, "weight_kg": 180, "completed": True}, {"set_num": 2, "reps": 12, "weight_kg": 200, "completed": True}, {"set_num": 3, "reps": 10, "weight_kg": 220, "completed": True}, {"set_num": 4, "reps": 10, "weight_kg": 220, "completed": True}]},
            {"exercise_name": "Standing Calf Raises", "sets": [{"set_num": 1, "reps": 15, "weight_kg": 70, "completed": True}, {"set_num": 2, "reps": 15, "weight_kg": 75, "completed": True}, {"set_num": 3, "reps": 12, "weight_kg": 80, "completed": True}, {"set_num": 4, "reps": 12, "weight_kg": 80, "completed": True}]}
        ]),
        ("Shoulder & Core Explosive", "Shoulders & Core", 45, 4900.0, 14, 14, four_days_ago, "Shoulder pump was insane. Lateral raises with strict slow tempo.", 190, [
            {"exercise_name": "Overhead Barbell Press", "sets": [{"set_num": 1, "reps": 10, "weight_kg": 50, "completed": True}, {"set_num": 2, "reps": 8, "weight_kg": 55, "completed": True}, {"set_num": 3, "reps": 6, "weight_kg": 60, "completed": True}, {"set_num": 4, "reps": 6, "weight_kg": 60, "completed": True}]},
            {"exercise_name": "Dumbbell Lateral Raises", "sets": [{"set_num": 1, "reps": 15, "weight_kg": 12, "completed": True}, {"set_num": 2, "reps": 12, "weight_kg": 14, "completed": True}, {"set_num": 3, "reps": 12, "weight_kg": 14, "completed": True}, {"set_num": 4, "reps": 10, "weight_kg": 16, "completed": True}]},
            {"exercise_name": "Hanging Leg Raises", "sets": [{"set_num": 1, "reps": 15, "weight_kg": 0, "completed": True}, {"set_num": 2, "reps": 15, "weight_kg": 0, "completed": True}, {"set_num": 3, "reps": 12, "weight_kg": 0, "completed": True}]}
        ])
    ]

    for title, cat, dur, vol, s_comp, s_tot, date_w, notes, xp, exercises in past_workouts:
        cursor.execute("""
            INSERT INTO workouts (user_id, title, category, duration_min, total_volume_kg, sets_completed, total_sets, date, notes, xp_earned)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (alex_id, title, cat, dur, vol, s_comp, s_tot, date_w, notes, xp))
        wid = cursor.lastrowid
        for ex in exercises:
            cursor.execute("""
                INSERT INTO workout_exercises (workout_id, exercise_name, sets_json)
                VALUES (?, ?, ?)
            """, (wid, ex["exercise_name"], json.dumps(ex["sets"])))

    # ─── Workout history for ALL other seed athletes ───────────────────────
    def add_workouts(uid, entries):
        for title, cat, dur, vol, sets, xp, date_w in entries:
            cursor.execute("""
                INSERT INTO workouts (user_id, title, category, duration_min, total_volume_kg,
                    sets_completed, total_sets, date, notes, xp_earned)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (uid, title, cat, dur, vol, sets, sets, date_w, "", xp))

    def get_uid(uname):
        r = cursor.execute("SELECT id FROM users WHERE username = ?", (uname,)).fetchone()
        return r[0] if r else None

    # Viktor_Iron — Diamond, 4320 XP — heavy strength focus
    vid = get_uid("Viktor_Iron")
    if vid:
        add_workouts(vid, [
            ("Heavy Deadlift Session",       "Back & Biceps",      65, 9800.0, 18, 300, yesterday_str),
            ("Max Bench Press Day",          "Chest & Triceps",    60, 8500.0, 16, 290, two_days_ago),
            ("Squat Strength Block",         "Legs & Calves",      70, 11200.0, 20, 310, four_days_ago),
            ("Overhead Press Power",         "Shoulders & Core",   55, 7200.0, 14, 260, (datetime.now()-timedelta(days=6)).strftime("%Y-%m-%d")),
            ("Pull-Up & Row Finisher",       "Back & Biceps",      50, 6800.0, 16, 250, (datetime.now()-timedelta(days=8)).strftime("%Y-%m-%d")),
        ])

    # Marcus_Beast — Platinum, 3780 XP — hypertrophy
    mid = get_uid("Marcus_Beast")
    if mid:
        add_workouts(mid, [
            ("Chest Hypertrophy Blast",      "Chest & Triceps",    55, 7400.0, 16, 260, yesterday_str),
            ("Back Width Builder",           "Back & Biceps",      60, 7900.0, 18, 270, two_days_ago),
            ("Leg Volume Session",           "Legs & Calves",      65, 9100.0, 18, 280, four_days_ago),
            ("Arm Annihilation",             "Arms",               45, 4200.0, 14, 220, (datetime.now()-timedelta(days=7)).strftime("%Y-%m-%d")),
        ])

    # Sarah_Lift — Platinum, 3610 XP — athletic conditioning
    sid = get_uid("Sarah_Lift")
    if sid:
        add_workouts(sid, [
            ("Full Body Athletic Circuit",   "Full Body",          50, 5600.0, 16, 250, yesterday_str),
            ("Lower Body Power Day",         "Legs & Calves",      55, 6800.0, 16, 240, two_days_ago),
            ("Upper Body Strength",          "Chest & Triceps",    45, 5100.0, 14, 230, four_days_ago),
            ("Core & Cardio Finisher",       "Shoulders & Core",   40, 3200.0, 12, 200, (datetime.now()-timedelta(days=6)).strftime("%Y-%m-%d")),
        ])

    # Elena_Blitz — Platinum, 3100 XP — fat loss & toning
    eid = get_uid("Elena_Blitz")
    if eid:
        add_workouts(eid, [
            ("Fat Burn HIIT Weights",        "Full Body",          45, 4400.0, 14, 220, yesterday_str),
            ("Toning Upper Body",            "Chest & Triceps",    40, 3800.0, 12, 200, two_days_ago),
            ("Glutes & Legs Tone",           "Legs & Calves",      50, 5200.0, 14, 230, four_days_ago),
        ])

    # Liam_Savage — Gold, 2750 XP — hypertrophy
    lid = get_uid("Liam_Savage")
    if lid:
        add_workouts(lid, [
            ("Push Day Volume",              "Chest & Triceps",    50, 6100.0, 14, 210, yesterday_str),
            ("Pull Day Strength",            "Back & Biceps",      55, 6700.0, 16, 220, two_days_ago),
            ("Leg Press Intensive",          "Legs & Calves",      60, 7800.0, 16, 230, four_days_ago),
        ])

    # Jordan_Swift — Gold, 2300 XP — cardio & hypertrophy
    jid = get_uid("Jordan_Swift")
    if jid:
        add_workouts(jid, [
            ("Cardio + Upper Body Mix",      "Full Body",          40, 3600.0, 12, 180, yesterday_str),
            ("Beginner Chest & Back",        "Chest & Triceps",    35, 3100.0, 10, 170, two_days_ago),
        ])

    # Maya_Pulse — Silver, 1950 XP — strength foundations
    mpid = get_uid("Maya_Pulse")
    if mpid:
        add_workouts(mpid, [
            ("Foundation Strength Day",      "Full Body",          35, 2800.0, 10, 160, yesterday_str),
            ("Beginner Lower Body",          "Legs & Calves",      30, 2400.0, 10, 150, two_days_ago),
        ])

    # Today's Active Workout Routine for Alex (11 of 18 sets completed, 7 remaining!)
    today_routine = [
        {
            "id": "ex_1",
            "name": "Barbell Incline Bench Press",
            "target_sets": 4,
            "muscle": "Upper Chest",
            "sets": [
                {"set_num": 1, "reps": 10, "weight_kg": 70, "completed": True},
                {"set_num": 2, "reps": 8, "weight_kg": 75, "completed": True},
                {"set_num": 3, "reps": 8, "weight_kg": 75, "completed": True},
                {"set_num": 4, "reps": 6, "weight_kg": 80, "completed": True}
            ]
        },
        {
            "id": "ex_2",
            "name": "Flat Dumbbell Press",
            "target_sets": 4,
            "muscle": "Mid Chest",
            "sets": [
                {"set_num": 1, "reps": 10, "weight_kg": 32, "completed": True},
                {"set_num": 2, "reps": 10, "weight_kg": 34, "completed": True},
                {"set_num": 3, "reps": 8, "weight_kg": 36, "completed": True},
                {"set_num": 4, "reps": 8, "weight_kg": 36, "completed": True}
            ]
        },
        {
            "id": "ex_3",
            "name": "Dips (Bodyweight + Chain)",
            "target_sets": 3,
            "muscle": "Lower Chest / Triceps",
            "sets": [
                {"set_num": 1, "reps": 12, "weight_kg": 10, "completed": True},
                {"set_num": 2, "reps": 10, "weight_kg": 15, "completed": True},
                {"set_num": 3, "reps": 10, "weight_kg": 15, "completed": True}
            ]
        },
        {
            "id": "ex_4",
            "name": "Cable Low-to-High Flyes",
            "target_sets": 4,
            "muscle": "Upper Clavicular Chest",
            "sets": [
                {"set_num": 1, "reps": 12, "weight_kg": 18, "completed": False},
                {"set_num": 2, "reps": 12, "weight_kg": 18, "completed": False},
                {"set_num": 3, "reps": 10, "weight_kg": 21, "completed": False},
                {"set_num": 4, "reps": 10, "weight_kg": 21, "completed": False}
            ]
        },
        {
            "id": "ex_5",
            "name": "Overhead Rope Tricep Extension",
            "target_sets": 3,
            "muscle": "Triceps Long Head",
            "sets": [
                {"set_num": 1, "reps": 12, "weight_kg": 25, "completed": False},
                {"set_num": 2, "reps": 12, "weight_kg": 25, "completed": False},
                {"set_num": 3, "reps": 10, "weight_kg": 28, "completed": False}
            ]
        }
    ]

    cursor.execute("""
        INSERT INTO daily_goals (user_id, date, target_sets, completed_sets, target_volume_kg, completed_volume_kg, target_duration_min, completed_duration_min, active_split_title, active_split_category, routine_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        alex_id,
        today_str,
        18, # 18 total sets planned
        11, # 11 sets completed
        6200, # target volume kg
        3880, # volume lifted so far
        60, # 60 min target
        38, # 38 min elapsed
        "Chest & Triceps Hypertrophy Crucible",
        "Chest & Triceps",
        json.dumps(today_routine)
    ))

    conn.commit()
    print("AthletiQ database seeded successfully with users, workouts, challenges, and daily progress!")

if __name__ == "__main__":
    init_db(force_reseed=True)
