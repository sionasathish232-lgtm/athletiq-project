/**
 * develop.js - "Develop Faster" Science & Hypertrophy Acceleration Suite
 */

const Develop = {
  init() {
    this.bindOverloadCalc();
    this.bindProteinCalc();
  },

  bindOverloadCalc() {
    const form = document.getElementById('overloadCalcForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const exerciseType = document.getElementById('calcExerciseType').value;
      const currentWeight = parseFloat(document.getElementById('calcCurrentWeight').value) || 60;
      const currentReps = parseInt(document.getElementById('calcCurrentReps').value) || 8;
      const rir = parseInt(document.getElementById('calcRir').value) || 1;

      // 1-Rep Max Estimate (Epley Formula)
      const oneRepMax = Math.round(currentWeight * (1 + currentReps / 30));

      let nextWeight = currentWeight;
      let nextReps = currentReps;
      let recommendation = '';
      let badge = 'STEADY OVERLOAD';

      if (exerciseType === 'compound') {
        if (currentReps >= 10 && rir >= 1) {
          // Add 2.5kg or 5kg
          nextWeight = currentWeight + 2.5;
          nextReps = 8;
          recommendation = `Increase load to <strong>${nextWeight} kg</strong> for 8 reps. Your strength is primed for micro-loading!`;
          badge = 'WEIGHT JUMP READY 🚀';
        } else if (currentReps < 8) {
          nextWeight = currentWeight;
          nextReps = currentReps + 1;
          recommendation = `Hold weight at <strong>${currentWeight} kg</strong> and aim for <strong>${nextReps} reps</strong> with strict 3-second eccentric tempo.`;
          badge = 'REP PROGRESSION ⚡';
        } else {
          nextWeight = currentWeight;
          nextReps = currentReps + 1;
          recommendation = `Great work. Push for <strong>${nextReps} clean reps</strong> next session before bumping the barbell weight.`;
        }
      } else {
        // Isolation
        if (currentReps >= 12) {
          nextWeight = currentWeight + 1.0;
          nextReps = 10;
          recommendation = `Bump dumbbell weight by 1–2 kg to <strong>${nextWeight} kg</strong> and hit 10 controlled reps.`;
          badge = 'WEIGHT JUMP READY 🚀';
        } else {
          nextReps = currentReps + 1;
          recommendation = `Keep <strong>${currentWeight} kg</strong> and focus on deep muscle stretch and pause at peak contraction.`;
          badge = 'TENSION PROGRESSION ⚡';
        }
      }

      const resultBox = document.getElementById('overloadResultBox');
      if (resultBox) {
        resultBox.style.display = 'block';
        resultBox.innerHTML = `
          <div class="science-card" style="border-left-color: var(--accent-neon); background: rgba(16, 185, 129, 0.08);">
            <span class="science-badge" style="background: rgba(16, 185, 129, 0.2); color: var(--accent-neon);">${badge}</span>
            <h4 style="font-size: 1.15rem; margin: 8px 0; color: #fff;">Next Session Blueprint</h4>
            <p style="font-size: 0.95rem; color: #cbd5e1; margin-bottom: 12px;">${recommendation}</p>
            <div style="display: flex; gap: 16px; flex-wrap: wrap; margin-top: 10px;">
              <div style="background: rgba(0,0,0,0.3); padding: 8px 14px; border-radius: 8px;">
                <span style="font-size: 0.75rem; color: #94a3b8; display: block;">Target Weight</span>
                <strong style="color: var(--accent-neon); font-size: 1.1rem;">${nextWeight} kg</strong>
              </div>
              <div style="background: rgba(0,0,0,0.3); padding: 8px 14px; border-radius: 8px;">
                <span style="font-size: 0.75rem; color: #94a3b8; display: block;">Target Reps</span>
                <strong style="color: var(--accent-cyan); font-size: 1.1rem;">${nextReps} reps</strong>
              </div>
              <div style="background: rgba(0,0,0,0.3); padding: 8px 14px; border-radius: 8px;">
                <span style="font-size: 0.75rem; color: #94a3b8; display: block;">Estimated 1RM</span>
                <strong style="color: var(--accent-gold); font-size: 1.1rem;">${oneRepMax} kg</strong>
              </div>
            </div>
          </div>
        `;
      }
    });
  },

  bindProteinCalc() {
    const form = document.getElementById('proteinCalcForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const weight = parseFloat(document.getElementById('macroWeight').value) || 75;
      const goal = document.getElementById('macroGoal').value;

      let proteinMultiplier = 2.0; // g per kg
      let calorieDelta = 300;
      let goalDesc = 'Lean Hypertrophy';

      if (goal === 'bulk') {
        proteinMultiplier = 2.0;
        calorieDelta = 400;
        goalDesc = 'Rapid Muscle Building (+400 kcal surplus)';
      } else if (goal === 'lean') {
        proteinMultiplier = 2.2;
        calorieDelta = 200;
        goalDesc = 'Lean Hypertrophy (+200 kcal surplus)';
      } else if (goal === 'cut') {
        proteinMultiplier = 2.4;
        calorieDelta = -450;
        goalDesc = 'Muscle-Sparing Fat Loss (-450 kcal deficit)';
      }

      const dailyProteinG = Math.round(weight * proteinMultiplier);
      const meals = 4;
      const proteinPerMeal = Math.round(dailyProteinG / meals);
      const estimatedMaintenance = Math.round(weight * 33);
      const targetCalories = estimatedMaintenance + calorieDelta;

      const resultBox = document.getElementById('proteinResultBox');
      if (resultBox) {
        resultBox.style.display = 'block';
        resultBox.innerHTML = `
          <div class="science-card" style="border-left-color: var(--accent-cyan); background: rgba(6, 182, 212, 0.08);">
            <span class="science-badge">ACCELERATION PROTOCOL: ${goalDesc}</span>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin: 16px 0;">
              <div style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: 10px; text-align: center;">
                <span style="font-size: 0.72rem; color: #94a3b8; text-transform: uppercase;">Daily Protein</span>
                <div style="font-size: 1.4rem; font-weight: 800; color: var(--accent-cyan);">${dailyProteinG}g</div>
                <span style="font-size: 0.75rem; color: #64748b;">(${proteinMultiplier}g / kg)</span>
              </div>
              <div style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: 10px; text-align: center;">
                <span style="font-size: 0.72rem; color: #94a3b8; text-transform: uppercase;">Per Meal (4 meals)</span>
                <div style="font-size: 1.4rem; font-weight: 800; color: var(--accent-neon);">${proteinPerMeal}g</div>
                <span style="font-size: 0.75rem; color: #64748b;">Max mTOR trigger</span>
              </div>
              <div style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: 10px; text-align: center;">
                <span style="font-size: 0.72rem; color: #94a3b8; text-transform: uppercase;">Target Calories</span>
                <div style="font-size: 1.4rem; font-weight: 800; color: var(--accent-gold);">${targetCalories}</div>
                <span style="font-size: 0.75rem; color: #64748b;">kcal / day</span>
              </div>
            </div>
            <p style="font-size: 0.85rem; color: #94a3b8; line-height: 1.4;">
              💡 <strong>Muscle Speed Tip:</strong> Consume ~3g of leucine per meal (found in whey, eggs, chicken, or beef) to trigger optimal Muscle Protein Synthesis (MPS) spikes.
            </p>
          </div>
        `;
      }
    });
  }
};

window.Develop = Develop;
