/**
 * auth.js - Mobile App Authentication, Registration, and Session Management for AthletiQ
 * Controls the dedicated mobile Login/Sign-up Gateway Screen
 */

const Auth = {
  currentUser: null,

  async init() {
    this.bindGatewayEvents();
    await this.checkSession();
  },

  bindGatewayEvents() {
    // 1. Gateway Segmented Tab Buttons (Sign In / Create Account / Forgot Password)
    document.querySelectorAll('.auth-segment-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const target = e.currentTarget.dataset.target;
        this.switchGatewayTab(target);
      });
    });

    // 2. Gateway Sign In Form Submit
    const loginForm = document.getElementById('gatewayLoginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const idInput   = document.getElementById('gatewayLoginId').value.trim();
        const passInput = document.getElementById('gatewayLoginPass').value.trim();
        const btn = loginForm.querySelector('button[type="submit"]');
        if (btn) { btn.textContent = 'Signing in...'; btn.disabled = true; }
        try {
          const res = await API.login(idInput, passInput);
          this.currentUser = res.user;
          // Existing users: skip onboarding, go straight to app
          this.showMainApp(res.user);
          showToast(`Welcome back, ${res.user.username}! 🔥`, 'success');
          if (window.App) window.App.loadAllData();
        } catch (err) {
          showToast(err.message || 'Login failed. Please check credentials.', 'error');
        } finally {
          if (btn) { btn.textContent = '🔥 SIGN IN TO ATHLETIQ'; btn.disabled = false; }
        }
      });
    }

    // 3. Gateway Register Form Submit — name, username, email, password
    const registerForm = document.getElementById('gatewayRegisterForm');
    if (registerForm) {
      registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const userData = {
          full_name: document.getElementById('gatewayRegName').value.trim(),
          username:  document.getElementById('gatewayRegUsername').value.trim(),
          email:     document.getElementById('gatewayRegEmail').value.trim(),
          password:  document.getElementById('gatewayRegPass').value.trim(),
          // Defaults — will be updated by onboarding wizard
          fitness_goal: 'build_muscle',
          experience_level: 'Intermediate',
          weight_kg: 70
        };
        const btn = registerForm.querySelector('button[type="submit"]');
        if (btn) { btn.textContent = 'Creating...'; btn.disabled = true; }
        try {
          const res = await API.register(userData);
          this.currentUser = res.user;
          showToast(`Account created! Let's set up your profile, ${res.user.username}! ⚡`, 'success');
          // NEW users → trigger animated onboarding wizard
          if (window.Onboarding) Onboarding.start();
        } catch (err) {
          showToast(err.message || 'Registration failed.', 'error');
        } finally {
          if (btn) { btn.textContent = '⚡ CREATE ACCOUNT'; btn.disabled = false; }
        }
      });
    }


    // 4. Gateway Forgot Password Form Submit
    const forgotForm = document.getElementById('gatewayForgotForm');
    if (forgotForm) {
      forgotForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email   = document.getElementById('gatewayForgotEmail').value.trim();
        const newPass = document.getElementById('gatewayForgotPass').value.trim();
        const secAns  = document.getElementById('gatewayForgotSecurity').value.trim();
        try {
          const res = await API.forgotPassword(email, newPass, secAns);
          showToast(res.message || 'Password successfully updated! You can now sign in.', 'success');
          this.switchGatewayTab('login');
          const loginId = document.getElementById('gatewayLoginId');
          if (loginId) loginId.value = email;
        } catch (err) {
          showToast(err.message || 'Reset failed.', 'error');
        }
      });
    }

    // 5. 1-Click Fast Demo Login Buttons (on Gateway screen)
    document.querySelectorAll('.demo-login-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const username = e.currentTarget.dataset.user || 'Alex_Forge';
        try {
          const res = await API.demoLogin(username);
          this.currentUser = res.user;
          this.showMainApp(res.user);
          showToast(`Logged in as ${username}! 🔥`, 'success');
          if (window.App) window.App.loadAllData();
        } catch (err) {
          showToast(err.message || 'Demo login failed.', 'error');
        }
      });
    });

    // 6. Main App Logout Button
    const logoutBtn = document.getElementById('mainLogoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', async () => {
        try {
          await API.logout();
        } catch (e) {
          console.warn('Logout request ignored:', e);
        }
        this.currentUser = null;
        this.showGateway();
        showToast('Logged out of AthletiQ.', 'info');
      });
    }
  },

  async checkSession() {
    try {
      const res = await API.getMe();
      if (res.authenticated && res.user) {
        this.currentUser = res.user;
        this.showMainApp(res.user);
        if (window.App) window.App.loadAllData();
      } else {
        this.showGateway();
      }
    } catch (err) {
      console.warn('Session check returned unauthenticated. Showing gateway.');
      this.showGateway();
    }
  },

  showGateway() {
    const gateway  = document.getElementById('authGatewayView');
    const mainApp  = document.getElementById('mainAppView');
    const wizard   = document.getElementById('onboardingWizard');
    if (gateway) gateway.style.display = 'flex';
    if (mainApp) mainApp.style.display = 'none';
    if (wizard)  wizard.style.display  = 'none';
  },

  showMainApp(user) {
    const gateway  = document.getElementById('authGatewayView');
    const mainApp  = document.getElementById('mainAppView');
    const wizard   = document.getElementById('onboardingWizard');
    if (gateway) gateway.style.display = 'none';
    if (wizard)  wizard.style.display  = 'none';
    if (mainApp) mainApp.style.display = 'block';
    this.updateNavUI(user);
  },

  switchGatewayTab(target) {
    document.querySelectorAll('.auth-segment-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.target === target);
    });

    const loginPanel  = document.getElementById('gatewayLoginPanel');
    const regPanel    = document.getElementById('gatewayRegisterPanel');
    const forgotPanel = document.getElementById('gatewayForgotPanel');

    if (loginPanel)  loginPanel.style.display  = (target === 'login')    ? 'block' : 'none';
    if (regPanel)    regPanel.style.display     = (target === 'register') ? 'block' : 'none';
    if (forgotPanel) forgotPanel.style.display  = (target === 'forgot')   ? 'block' : 'none';
  },

  updateNavUI(user) {
    if (!user) return;
    const nameEl   = document.getElementById('navUsername');
    const xpEl     = document.getElementById('navUserXp');
    const streakEl = document.getElementById('navUserStreak');
    const avatarEl = document.getElementById('navAvatar');
    const divEl    = document.getElementById('navDivision');

    if (nameEl)   nameEl.textContent   = user.username;
    if (xpEl)     xpEl.textContent     = `${(user.xp || 0).toLocaleString()} XP`;
    if (streakEl) streakEl.textContent  = `${user.current_streak || 1}d`;
    if (avatarEl) {
      avatarEl.textContent = user.username.charAt(0).toUpperCase();
      avatarEl.style.backgroundColor = user.avatar_color || '#ef233c';
    }
    if (divEl) {
      divEl.textContent  = user.division || 'Gold';
      divEl.className = `division-badge division-${user.division || 'Gold'}`;
    }
  }
};

window.Auth = Auth;
