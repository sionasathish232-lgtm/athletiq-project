/**
 * animations.js — AthletiQ Premium Animations & Effects
 * 1. Sparks particle background (login screen)
 * 4. Streak flame pulse
 * 6. Leaderboard rank badge pop
 * 7. Button ripple effect (all buttons)
 * 8. Tab switching slide transition
 * 10. Glassmorphism card upgrade
 * 12. Hover tilt effect on cards
 * 14. Skeleton loading screens
 */

const AthletiQAnimations = {

  init() {
    this.initSparks();
    this.initFlameStreak();
    this.initRipple();
    this.initHoverTilt();
    this.initCardEntrance();
    console.log('[AthletiQ] Animations initialized ✨');
  },

  // ================================================================
  // 1. SPARKS PARTICLE BACKGROUND — auth gateway login screen
  // ================================================================
  initSparks() {
    const canvas = document.getElementById('sparksCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const wrap = canvas.parentElement;
    const particles = [];

    const resize = () => {
      canvas.width  = wrap.offsetWidth  || window.innerWidth;
      canvas.height = wrap.offsetHeight || window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const rand = (a, b) => a + Math.random() * (b - a);

    class Spark {
      constructor() { this.reset(); }
      reset() {
        this.x     = rand(0, canvas.width);
        this.y     = canvas.height + rand(0, 20);
        this.vx    = rand(-0.6, 0.6);
        this.vy    = rand(-1.4, -0.5);
        this.life  = rand(0.6, 1);
        this.decay = rand(0.006, 0.016);
        this.size  = rand(1, 2.8);
        this.hue   = rand(0, 35); // red-orange range
      }
      update() {
        this.x    += this.vx;
        this.y    += this.vy;
        this.life -= this.decay;
        if (this.life <= 0) this.reset();
      }
      draw() {
        ctx.save();
        ctx.globalAlpha = this.life * 0.9;
        ctx.fillStyle   = `hsl(${this.hue},100%,62%)`;
        ctx.shadowBlur  = 10;
        ctx.shadowColor = `hsl(${this.hue},100%,55%)`;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    for (let i = 0; i < 70; i++) {
      const p = new Spark();
      p.y = rand(0, canvas.height); // scatter initially
      particles.push(p);
    }

    const loop = () => {
      if (!document.getElementById('sparksCanvas')) return; // stop if removed
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => { p.update(); p.draw(); });
      requestAnimationFrame(loop);
    };
    loop();
  },

  // ================================================================
  // 4. STREAK FLAME PULSE — applied to streak badge in top nav
  // ================================================================
  initFlameStreak() {
    const badge = document.querySelector('.streak-badge');
    if (!badge) return;
    // Wrap the flame emoji in a span with the pulse class
    const spans = badge.querySelectorAll('span');
    if (spans.length > 0) {
      spans[0].classList.add('flame-pulse');
      // Add the glow ring element
      if (!badge.querySelector('.streak-glow-ring')) {
        const ring = document.createElement('div');
        ring.className = 'streak-glow-ring';
        badge.style.position = 'relative';
        badge.appendChild(ring);
      }
    }
  },

  // ================================================================
  // 6. LEADERBOARD RANK BADGE POP — called when leaderboard loads
  // ================================================================
  animateLeaderboardRows() {
    const rows = document.querySelectorAll('#leaderboardTableBody tr, .podium-slot');
    rows.forEach(row => {
      row.classList.remove('lb-pop-visible');
      row.classList.add('lb-pop-hidden');
    });
    rows.forEach((row, i) => {
      setTimeout(() => {
        row.classList.remove('lb-pop-hidden');
        row.classList.add('lb-pop-visible');
      }, i * 90 + 60);
    });
    // Also animate podium rank numbers
    document.querySelectorAll('.podium-rank-num').forEach((el, i) => {
      el.style.transform = 'scale(0)';
      el.style.transition = 'none';
      setTimeout(() => {
        el.style.transition = `transform 0.5s cubic-bezier(0.34,1.56,0.64,1) ${i * 120}ms`;
        el.style.transform  = 'scale(1)';
      }, 150);
    });
  },

  // ================================================================
  // 7. BUTTON RIPPLE EFFECT — applied to all buttons globally
  // ================================================================
  initRipple() {
    const applyRipple = (btn) => {
      if (btn.dataset.ripple) return;
      btn.dataset.ripple = '1';
      btn.style.position = 'relative';
      btn.style.overflow = 'hidden';
      btn.addEventListener('click', (e) => {
        const rect  = btn.getBoundingClientRect();
        const x     = e.clientX - rect.left;
        const y     = e.clientY - rect.top;
        const size  = Math.max(rect.width, rect.height) * 2;
        const wave  = document.createElement('span');
        wave.className = 'ripple-wave-effect';
        wave.style.cssText = `
          width:${size}px; height:${size}px;
          left:${x - size/2}px; top:${y - size/2}px;
          position:absolute; border-radius:50%;
          background:rgba(255,255,255,0.28);
          transform:scale(0); animation:rippleExpand 0.55s ease-out forwards;
          pointer-events:none; z-index:99;
        `;
        btn.appendChild(wave);
        setTimeout(() => wave.remove(), 600);
      });
    };

    // Apply to all existing buttons
    document.querySelectorAll('.btn, button:not(.ob-btn):not(.tab-btn-anim)').forEach(applyRipple);

    // Watch for dynamically added buttons (leaderboard rows, workout cards, etc.)
    const observer = new MutationObserver(() => {
      document.querySelectorAll('.btn, button:not(.ob-btn)').forEach(applyRipple);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  },

  // ================================================================
  // 8. TAB SWITCHING SLIDE — upgrade switchTab to use slide animation
  // ================================================================
  patchTabSlide() {
    const tabOrder = ['dashboard', 'workouts', 'leaderboard', 'story', 'develop'];

    const originalSwitch = window.App?.switchTab?.bind(window.App);
    if (!originalSwitch) return;

    window.App.switchTab = function(tabName) {
      const oldTab  = this.activeTab;
      const oldIdx  = tabOrder.indexOf(oldTab);
      const newIdx  = tabOrder.indexOf(tabName);
      const dir     = newIdx > oldIdx ? 1 : -1;

      const oldView = document.getElementById(`${oldTab}View`);
      const newView = document.getElementById(`${tabName}View`);

      // Update nav active states immediately
      this.activeTab = tabName;
      document.querySelectorAll('.nav-tab-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.tab === tabName);
      });
      document.querySelectorAll('.mobile-nav-item').forEach(b => {
        b.classList.toggle('active', b.dataset.tab === tabName);
      });

      if (oldTab === tabName || !oldView || !newView) {
        // No animation needed — just show/hide
        document.querySelectorAll('.tab-view').forEach(v => {
          v.style.display = (v.id === `${tabName}View`) ? 'block' : 'none';
        });
        return;
      }

      // Animate old view out
      oldView.style.display = 'block';
      oldView.style.position = 'absolute';
      oldView.style.width = '100%';
      oldView.style.animation = `slideTabOut${dir > 0 ? 'Left' : 'Right'} 0.28s cubic-bezier(0.4,0,1,1) forwards`;

      // Prepare new view
      newView.style.display = 'block';
      newView.style.position = 'absolute';
      newView.style.width = '100%';
      newView.style.animation = `slideTabIn${dir > 0 ? 'Right' : 'Left'} 0.3s cubic-bezier(0,0,0.2,1) forwards`;

      setTimeout(() => {
        oldView.style.display  = 'none';
        oldView.style.position = '';
        oldView.style.animation = '';
        newView.style.position = '';
        newView.style.animation = '';
      }, 310);

      // Story card re-render
      if (tabName === 'story' && window.StoryCard) window.StoryCard.render();
      // Trigger leaderboard badge pop
      if (tabName === 'leaderboard') {
        setTimeout(() => AthletiQAnimations.animateLeaderboardRows(), 200);
      }
    };
  },

  // ================================================================
  // 10. GLASSMORPHISM — upgrade .card elements
  // ================================================================
  applyGlassmorphism() {
    document.querySelectorAll('.card').forEach(card => {
      if (!card.dataset.glass) {
        card.dataset.glass = '1';
        card.classList.add('glass-card-effect');
      }
    });
    // Watch for dynamic cards
    const observer = new MutationObserver(() => {
      document.querySelectorAll('.card:not([data-glass])').forEach(card => {
        card.dataset.glass = '1';
        card.classList.add('glass-card-effect');
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  },

  // ================================================================
  // 12. HOVER TILT — 3D tilt for .card elements
  // ================================================================
  initHoverTilt() {
    const applyTilt = (card) => {
      if (card.dataset.tilt) return;
      card.dataset.tilt = '1';
      card.addEventListener('mousemove', (e) => {
        const rect  = card.getBoundingClientRect();
        const cx    = rect.left + rect.width / 2;
        const cy    = rect.top  + rect.height / 2;
        const dx    = (e.clientX - cx) / (rect.width  / 2);
        const dy    = (e.clientY - cy) / (rect.height / 2);
        const rotX  = -dy * 7;
        const rotY  =  dx * 7;
        card.style.transform  = `perspective(700px) rotateX(${rotX}deg) rotateY(${rotY}deg) scale(1.01)`;
        card.style.boxShadow  = `${-rotY * 3}px ${rotX * 2}px 28px rgba(239,35,60,0.2), var(--shadow-card)`;
        card.style.transition = 'box-shadow 0.1s ease';
      });
      card.addEventListener('mouseleave', () => {
        card.style.transition = 'transform 0.4s cubic-bezier(0.16,1,0.3,1), box-shadow 0.4s ease';
        card.style.transform  = '';
        card.style.boxShadow  = '';
        setTimeout(() => { card.style.transition = ''; }, 400);
      });
    };

    document.querySelectorAll('.card').forEach(applyTilt);
    const observer = new MutationObserver(() => {
      document.querySelectorAll('.card:not([data-tilt])').forEach(applyTilt);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  },

  // ================================================================
  // 14. SKELETON LOADING — show skeleton before dashboard data loads
  // ================================================================
  showDashboardSkeleton() {
    const container = document.getElementById('dashboardView');
    if (!container) return;

    const skeletonHTML = `
      <div id="dashSkeleton" class="dash-skeleton">
        <div class="skel-hero">
          <div class="skel skel-title-lg"></div>
          <div class="skel skel-subtitle"></div>
          <div class="skel-stats-row">
            <div class="skel skel-stat-box"></div>
            <div class="skel skel-stat-box" style="animation-delay:0.12s"></div>
            <div class="skel skel-stat-box" style="animation-delay:0.24s"></div>
          </div>
        </div>
        <div class="skel-card-wrap">
          <div class="skel skel-heading"></div>
          <div class="skel-row"><div class="skel skel-circle"></div><div class="skel-lines"><div class="skel skel-line-w80"></div><div class="skel skel-line-w60" style="animation-delay:0.1s"></div></div></div>
          <div class="skel-row" style="animation-delay:0.1s"><div class="skel skel-circle" style="animation-delay:0.1s"></div><div class="skel-lines"><div class="skel skel-line-w70" style="animation-delay:0.1s"></div><div class="skel skel-line-w50" style="animation-delay:0.2s"></div></div></div>
          <div class="skel-row" style="animation-delay:0.2s"><div class="skel skel-circle" style="animation-delay:0.2s"></div><div class="skel-lines"><div class="skel skel-line-w90" style="animation-delay:0.2s"></div><div class="skel skel-line-w40" style="animation-delay:0.3s"></div></div></div>
        </div>
      </div>
    `;

    // Hide real content temporarily
    const rival = document.getElementById('rivalAlertContainer');
    const hero  = document.querySelector('.hero-progress-banner');
    const routineCard = document.querySelector('.active-routine-card');
    const grid2 = document.querySelector('#dashboardView .grid-2');

    [rival, hero, routineCard, grid2].forEach(el => { if (el) el.style.visibility = 'hidden'; });

    const existing = document.getElementById('dashSkeleton');
    if (!existing) container.insertAdjacentHTML('afterbegin', skeletonHTML);
  },

  hideDashboardSkeleton() {
    const skel = document.getElementById('dashSkeleton');
    if (skel) {
      skel.classList.add('skel-fade-out');
      setTimeout(() => skel.remove(), 400);
    }
    // Reveal real content with stagger entrance
    const rival = document.getElementById('rivalAlertContainer');
    const hero  = document.querySelector('.hero-progress-banner');
    const routineCard = document.querySelector('.active-routine-card');
    const grid2 = document.querySelector('#dashboardView .grid-2');

    [rival, hero, routineCard, grid2].forEach((el, i) => {
      if (!el) return;
      el.style.visibility = '';
      el.style.opacity = '0';
      el.style.transform = 'translateY(16px)';
      el.style.transition = `opacity 0.4s ease ${i * 90}ms, transform 0.4s cubic-bezier(0.16,1,0.3,1) ${i * 90}ms`;
      setTimeout(() => {
        el.style.opacity = '1';
        el.style.transform = '';
      }, 50 + i * 90);
    });
  },

  // ================================================================
  // Card entrance stagger (bonus: triggered on tab switch)
  // ================================================================
  initCardEntrance() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          const el = entry.target;
          el.style.animationDelay = `${i * 60}ms`;
          el.classList.add('card-enter');
          observer.unobserve(el);
        }
      });
    }, { threshold: 0.1 });

    // Observe dynamically added cards
    const mo = new MutationObserver(() => {
      document.querySelectorAll('.card:not(.card-enter):not([data-observed])').forEach(card => {
        card.dataset.observed = '1';
        observer.observe(card);
      });
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }
};

window.AthletiQAnimations = AthletiQAnimations;

// Auto-init once DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  AthletiQAnimations.init();
  // Patch tab slide after App is ready
  setTimeout(() => AthletiQAnimations.patchTabSlide(), 200);
});
