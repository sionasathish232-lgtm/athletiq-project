/**
 * app.js - Main Application Controller for TitanFit
 */

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  let icon = '⚡';
  if (type === 'success') icon = '✅';
  if (type === 'error') icon = '❌';
  if (type === 'streak') icon = '🔥';
  toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
window.showToast = showToast;

const App = {
  activeTab: 'dashboard',
  quotes: [],
  currentQuoteIndex: 0,
  dashboardData: null,

  async init() {
    this.bindNavigation();
    this.bindModals();
    this.bindWorkoutLogger();
    this.bindSeedReset();
    
    // Init Auth
    await window.Auth.init();
    
    // Load initial data
    await this.loadAllData();

    // Init Story Generator and Develop modules
    if (window.StoryCard) window.StoryCard.init();
    if (window.Develop) window.Develop.init();
  },

  bindNavigation() {
    // Desktop Nav Tabs
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tab = e.currentTarget.dataset.tab;
        this.switchTab(tab);
      });
    });

    // Mobile Bottom Bar Tabs
    document.querySelectorAll('.mobile-nav-item').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tab = e.currentTarget.dataset.tab;
        this.switchTab(tab);
      });
    });

    // Motivational Pill in Nav click
    const quotePill = document.getElementById('navMotivationPill');
    if (quotePill) {
      quotePill.addEventListener('click', () => {
        this.cycleQuote();
      });
    }

    // Direct links to open auth gateway / profile
    const profileBtn = document.getElementById('userProfileBtn');
    if (profileBtn) {
      profileBtn.addEventListener('click', () => {
        if (window.Auth) {
          window.Auth.showGateway();
        }
      });
    }

    // Mobile App Frame Toggle on Desktop
    const mobileToggleBtn = document.getElementById('mobileViewToggleBtn');
    if (mobileToggleBtn) {
      mobileToggleBtn.addEventListener('click', () => {
        const container = document.getElementById('appMainContainer');
        if (container) {
          container.classList.toggle('mobile-frame-mode');
          const isMobile = container.classList.contains('mobile-frame-mode');
          mobileToggleBtn.textContent = isMobile ? '🖥️ Desktop Mode' : '📱 Mobile Mode';
          showToast(isMobile ? 'Switched to Mobile App frame' : 'Switched to Full Desktop layout', 'info');
        }
      });
    }
  },

  switchTab(tabName) {
    this.activeTab = tabName;
    document.querySelectorAll('.nav-tab-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === tabName);
    });
    document.querySelectorAll('.mobile-nav-item').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === tabName);
    });
    document.querySelectorAll('.tab-view').forEach(view => {
      view.style.display = (view.id === `${tabName}View`) ? 'block' : 'none';
    });

    if (tabName === 'story' && window.StoryCard) {
      window.StoryCard.render();
    }
  },

  cycleQuote() {
    if (!this.quotes.length) return;
    this.currentQuoteIndex = (this.currentQuoteIndex + 1) % this.quotes.length;
    const q = this.quotes[this.currentQuoteIndex];
    const textEl = document.getElementById('motivationText');
    if (textEl) textEl.textContent = q;

    // Update in story card as well
    if (window.StoryCard) {
      const qInput = document.getElementById('storyQuoteInput');
      if (qInput) qInput.value = q;
      window.StoryCard.customQuote = q;
      window.StoryCard.render();
    }
  },

  async loadAllData() {
    // Show skeleton loading screen before fetch
    if (window.AthletiQAnimations) AthletiQAnimations.showDashboardSkeleton();

    try {
      const data = await API.getDashboard();
      this.dashboardData = data;
      this.quotes = data.quotes || [];
      if (this.quotes.length > 0) {
        const textEl = document.getElementById('motivationText');
        if (textEl) textEl.textContent = this.quotes[0];
      }

      this.renderDashboard(data);
      this.renderLeaderboardView();
      this.renderWorkoutsView();
      this.renderChallengesView();
      this.renderAchievementsView();

      // Hide skeleton and reveal content with stagger animation
      if (window.AthletiQAnimations) {
        AthletiQAnimations.hideDashboardSkeleton();
        AthletiQAnimations.applyGlassmorphism();
      }

      // Animate leaderboard on first load
      setTimeout(() => {
        if (window.AthletiQAnimations) AthletiQAnimations.animateLeaderboardRows();
      }, 300);

    } catch (err) {
      console.error('Failed to load dashboard data:', err);
      if (window.AthletiQAnimations) AthletiQAnimations.hideDashboardSkeleton();
    }
  },


  renderDashboard(data) {
    const today = data.today;
    const user = data.user;
    const competition = data.competition;

    // 1. Gauge and remaining workout metrics
    const circumference = 2 * Math.PI * 52; // r = 52
    const offset = circumference - (today.sets_percentage / 100) * circumference;
    const gaugeCircle = document.getElementById('gaugeCircle');
    if (gaugeCircle) {
      gaugeCircle.style.strokeDasharray = `${circumference} ${circumference}`;
      gaugeCircle.style.strokeDashoffset = offset;
    }

    const gaugePct = document.getElementById('gaugePercentage');
    if (gaugePct) gaugePct.textContent = `${Math.round(today.sets_percentage)}%`;

    const remSetsEl = document.getElementById('remainingSetsVal');
    if (remSetsEl) remSetsEl.textContent = `${today.remaining_sets} sets left`;

    const doneSetsEl = document.getElementById('completedSetsVal');
    if (doneSetsEl) doneSetsEl.textContent = `${today.completed_sets} / ${today.target_sets}`;

    const remVolEl = document.getElementById('remainingVolumeVal');
    if (remVolEl) remVolEl.textContent = `${today.remaining_volume_kg.toLocaleString()} kg left`;

    const routineTitleEl = document.getElementById('routineSplitTitle');
    if (routineTitleEl) routineTitleEl.textContent = today.title;

    const routineCategoryEl = document.getElementById('routineSplitCategory');
    if (routineCategoryEl) routineCategoryEl.textContent = today.category;

    // 2. Rival Alert Gap Banner
    const rivalAlert = document.getElementById('rivalAlertContainer');
    if (rivalAlert) {
      if (competition.rival_ahead) {
        const r = competition.rival_ahead;
        rivalAlert.style.display = 'flex';
        rivalAlert.innerHTML = `
          <div class="rival-alert-info">
            <div class="rival-avatar">${r.username.charAt(0).toUpperCase()}</div>
            <div class="rival-text">
              <h4>Target to Beat: @${r.username} (Rank #${r.rank})</h4>
              <p>You are only <strong>${r.xp_ahead} XP</strong> behind. ${r.workouts_needed} workout session away from taking the lead!</p>
            </div>
          </div>
          <div class="rival-badge-gap">
            ⚡ +${r.xp_ahead} XP to Overtake
          </div>
        `;
      } else {
        // You are #1!
        rivalAlert.style.display = 'flex';
        rivalAlert.style.background = 'linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(16, 185, 129, 0.1))';
        rivalAlert.style.borderColor = 'var(--accent-gold)';
        rivalAlert.innerHTML = `
          <div class="rival-alert-info">
            <div class="rival-avatar" style="background: var(--accent-gold);">👑</div>
            <div class="rival-text">
              <h4 style="color: var(--accent-gold);">You Hold Rank #1 on the Podium!</h4>
              <p>You are the reigning division champion. Keep lifting to preserve your crown.</p>
            </div>
          </div>
          <div class="rival-badge-gap" style="background: rgba(245, 158, 11, 0.2); border-color: var(--accent-gold); color: #fde68a;">
            🔥 CHAMPION STATUS
          </div>
        `;
      }
    }

    // 3. Render Today's Interactive Checklist
    this.renderRoutineChecklist(today.routine);

    // 4. Render Recent Workouts Mini Feed
    const feedContainer = document.getElementById('recentWorkoutsFeed');
    if (feedContainer) {
      if (!data.recent_workouts || data.recent_workouts.length === 0) {
        feedContainer.innerHTML = `<p style="color: var(--text-muted); font-size: 0.9rem;">No workouts logged yet. Start your first session above!</p>`;
      } else {
        feedContainer.innerHTML = data.recent_workouts.map(w => `
          <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle); border-radius: 12px; padding: 14px 18px; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between;">
            <div>
              <div style="font-weight: 700; font-size: 0.95rem;">${w.title}</div>
              <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 2px;">
                ${w.category} • ${w.sets_completed} sets • ${w.duration_min} min • ${w.date}
              </div>
            </div>
            <div style="text-align: right;">
              <div style="font-weight: 800; color: var(--accent-neon); font-size: 0.95rem;">${w.total_volume_kg.toLocaleString()} kg</div>
              <div style="font-size: 0.75rem; color: var(--accent-cyan); font-weight: 700;">+${w.xp_earned} XP</div>
            </div>
          </div>
        `).join('');
      }
    }
  },

  renderRoutineChecklist(routine) {
    const listEl = document.getElementById('todayRoutineList');
    if (!listEl) return;

    if (!routine || routine.length === 0) {
      listEl.innerHTML = `<p style="color: var(--text-muted);">All sets finished for today! Amazing work.</p>`;
      return;
    }

    listEl.innerHTML = routine.map(ex => `
      <div class="routine-exercise-item">
        <div class="exercise-header">
          <div>
            <span class="exercise-name">${ex.name}</span>
            <span style="font-size: 0.8rem; color: var(--text-secondary); margin-left: 8px;">(${ex.target_sets} sets)</span>
          </div>
          <span class="exercise-muscle-tag">${ex.muscle || 'Compound'}</span>
        </div>
        <div class="sets-pill-grid">
          ${ex.sets.map(s => `
            <button class="set-check-btn ${s.completed ? 'completed' : ''}" 
                    data-exercise="${ex.id}" 
                    data-set="${s.set_num}" 
                    data-completed="${s.completed}">
              <span class="checkbox-indicator">${s.completed ? '✓' : ''}</span>
              <span>Set ${s.set_num}: ${s.weight_kg}kg × ${s.reps}</span>
            </button>
          `).join('')}
        </div>
      </div>
    `).join('');

    // Attach click listeners to each set button
    listEl.querySelectorAll('.set-check-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const btnEl = e.currentTarget;
        const exId = btnEl.dataset.exercise;
        const setNum = parseInt(btnEl.dataset.set);
        const currentCompleted = btnEl.dataset.completed === 'true';
        const newCompleted = !currentCompleted;

        try {
          const res = await API.toggleRoutineSet(exId, setNum, newCompleted);
          if (newCompleted) {
            showToast(`Set ${setNum} completed! +25 XP earned!`, 'success');
          } else {
            showToast(`Set ${setNum} marked incomplete.`, 'info');
          }
          await this.loadAllData();
        } catch (err) {
          showToast('Failed to update set status', 'error');
        }
      });
    });
  },

  async renderLeaderboardView() {
    try {
      const res = await API.getLeaderboard();
      const leaders = res.leaderboard || [];

      // 1. Podium (Top 3)
      const podiumEl = document.getElementById('podiumSlotsContainer');
      if (podiumEl && leaders.length >= 3) {
        const first = leaders[0];
        const second = leaders[1];
        const third = leaders[2];

        podiumEl.innerHTML = `
          <!-- Rank 2 -->
          <div class="podium-slot slot-2">
            <div class="podium-avatar" style="background: ${second.avatar_color || '#3b82f6'};">
              ${second.username.charAt(0).toUpperCase()}
            </div>
            <strong style="font-size: 0.95rem;">${second.username}</strong>
            <span style="font-size: 0.8rem; color: #94a3b8;">${second.xp.toLocaleString()} XP</span>
            <div class="podium-block">2</div>
          </div>

          <!-- Rank 1 -->
          <div class="podium-slot slot-1">
            <div class="podium-avatar" style="background: ${first.avatar_color || '#f59e0b'};">
              <span class="crown-icon">👑</span>
              ${first.username.charAt(0).toUpperCase()}
            </div>
            <strong style="font-size: 1.05rem; color: var(--accent-gold);">${first.username}</strong>
            <span style="font-size: 0.85rem; color: #fde68a;">${first.xp.toLocaleString()} XP</span>
            <div class="podium-block">1</div>
          </div>

          <!-- Rank 3 -->
          <div class="podium-slot slot-3">
            <div class="podium-avatar" style="background: ${third.avatar_color || '#ec4899'};">
              ${third.username.charAt(0).toUpperCase()}
            </div>
            <strong style="font-size: 0.95rem;">${third.username}</strong>
            <span style="font-size: 0.8rem; color: #94a3b8;">${third.xp.toLocaleString()} XP</span>
            <div class="podium-block">3</div>
          </div>
        `;
      }

      // 2. Full Table
      const tableBody = document.getElementById('leaderboardTableBody');
      if (tableBody) {
        tableBody.innerHTML = leaders.map(u => `
          <tr class="leader-row ${u.is_current_user ? 'highlight-user' : ''}">
            <td class="leader-cell">
              ${u.rank === 1 ? '🥇' : u.rank === 2 ? '🥈' : u.rank === 3 ? '🥉' : `#${u.rank}`}
            </td>
            <td class="leader-cell">
              <div class="user-cell-meta">
                <div class="user-avatar-circle" style="background-color: ${u.avatar_color || '#10b981'};">
                  ${u.username.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div style="font-weight: 700; display: flex; align-items: center; gap: 8px;">
                    ${u.username}
                    ${u.is_current_user ? '<span style="font-size: 0.7rem; background: var(--accent-lime); color: #000; padding: 2px 6px; border-radius: 4px; font-weight: 800;">YOU</span>' : ''}
                  </div>
                  <div style="font-size: 0.75rem; color: var(--text-muted);">
                    ${u.fitness_goal} • ${u.workouts_completed} workouts
                  </div>
                </div>
              </div>
            </td>
            <td class="leader-cell">
              <span class="division-badge division-${u.division}">${u.division}</span>
            </td>
            <td class="leader-cell" style="color: var(--accent-gold); font-weight: 700;">
              🔥 ${u.streak}d
            </td>
            <td class="leader-cell" style="color: var(--text-secondary);">
              ${u.total_volume.toLocaleString()} kg
            </td>
            <td class="leader-cell" style="font-weight: 800; color: var(--accent-neon); font-size: 1rem;">
              ${u.xp.toLocaleString()} XP
            </td>
          </tr>
        `).join('');
      }

      // 3. Gap Details in Leaderboard Tab
      const gapBox = document.getElementById('leaderboardGapNotice');
      if (gapBox && res.rival_ahead) {
        gapBox.innerHTML = `
          <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 12px; padding: 14px 20px; display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <span style="font-size: 24px;">⚔️</span>
              <div>
                <strong>Next Target: @${res.rival_ahead.username} (Rank #${res.rival_ahead.rank})</strong>
                <div style="font-size: 0.85rem; color: var(--text-secondary);">${res.rival_ahead.tip}</div>
              </div>
            </div>
            <div style="font-weight: 800; color: #fca5a5; font-size: 0.95rem; white-space: nowrap;">
              -${res.rival_ahead.xp_gap} XP Behind
            </div>
          </div>
        `;
      }
    } catch (err) {
      console.error('Failed to load leaderboard:', err);
    }
  },

  async renderWorkoutsView() {
    try {
      const res = await API.getWorkouts();
      const workouts = res.workouts || [];
      const container = document.getElementById('workoutsHistoryList');
      if (!container) return;

      if (workouts.length === 0) {
        container.innerHTML = `<p style="color: var(--text-muted); text-align: center; padding: 40px;">No workout history found yet. Log a workout to start building muscle memory!</p>`;
        return;
      }

      container.innerHTML = workouts.map(w => `
        <div class="card" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
            <div>
              <div style="display: flex; align-items: center; gap: 10px;">
                <h3 style="font-size: 1.15rem; font-weight: 800;">${w.title}</h3>
                <span class="exercise-muscle-tag">${w.category}</span>
              </div>
              <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 4px;">
                🗓️ ${w.date} • ⏱️ ${w.duration_min} minutes • 🏋️ ${w.sets_completed} total sets
              </div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 1.25rem; font-weight: 800; color: var(--accent-neon);">${w.total_volume_kg.toLocaleString()} kg</div>
              <div style="font-size: 0.8rem; color: var(--accent-cyan); font-weight: 700;">+${w.xp_earned} XP EARNED</div>
            </div>
          </div>
          
          ${w.notes ? `<p style="font-size: 0.88rem; color: #cbd5e1; background: rgba(0,0,0,0.25); padding: 8px 12px; border-radius: 8px; margin-bottom: 12px;">💬 ${w.notes}</p>` : ''}

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px;">
            ${(w.exercises || []).map(ex => `
              <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--border-subtle); border-radius: 8px; padding: 10px;">
                <strong style="font-size: 0.88rem; display: block; margin-bottom: 6px;">${ex.name}</strong>
                <div style="font-size: 0.78rem; color: var(--text-secondary);">
                  ${ex.sets.map(s => `Set ${s.set_num}: ${s.weight_kg}kg × ${s.reps}`).join('<br>')}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      `).join('');
    } catch (err) {
      console.error('Failed to load workouts:', err);
    }
  },

  async renderChallengesView() {
    try {
      const res = await API.getChallenges();
      const container = document.getElementById('challengesGrid');
      if (!container) return;

      container.innerHTML = res.challenges.map(c => `
        <div class="card" style="display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <span style="font-size: 2rem;">${c.badge_icon}</span>
              <span class="science-badge" style="background: rgba(245, 158, 11, 0.15); color: var(--accent-gold);">+${c.reward_xp} XP</span>
            </div>
            <h4 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 6px;">${c.title}</h4>
            <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 16px;">${c.description}</p>
          </div>

          <div>
            <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; margin-bottom: 6px;">
              <span>Progress</span>
              <span style="color: var(--accent-neon);">${c.user_progress.toLocaleString()} / ${c.target_value.toLocaleString()} ${c.unit} (${c.progress_pct}%)</span>
            </div>
            <div style="background: rgba(255,255,255,0.1); border-radius: var(--radius-full); height: 8px; overflow: hidden; margin-bottom: 14px;">
              <div style="background: linear-gradient(90deg, var(--accent-lime), var(--accent-neon)); height: 100%; width: ${c.progress_pct}%; transition: width 0.4s ease;"></div>
            </div>

            ${!c.is_joined ? `
              <button class="btn btn-outline btn-sm join-challenge-btn" data-id="${c.id}" style="width: 100%;">
                Join Challenge
              </button>
            ` : c.is_joined_and_completed ? `
              <div style="text-align: center; color: var(--accent-gold); font-weight: 700; font-size: 0.85rem;">
                🏆 Challenge Conquered!
              </div>
            ` : `
              <div style="display: flex; gap: 8px;">
                <button class="btn btn-secondary btn-sm push-chal-btn" data-id="${c.id}" data-amt="50" style="flex: 1;">
                  +50 Progress
                </button>
                <button class="btn btn-primary btn-sm push-chal-btn" data-id="${c.id}" data-amt="100" style="flex: 1;">
                  +100 Progress
                </button>
              </div>
            `}
          </div>
        </div>
      `).join('');

      // Bind Join Buttons
      container.querySelectorAll('.join-challenge-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          const cid = e.currentTarget.dataset.id;
          await API.joinChallenge(cid);
          showToast('Joined challenge! Let the gains begin.', 'success');
          this.loadAllData();
        });
      });

      // Bind Add Progress Buttons
      container.querySelectorAll('.push-chal-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          const cid = e.currentTarget.dataset.id;
          const amt = parseInt(e.currentTarget.dataset.amt);
          const res = await API.addChallengeProgress(cid, amt);
          if (res.is_completed) {
            showToast(`🏆 Challenge completed! +${res.reward_xp} XP awarded!`, 'success');
          } else {
            showToast(`+${amt} added to challenge progress!`, 'info');
          }
          this.loadAllData();
        });
      });
    } catch (err) {
      console.error('Failed to load challenges:', err);
    }
  },

  async renderAchievementsView() {
    try {
      const res = await API.getAchievements();
      const container = document.getElementById('achievementsList');
      if (!container) return;

      container.innerHTML = res.achievements.map(a => `
        <div style="display: flex; align-items: center; gap: 16px; background: ${a.unlocked ? 'rgba(16, 185, 129, 0.08)' : 'rgba(255,255,255,0.02)'}; border: 1px solid ${a.unlocked ? 'rgba(16, 185, 129, 0.3)' : 'var(--border-subtle)'}; border-radius: 12px; padding: 14px 18px; margin-bottom: 10px;">
          <div style="font-size: 2.2rem; filter: ${a.unlocked ? 'none' : 'grayscale(100%) opacity(40%)'};">
            ${a.icon}
          </div>
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <strong style="font-size: 0.95rem; color: ${a.unlocked ? '#fff' : '#64748b'};">${a.title}</strong>
              ${a.unlocked ? '<span style="font-size: 0.68rem; background: var(--accent-lime); color: #000; font-weight: 800; padding: 2px 6px; border-radius: 4px;">UNLOCKED</span>' : '<span style="font-size: 0.68rem; background: rgba(255,255,255,0.1); color: #94a3b8; padding: 2px 6px; border-radius: 4px;">LOCKED</span>'}
            </div>
            <p style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 2px;">${a.description}</p>
          </div>
          <div style="font-weight: 800; color: ${a.unlocked ? 'var(--accent-gold)' : '#64748b'}; font-size: 0.85rem;">
            +${a.xp_reward} XP
          </div>
        </div>
      `).join('');
    } catch (err) {
      console.error('Failed to load achievements:', err);
    }
  },

  bindModals() {
    // Open Workout Modal
    const openWorkoutBtn = document.getElementById('openLogWorkoutModalBtn');
    const modal = document.getElementById('logWorkoutModal');
    const closeBtn = document.getElementById('closeWorkoutModalBtn');

    if (openWorkoutBtn && modal) {
      openWorkoutBtn.addEventListener('click', () => {
        modal.classList.add('active');
      });
    }

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
      });
    }

    // Close on overlay click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('active');
        }
      });
    });
  },

  bindWorkoutLogger() {
    const form = document.getElementById('fullWorkoutForm');
    const addExerciseBtn = document.getElementById('addExerciseRowBtn');
    const exerciseList = document.getElementById('newWorkoutExerciseRows');

    if (addExerciseBtn && exerciseList) {
      addExerciseBtn.addEventListener('click', () => {
        const rowCount = exerciseList.children.length + 1;
        const row = document.createElement('div');
        row.className = 'form-group';
        row.style.background = 'rgba(255,255,255,0.03)';
        row.style.padding = '12px';
        row.style.borderRadius = '8px';
        row.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <label class="form-label" style="margin: 0;">Exercise #${rowCount}</label>
            <button type="button" class="btn btn-outline btn-sm remove-ex-btn" style="padding: 2px 8px; font-size: 0.7rem;">Remove</button>
          </div>
          <input type="text" class="form-control ex-name-input" placeholder="e.g. Barbell Squat" required style="margin-bottom: 8px;">
          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px;">
            <div>
              <span style="font-size: 0.72rem; color: #94a3b8;">Sets</span>
              <input type="number" class="form-control ex-sets-input" value="3" min="1" max="10">
            </div>
            <div>
              <span style="font-size: 0.72rem; color: #94a3b8;">Weight (kg)</span>
              <input type="number" class="form-control ex-weight-input" value="60" step="2.5" min="0">
            </div>
            <div>
              <span style="font-size: 0.72rem; color: #94a3b8;">Reps</span>
              <input type="number" class="form-control ex-reps-input" value="10" min="1">
            </div>
          </div>
        `;
        exerciseList.appendChild(row);
        row.querySelector('.remove-ex-btn').addEventListener('click', () => row.remove());
      });
    }

    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('workoutTitle').value;
        const category = document.getElementById('workoutCategory').value;
        const duration_min = parseInt(document.getElementById('workoutDuration').value) || 45;
        const notes = document.getElementById('workoutNotes').value;

        const exercises = [];
        const rows = exerciseList.querySelectorAll('.form-group');
        rows.forEach(r => {
          const name = r.querySelector('.ex-name-input').value;
          const numSets = parseInt(r.querySelector('.ex-sets-input').value) || 3;
          const weight = parseFloat(r.querySelector('.ex-weight-input').value) || 50;
          const reps = parseInt(r.querySelector('.ex-reps-input').value) || 10;
          
          const setsArr = [];
          for (let s = 1; s <= numSets; s++) {
            setsArr.push({ set_num: s, reps, weight_kg: weight, completed: true });
          }
          exercises.push({ name, sets: setsArr });
        });

        try {
          const res = await API.logFullWorkout({ title, category, duration_min, notes, exercises });
          showToast(`🔥 Workout logged! +${res.xp_earned} XP earned!`, 'success');
          document.getElementById('logWorkoutModal').classList.remove('active');
          form.reset();
          await this.loadAllData();
        } catch (err) {
          showToast('Failed to log workout', 'error');
        }
      });
    }
  },

  bindSeedReset() {
    const resetBtn = document.getElementById('resetSeedDataBtn');
    if (resetBtn) {
      resetBtn.addEventListener('click', async () => {
        if (confirm('Reset all sample data back to pristine default state? (Alex Forge, ranks, challenges)')) {
          try {
            await API.resetSeed();
            showToast('Sample data refreshed to initial state!', 'success');
            await window.Auth.demoLogin('Alex_Forge');
            await this.loadAllData();
          } catch (err) {
            showToast('Failed to reset data', 'error');
          }
        }
      });
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

window.App = App;
