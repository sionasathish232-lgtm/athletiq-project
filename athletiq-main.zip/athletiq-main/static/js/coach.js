/**
 * coach.js — AthletiQ Coach AI Chatbot
 *
 * Premium dark/red chat UI matching AthletiQ design system.
 * Calls POST /api/coach/chat only — no API keys in this file.
 * Shown only when user is authenticated (hidden on login screen).
 */

const AthletiQCoach = {
  isOpen: false,
  isTyping: false,
  history: [],           // { role: 'user'|'coach', text: string }[]
  initialized: false,

  QUICK_ACTIONS: [
    { label: "Today's workout",        icon: "⚡", msg: "What's my workout today? List every exercise, sets and reps." },
    { label: "How close am I to Gold?",icon: "🏆", msg: "What rank am I right now and how many workouts do I need to reach the next division?" },
    { label: "Beat my rival",          icon: "🎯", msg: "Who is directly above me on the leaderboard and what is the fastest way to overtake them?" },
    { label: "Can I hit 5K XP?",       icon: "📈", msg: "Given my current XP and streak, can I realistically hit 5000 XP this week? What would it take?" },
  ],

  // ─── Init ──────────────────────────────────────────────
  init() {
    if (this.initialized) return;
    this.initialized = true;
    this._injectHTML();
    this._bindEvents();
    this._updateVisibility();
  },

  // Show/hide based on auth state (called by app.js after login/logout)
  _updateVisibility() {
    const bubble = document.getElementById('coachBubble');
    const authScreen = document.getElementById('authGatewayView');
    if (!bubble) return;
    const isAuth = authScreen && authScreen.style.display === 'none';
    bubble.style.display = isAuth ? 'flex' : 'none';
  },

  show() {
    const bubble = document.getElementById('coachBubble');
    if (bubble) bubble.style.display = 'flex';
  },

  hide() {
    const bubble = document.getElementById('coachBubble');
    if (bubble) bubble.style.display = 'none';
    this.close();
  },

  // ─── HTML injection ────────────────────────────────────
  _injectHTML() {
    if (document.getElementById('coachPanel')) return;

    const html = `
      <!-- ATHLETIQ COACH: Floating Bubble -->
      <div id="coachBubble" class="coach-bubble" title="Chat with AthletiQ Coach" style="display:none;" aria-label="Open AthletiQ Coach">
        <div class="coach-bubble-icon">🤖</div>
        <div class="coach-bubble-label">COACH</div>
        <div class="coach-bubble-ping"></div>
      </div>

      <!-- ATHLETIQ COACH: Full Chat Drawer -->
      <div id="coachPanel" class="coach-panel" role="dialog" aria-modal="true" aria-label="AthletiQ Coach Chat" style="display:none;">
        <!-- Header -->
        <div class="coach-header">
          <div class="coach-header-left">
            <div class="coach-avatar">🤖</div>
            <div>
              <div class="coach-title">ATHLETIQ COACH</div>
              <div class="coach-subtitle">AI-powered · Personalized · Real data</div>
            </div>
          </div>
          <button class="coach-close-btn" id="coachCloseBtn" aria-label="Close coach">✕</button>
        </div>

        <!-- Message feed -->
        <div class="coach-messages" id="coachMessages" role="log" aria-live="polite"></div>

        <!-- Quick action buttons -->
        <div class="coach-quick-actions" id="coachQuickActions">
          <div class="coach-quick-label">Quick questions:</div>
          <div class="coach-quick-row" id="coachQuickRow"></div>
        </div>

        <!-- Input bar -->
        <div class="coach-input-bar">
          <input
            type="text"
            class="coach-input"
            id="coachInput"
            placeholder="Ask your coach anything..."
            maxlength="300"
            autocomplete="off"
            aria-label="Message to AthletiQ Coach"
          />
          <button class="coach-send-btn" id="coachSendBtn" aria-label="Send message">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>

      <!-- Backdrop -->
      <div id="coachBackdrop" class="coach-backdrop" style="display:none;"></div>
    `;

    document.body.insertAdjacentHTML('beforeend', html);

    // Render quick action buttons
    const row = document.getElementById('coachQuickRow');
    if (row) {
      this.QUICK_ACTIONS.forEach(action => {
        const btn = document.createElement('button');
        btn.className = 'coach-quick-btn';
        btn.innerHTML = `${action.icon} ${action.label}`;
        btn.addEventListener('click', () => this.sendMessage(action.msg));
        row.appendChild(btn);
      });
    }
  },

  // ─── Events ────────────────────────────────────────────
  _bindEvents() {
    this._makeBubbleDraggable();

    document.addEventListener('click', (e) => {
      const closeBtn = document.getElementById('coachCloseBtn');
      const backdrop = document.getElementById('coachBackdrop');
      const sendBtn  = document.getElementById('coachSendBtn');

      if (closeBtn && closeBtn.contains(e.target)) this.close();
      if (backdrop && backdrop.contains(e.target)) this.close();
      if (sendBtn  && sendBtn.contains(e.target))  this._handleSend();
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen) this.close();
      if (e.key === 'Enter' && this.isOpen) {
        const input = document.getElementById('coachInput');
        if (document.activeElement === input) this._handleSend();
      }
    });
  },

  // ─── Draggable bubble ──────────────────────────────────
  _makeBubbleDraggable() {
    const bubble = document.getElementById('coachBubble');
    if (!bubble) return;

    let startX, startY, startLeft, startBottom;
    let dragging = false;
    let didDrag  = false;        // distinguish tap vs drag

    // Restore saved position
    const saved = JSON.parse(localStorage.getItem('coachBubblePos') || 'null');
    if (saved) {
      bubble.style.right  = 'auto';
      bubble.style.bottom = 'auto';
      bubble.style.left   = saved.left + 'px';
      bubble.style.top    = saved.top  + 'px';
    }

    const onMove = (cx, cy) => {
      if (!dragging) return;
      const dx = cx - startX;
      const dy = cy - startY;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) didDrag = true;

      // Clamp inside viewport
      const bw = bubble.offsetWidth;
      const bh = bubble.offsetHeight;
      let newLeft = startLeft + dx;
      let newTop  = startY  - startBottom + dy;   // convert from bottom-anchored

      // Clamp
      newLeft = Math.max(8, Math.min(window.innerWidth  - bw - 8, newLeft));
      newTop  = Math.max(8, Math.min(window.innerHeight - bh - 8, newTop));

      bubble.style.right  = 'auto';
      bubble.style.bottom = 'auto';
      bubble.style.left   = newLeft + 'px';
      bubble.style.top    = newTop  + 'px';
    };

    const onEnd = (cx, cy) => {
      if (!dragging) return;
      dragging = false;
      bubble.style.transition = '';
      bubble.style.cursor = 'pointer';
      document.body.style.userSelect = '';

      // Save position
      const rect = bubble.getBoundingClientRect();
      localStorage.setItem('coachBubblePos', JSON.stringify({ left: rect.left, top: rect.top }));

      // If barely moved → treat as click → open panel
      if (!didDrag) {
        setTimeout(() => this.open(), 0);
      }
    };

    // ── Mouse ──
    bubble.addEventListener('mousedown', (e) => {
      e.preventDefault();
      dragging = true;
      didDrag  = false;
      const rect = bubble.getBoundingClientRect();
      startX      = e.clientX;
      startY      = e.clientY;
      startLeft   = rect.left;
      startBottom = window.innerHeight - rect.bottom;
      bubble.style.transition = 'none';
      bubble.style.cursor = 'grabbing';
      document.body.style.userSelect = 'none';
    });
    document.addEventListener('mousemove', (e) => onMove(e.clientX, e.clientY));
    document.addEventListener('mouseup',   (e) => onEnd(e.clientX, e.clientY));

    // ── Touch ──
    bubble.addEventListener('touchstart', (e) => {
      const t = e.touches[0];
      dragging = true;
      didDrag  = false;
      const rect = bubble.getBoundingClientRect();
      startX      = t.clientX;
      startY      = t.clientY;
      startLeft   = rect.left;
      startBottom = window.innerHeight - rect.bottom;
      bubble.style.transition = 'none';
    }, { passive: true });
    document.addEventListener('touchmove', (e) => {
      if (!dragging) return;
      e.preventDefault();
      const t = e.touches[0];
      onMove(t.clientX, t.clientY);
    }, { passive: false });
    document.addEventListener('touchend', (e) => {
      if (!dragging) return;
      const t = e.changedTouches[0];
      onEnd(t.clientX, t.clientY);
    });
  },

  // ─── Open / Close ──────────────────────────────────────
  open() {
    if (this.isOpen) return;
    this.isOpen = true;

    const panel    = document.getElementById('coachPanel');
    const backdrop = document.getElementById('coachBackdrop');
    const bubble   = document.getElementById('coachBubble');

    if (panel)    { panel.style.display    = 'flex'; requestAnimationFrame(() => panel.classList.add('coach-panel-open')); }
    if (backdrop) { backdrop.style.display = 'block'; requestAnimationFrame(() => backdrop.classList.add('coach-backdrop-visible')); }
    if (bubble)   bubble.classList.add('coach-bubble-active');

    // Show welcome message if first open
    if (this.history.length === 0) {
      setTimeout(() => this._showWelcome(), 200);
    }

    setTimeout(() => {
      const input = document.getElementById('coachInput');
      if (input) input.focus();
    }, 300);
  },

  close() {
    if (!this.isOpen) return;
    this.isOpen = false;

    const panel    = document.getElementById('coachPanel');
    const backdrop = document.getElementById('coachBackdrop');
    const bubble   = document.getElementById('coachBubble');

    if (panel)    { panel.classList.remove('coach-panel-open'); setTimeout(() => { if (!this.isOpen) panel.style.display = 'none'; }, 320); }
    if (backdrop) { backdrop.classList.remove('coach-backdrop-visible'); setTimeout(() => { if (!this.isOpen) backdrop.style.display = 'none'; }, 320); }
    if (bubble)   bubble.classList.remove('coach-bubble-active');
  },

  // ─── Welcome message ───────────────────────────────────
  _showWelcome() {
    this._appendMessage('coach',
      '👋 I\'m your **AthletiQ Coach** — I have access to your real workout data, XP, rank, and streak.\n\nAsk me anything, or tap a quick action below to get started. Let\'s CONQUER.'
    );
  },

  // ─── Send logic ────────────────────────────────────────
  _handleSend() {
    const input = document.getElementById('coachInput');
    if (!input) return;
    const text = input.value.trim();
    if (!text || this.isTyping) return;
    input.value = '';
    this.sendMessage(text);
  },

  async sendMessage(text) {
    if (this.isTyping) return;

    // Hide quick actions after first real message
    const qa = document.getElementById('coachQuickActions');
    if (qa) qa.style.display = 'none';

    this._appendMessage('user', text);
    this.history.push({ role: 'user', text });

    this._showTyping();
    this.isTyping = true;

    const sendBtn = document.getElementById('coachSendBtn');
    const input   = document.getElementById('coachInput');
    if (sendBtn) sendBtn.disabled = true;
    if (input)   input.disabled = true;

    try {
      const res = await fetch('/api/coach/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });

      const data = await res.json();

      this._removeTyping();

      if (res.ok && data.reply) {
        this._appendMessage('coach', data.reply);
        this.history.push({ role: 'coach', text: data.reply });
      } else {
        this._appendMessage('coach', '⚡ Something went wrong on my end. Try again in a moment.');
      }
    } catch (err) {
      this._removeTyping();
      this._appendMessage('coach', '⚡ Network error — check your connection and try again.');
    } finally {
      this.isTyping = false;
      if (sendBtn) sendBtn.disabled = false;
      if (input)   { input.disabled = false; input.focus(); }
    }
  },

  // ─── Message rendering ─────────────────────────────────
  _appendMessage(role, text) {
    const feed = document.getElementById('coachMessages');
    if (!feed) return;

    const wrap = document.createElement('div');
    wrap.className = `coach-msg coach-msg-${role}`;

    // Render bold markdown (**text**) and newlines
    const formatted = text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>');

    if (role === 'coach') {
      wrap.innerHTML = `
        <div class="coach-msg-avatar">🤖</div>
        <div class="coach-msg-bubble">${formatted}</div>
      `;
    } else {
      wrap.innerHTML = `<div class="coach-msg-bubble">${formatted}</div>`;
    }

    feed.appendChild(wrap);
    requestAnimationFrame(() => { wrap.classList.add('coach-msg-visible'); });
    feed.scrollTop = feed.scrollHeight;
  },

  _showTyping() {
    const feed = document.getElementById('coachMessages');
    if (!feed || document.getElementById('coachTyping')) return;
    const el = document.createElement('div');
    el.id = 'coachTyping';
    el.className = 'coach-msg coach-msg-coach coach-typing-wrap';
    el.innerHTML = `
      <div class="coach-msg-avatar">🤖</div>
      <div class="coach-msg-bubble coach-typing">
        <span></span><span></span><span></span>
      </div>
    `;
    feed.appendChild(el);
    requestAnimationFrame(() => el.classList.add('coach-msg-visible'));
    feed.scrollTop = feed.scrollHeight;
  },

  _removeTyping() {
    const el = document.getElementById('coachTyping');
    if (el) el.remove();
  }
};

window.AthletiQCoach = AthletiQCoach;

// Auto-init when DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => AthletiQCoach.init());
} else {
  AthletiQCoach.init();
}

// Hook into Auth state changes — show/hide bubble correctly.
// Auth.showMainApp() is called when user logs in or session is restored.
// We patch it after a short delay so Auth object is fully initialized first.
setTimeout(() => {
  if (window.Auth && typeof window.Auth.showMainApp === 'function') {
    const _orig = window.Auth.showMainApp.bind(window.Auth);
    window.Auth.showMainApp = function (user) {
      _orig(user);
      setTimeout(() => AthletiQCoach.show(), 400);
    };
  }
  // Also patch onboarding finish (onboarding.js calls mainApp.style.display = 'block' directly)
  if (window.Onboarding && typeof window.Onboarding.submit === 'function') {
    const _origSubmit = window.Onboarding.submit.bind(window.Onboarding);
    window.Onboarding.submit = async function () {
      await _origSubmit();
      setTimeout(() => AthletiQCoach.show(), 600);
    };
  }
  // Also check if user is already logged in on page load
  setTimeout(() => AthletiQCoach._updateVisibility(), 800);
}, 300);

