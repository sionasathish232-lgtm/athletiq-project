/**
 * api.js - Clean HTTP client wrapper for TitanFit backend APIs
 */

const API = {
  async request(endpoint, options = {}) {
    const defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    const config = {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers
      }
    };

    try {
      const response = await fetch(endpoint, config);
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Server error occurred');
      }
      return data;
    } catch (err) {
      console.error(`API Error [${endpoint}]:`, err);
      throw err;
    }
  },

  // Auth Endpoints
  async getMe() {
    return this.request('/api/auth/me');
  },

  async login(identifier, password) {
    return this.request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password })
    });
  },

  async demoLogin(username = 'Alex_Forge') {
    return this.request('/api/auth/demo-login', {
      method: 'POST',
      body: JSON.stringify({ username })
    });
  },

  async register(userData) {
    return this.request('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  },

  async forgotPassword(email, new_password, security_answer = 'gym') {
    return this.request('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email, new_password, security_answer })
    });
  },

  async logout() {
    return this.request('/api/auth/logout', { method: 'POST' });
  },

  // Dashboard & Workouts
  async getDashboard() {
    return this.request('/api/dashboard');
  },

  async toggleRoutineSet(exercise_id, set_num, completed) {
    return this.request('/api/workouts/toggle-set', {
      method: 'POST',
      body: JSON.stringify({ exercise_id, set_num, completed })
    });
  },

  async logFullWorkout(workoutData) {
    return this.request('/api/workouts', {
      method: 'POST',
      body: JSON.stringify(workoutData)
    });
  },

  async getWorkouts() {
    return this.request('/api/workouts');
  },

  // Leaderboard
  async getLeaderboard() {
    return this.request('/api/leaderboard');
  },

  // Challenges & Achievements
  async getChallenges() {
    return this.request('/api/challenges');
  },

  async joinChallenge(challenge_id) {
    return this.request('/api/challenges/join', {
      method: 'POST',
      body: JSON.stringify({ challenge_id })
    });
  },

  async addChallengeProgress(challenge_id, amount) {
    return this.request('/api/challenges/progress', {
      method: 'POST',
      body: JSON.stringify({ challenge_id, amount })
    });
  },

  async getAchievements() {
    return this.request('/api/achievements');
  },

  async getQuotes() {
    return this.request('/api/quotes');
  },

  async saveOnboarding(data) {
    return this.request('/api/auth/onboarding', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async resetSeed() {
    return this.request('/api/reset-seed', { method: 'POST' });
  }
};

window.API = API;
