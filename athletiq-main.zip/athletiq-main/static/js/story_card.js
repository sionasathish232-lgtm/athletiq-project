/**
 * story_card.js - 9:16 Instagram Story Canvas Generator & Exporter
 * Configured for AthletiQ: "TRACK. IMPROVE. CONQUER."
 */

const StoryCard = {
  canvas: null,
  ctx: null,
  width: 1080,
  height: 1920,
  currentTheme: 'crimson',
  currentTemplate: 'pr',
  customTitle: 'NEW BENCH PRESS PR',
  customStat: '100 KG x 6 REPS',
  customQuote: 'Pain today, strength tomorrow.',
  logoImg: null,

  themes: {
    crimson: {
      bgTop: '#180407',
      bgBottom: '#050508',
      accent: '#ef233c',
      accentGlow: 'rgba(239, 35, 60, 0.55)',
      accentNeon: '#ff0033',
      text: '#ffffff',
      subtext: '#ffccd5'
    },
    stealth: {
      bgTop: '#111217',
      bgBottom: '#050507',
      accent: '#ffffff',
      accentGlow: 'rgba(255, 255, 255, 0.25)',
      accentNeon: '#ef233c',
      text: '#ffffff',
      subtext: '#e2e8f0'
    },
    inferno: {
      bgTop: '#260205',
      bgBottom: '#080102',
      accent: '#ff0033',
      accentGlow: 'rgba(255, 0, 51, 0.65)',
      accentNeon: '#ff3355',
      text: '#ffffff',
      subtext: '#ffe5e9'
    },
    emerald: {
      bgTop: '#08140c',
      bgBottom: '#020604',
      accent: '#10b981',
      accentGlow: 'rgba(16, 185, 129, 0.4)',
      accentNeon: '#00ff87',
      text: '#ffffff',
      subtext: '#a7f3d0'
    }
  },

  templates: {
    pr: {
      tag: 'PERSONAL RECORD BROKEN',
      icon: '💥',
      defaultTitle: 'BENCH PRESS PR',
      defaultStat: '100 KG x 6 REPS'
    },
    streak: {
      tag: 'DISCIPLINE CRUCIBLE',
      icon: '🔥',
      defaultTitle: 'UNBROKEN IRON STREAK',
      defaultStat: '7 CONSECUTIVE DAYS'
    },
    rank: {
      tag: 'LEADERBOARD PROMOTION',
      icon: '🏆',
      defaultTitle: 'GLOBAL PODIUM REACHED',
      defaultStat: 'RANK #3 PLATINUM'
    },
    volume: {
      tag: 'HYPERTROPHY VOLUME',
      icon: '🏋️',
      defaultTitle: 'VOLUME DESTROYED',
      defaultStat: '24,500 KG MOVED'
    }
  },

  init() {
    this.canvas = document.getElementById('storyCanvas');
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.canvas.width = this.width;
    this.canvas.height = this.height;

    // Preload logo
    this.logoImg = new Image();
    this.logoImg.src = '/static/images/athletiq_logo.jpg';
    this.logoImg.onload = () => {
      this.render();
    };

    this.bindControls();
    this.render();
  },

  bindControls() {
    // Theme buttons
    document.querySelectorAll('.story-theme-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.story-theme-btn').forEach(b => b.classList.remove('active'));
        e.currentTarget.classList.add('active');
        this.currentTheme = e.currentTarget.dataset.theme;
        this.render();
      });
    });

    // Template selector
    const templateSelect = document.getElementById('storyTemplateSelect');
    if (templateSelect) {
      templateSelect.addEventListener('change', (e) => {
        this.currentTemplate = e.target.value;
        const tmpl = this.templates[this.currentTemplate];
        if (tmpl) {
          const titleInput = document.getElementById('storyTitleInput');
          const statInput = document.getElementById('storyStatInput');
          if (titleInput) titleInput.value = tmpl.defaultTitle;
          if (statInput) statInput.value = tmpl.defaultStat;
          this.customTitle = tmpl.defaultTitle;
          this.customStat = tmpl.defaultStat;
        }
        this.render();
      });
    }

    // Input changes
    const titleInput = document.getElementById('storyTitleInput');
    if (titleInput) {
      titleInput.addEventListener('input', (e) => {
        this.customTitle = e.target.value;
        this.render();
      });
    }

    const statInput = document.getElementById('storyStatInput');
    if (statInput) {
      statInput.addEventListener('input', (e) => {
        this.customStat = e.target.value;
        this.render();
      });
    }

    const quoteInput = document.getElementById('storyQuoteInput');
    if (quoteInput) {
      quoteInput.addEventListener('input', (e) => {
        this.customQuote = e.target.value;
        this.render();
      });
    }

    // Download Button
    const downloadBtn = document.getElementById('downloadStoryBtn');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', () => this.download());
    }

    // Copy Caption Button
    const copyCaptionBtn = document.getElementById('copyCaptionBtn');
    if (copyCaptionBtn) {
      copyCaptionBtn.addEventListener('click', () => this.copyCaption());
    }
  },

  render() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const w = this.width;
    const h = this.height;
    const t = this.themes[this.currentTheme] || this.themes.crimson;
    const tmpl = this.templates[this.currentTemplate] || this.templates.pr;
    const user = (window.Auth && window.Auth.currentUser) ? window.Auth.currentUser : { username: 'Alex_Forge', xp: 3450, current_streak: 5, division: 'Platinum' };

    // 1. Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0, t.bgTop);
    bgGrad.addColorStop(1, t.bgBottom);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // 2. Athletic Radial Glow Orbs (Red Atmosphere)
    const glow1 = ctx.createRadialGradient(w * 0.5, h * 0.38, 50, w * 0.5, h * 0.38, 550);
    glow1.addColorStop(0, t.accentGlow);
    glow1.addColorStop(1, 'transparent');
    ctx.fillStyle = glow1;
    ctx.fillRect(0, 0, w, h);

    const glow2 = ctx.createRadialGradient(w * 0.8, h * 0.85, 30, w * 0.8, h * 0.85, 450);
    glow2.addColorStop(0, 'rgba(0, 0, 0, 0.5)');
    glow2.addColorStop(1, 'transparent');
    ctx.fillStyle = glow2;
    ctx.fillRect(0, 0, w, h);

    // 3. Grid Pattern Overlay
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 2;
    for (let x = 60; x < w; x += 120) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 60; y < h; y += 120) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // 4. Header Bar with Logo
    ctx.save();
    if (this.logoImg && this.logoImg.complete && this.logoImg.naturalWidth !== 0) {
      ctx.save();
      this.roundRect(ctx, 90, 80, 80, 80, 20);
      ctx.clip();
      ctx.drawImage(this.logoImg, 90, 80, 80, 80);
      ctx.restore();

      ctx.strokeStyle = t.accent;
      ctx.lineWidth = 3;
      this.roundRect(ctx, 90, 80, 80, 80, 20);
      ctx.stroke();

      ctx.font = '900 44px -apple-system, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'left';
      ctx.fillText('ATHLETIQ', 190, 125);

      ctx.font = '800 20px -apple-system, sans-serif';
      ctx.fillStyle = t.accent;
      ctx.letterSpacing = '3px';
      ctx.fillText('TRACK. IMPROVE. CONQUER.', 190, 155);
    } else {
      ctx.font = '900 44px -apple-system, sans-serif';
      ctx.fillStyle = t.accent;
      ctx.textAlign = 'left';
      ctx.fillText('⚡ ATHLETIQ', 90, 140);
    }

    ctx.font = '700 26px -apple-system, sans-serif';
    ctx.fillStyle = '#71717a';
    ctx.textAlign = 'right';
    ctx.fillText('INSTA STORY', w - 90, 135);
    ctx.restore();

    // 5. User Badge Card
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 3;
    this.roundRect(ctx, 90, 210, w - 180, 150, 30);
    ctx.fill();
    ctx.stroke();

    // User Avatar
    ctx.beginPath();
    ctx.arc(175, 285, 48, 0, Math.PI * 2);
    ctx.fillStyle = t.accent;
    ctx.fill();
    ctx.font = '900 44px -apple-system, sans-serif';
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(user.username.charAt(0).toUpperCase(), 175, 285);

    // Username & Division
    ctx.textAlign = 'left';
    ctx.font = '900 44px -apple-system, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`@${user.username}`, 250, 270);

    ctx.font = '700 30px -apple-system, sans-serif';
    ctx.fillStyle = t.subtext;
    ctx.fillText(`Rank #${user.rank || 4} • ${user.division || 'Platinum'} Division`, 250, 315);
    ctx.restore();

    // 6. Central Hero Milestone Box
    ctx.save();
    ctx.fillStyle = 'rgba(12, 13, 18, 0.92)';
    ctx.strokeStyle = t.accent;
    ctx.lineWidth = 4;
    ctx.shadowColor = t.accentGlow;
    ctx.shadowBlur = 40;
    this.roundRect(ctx, 90, 420, w - 180, 840, 40);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Tag Pill
    ctx.fillStyle = t.accent;
    this.roundRect(ctx, w / 2 - 240, 480, 480, 56, 28);
    ctx.fill();
    ctx.font = '900 24px -apple-system, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText(tmpl.tag, w / 2, 515);

    // Huge Icon
    ctx.font = '140px -apple-system, sans-serif';
    ctx.fillText(tmpl.icon, w / 2, 690);

    // Title
    ctx.font = '900 60px -apple-system, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText(this.customTitle.toUpperCase(), w / 2, 800);

    // Stat / Value Display
    ctx.font = '900 76px -apple-system, sans-serif';
    ctx.fillStyle = t.accentNeon;
    ctx.fillText(this.customStat, w / 2, 910);

    // Divider Line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(180, 970);
    ctx.lineTo(w - 180, 970);
    ctx.stroke();

    // 4-6 Word Motivation Mantra
    ctx.font = 'italic 700 42px -apple-system, serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`“${this.customQuote}”`, w / 2, 1050);

    ctx.font = '700 26px -apple-system, sans-serif';
    ctx.fillStyle = '#a1a1aa';
    ctx.fillText('ATHLETIQ // TRACK. IMPROVE. CONQUER.', w / 2, 1120);
    ctx.restore();

    // 7. Stat Pill Grid at Bottom
    const pillY = 1320;
    const pillW = (w - 220) / 3;

    // Pill 1: Total XP
    this.drawStatPill(ctx, 90, pillY, pillW, 170, 'TOTAL XP', `${(user.xp || 3450).toLocaleString()}`, '⚡', t);
    // Pill 2: Streak
    this.drawStatPill(ctx, 90 + pillW + 20, pillY, pillW, 170, 'DISCIPLINE', `${user.current_streak || 5} DAYS`, '🔥', t);
    // Pill 3: Level
    this.drawStatPill(ctx, 90 + (pillW + 20) * 2, pillY, pillW, 170, 'TIER', `${user.division || 'PLATINUM'}`, '🛡️', t);

    // 8. Footer & Social Watermark
    ctx.save();
    ctx.font = '800 32px -apple-system, sans-serif';
    ctx.fillStyle = '#71717a';
    ctx.textAlign = 'center';
    ctx.fillText('TAG @ATHLETIQ.APP • COMPETE ON LEADERBOARDS', w / 2, 1680);

    ctx.font = '700 26px -apple-system, sans-serif';
    ctx.fillStyle = t.accent;
    ctx.fillText('#ATHLETIQ #CONQUER #HYPERTROPHY #BEASTMODE', w / 2, 1730);

    // Swipe Up indicator line
    ctx.strokeStyle = t.accentNeon;
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(w / 2 - 60, 1820);
    ctx.lineTo(w / 2, 1795);
    ctx.lineTo(w / 2 + 60, 1820);
    ctx.stroke();
    ctx.restore();
  },

  drawStatPill(ctx, x, y, width, height, label, val, icon, theme) {
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    this.roundRect(ctx, x, y, width, height, 24);
    ctx.fill();
    ctx.stroke();

    ctx.font = '36px -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(icon, x + width / 2, y + 48);

    ctx.font = '900 32px -apple-system, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(val, x + width / 2, y + 100);

    ctx.font = '800 20px -apple-system, sans-serif';
    ctx.fillStyle = theme.accent;
    ctx.fillText(label, x + width / 2, y + 138);
    ctx.restore();
  },

  roundRect(ctx, x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;
    if (h < 2 * r) r = h / 2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  },

  download() {
    if (!this.canvas) return;
    const link = document.createElement('a');
    link.download = `athletiq-story-${Date.now()}.png`;
    link.href = this.canvas.toDataURL('image/png');
    link.click();
    showToast('9:16 AthletiQ Instagram Story downloaded!', 'success');
  },

  copyCaption() {
    const user = (window.Auth && window.Auth.currentUser) ? window.Auth.currentUser.username : 'Alex_Forge';
    const caption = `🔥 Just hit a new milestone on AthletiQ!\n⚡ ${this.customTitle}: ${this.customStat}\n💬 "${this.customQuote}"\n\nTRACK. IMPROVE. CONQUER. on @AthletiQ: #AthletiQ #TrackImproveConquer #Hypertrophy`;
    navigator.clipboard.writeText(caption).then(() => {
      showToast('Caption copied! Paste directly into Instagram!', 'success');
    }).catch(() => {
      showToast('Unable to copy to clipboard', 'error');
    });
  }
};

window.StoryCard = StoryCard;
