/**
 * auth-premium.js — AthletiQ Premium Login Page Animation System
 *
 * Visual-only upgrade. Zero changes to auth logic, fields, or routes.
 * Implements requirements 1–20: breathing glow, ambient light, particles,
 * cursor spotlight, card tilt, logo effect, entrance sequence, button sheen,
 * input focus, tab transitions, test-drive panel, sparkles, border sweep.
 *
 * Runs only when #authGatewayView is visible.
 * Fully respects prefers-reduced-motion.
 * All animation via CSS transforms + opacity + requestAnimationFrame.
 */

(function () {
  'use strict';

  /* ─── Feature flags ─────────────────────────────── */
  const REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const IS_TOUCH = () => window.matchMedia('(hover: none)').matches;
  const IS_TABLET = () => window.matchMedia('(max-width: 1024px)').matches;

  /* ─── Run once gateway is in the DOM ────────────── */
  function init() {
    if (REDUCED) { initReducedMode(); return; }

    initAmbientLayers();
    initParticles();
    initCursorSpotlight();
    initCardTilt();
    initLogoEffect();
    initEntranceSequence();
    initButtonEffects();
    initInputEffects();
    initTabTransitions();
    initTestDrivePanel();
    initSparkles();
    initBorderSweep();
  }

  /* ─── Reduced-motion: only opacity transitions ───── */
  function initReducedMode() {
    const container = getContainer();
    if (!container) return;
    container.style.opacity = '0';
    container.style.transition = 'opacity 0.4s ease';
    requestAnimationFrame(() => { container.style.opacity = '1'; });
  }

  /* ─── Helpers ────────────────────────────────────── */
  function getScreen()    { return document.getElementById('authGatewayView'); }
  function getContainer() { return document.querySelector('.auth-gateway-container'); }

  /* ================================================================
     1 + 2. BREATHING GLOW + AMBIENT LIGHT LAYERS
     Injects two absolutely-positioned soft gradient blobs behind
     the card. They animate slowly on their own CSS keyframes.
  ================================================================ */
  function initAmbientLayers() {
    const screen = getScreen();
    if (!screen || document.getElementById('apAmbientWrap')) return;

    const wrap = document.createElement('div');
    wrap.id = 'apAmbientWrap';
    wrap.innerHTML = `
      <div class="ap-blob ap-blob-1"></div>
      <div class="ap-blob ap-blob-2"></div>
      <div class="ap-blob ap-blob-3"></div>
    `;
    // Insert behind everything else
    screen.insertBefore(wrap, screen.firstChild);

    // Breathing glow on the card container
    const card = getContainer();
    if (card && !card.querySelector('.ap-card-glow-ring')) {
      const ring = document.createElement('div');
      ring.className = 'ap-card-glow-ring';
      card.appendChild(ring);
    }
  }

  /* ================================================================
     3. FLOATING PARTICLES
  ================================================================ */
  function initParticles() {
    const screen = getScreen();
    if (!screen || document.getElementById('apParticleCanvas')) return;

    const canvas = document.createElement('canvas');
    canvas.id = 'apParticleCanvas';
    canvas.className = 'ap-particle-canvas';
    screen.insertBefore(canvas, screen.firstChild);

    const ctx = canvas.getContext('2d');
    const particles = [];
    const count = IS_TABLET() ? 28 : 48;

    function resize() {
      canvas.width  = screen.offsetWidth;
      canvas.height = screen.offsetHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const rand = (a, b) => a + Math.random() * (b - a);
    const card = getContainer();

    class Particle {
      constructor() { this.reset(true); }
      reset(scatter = false) {
        // Start anywhere when scattering, otherwise from bottom
        this.x     = rand(0, canvas.width);
        this.y     = scatter ? rand(0, canvas.height) : canvas.height + rand(0, 30);
        this.vx    = rand(-0.25, 0.25);
        this.vy    = rand(-0.35, -0.12);
        this.life  = scatter ? rand(0.1, 1) : rand(0.05, 0.25);
        this.maxL  = rand(0.25, 0.7);
        this.decay = rand(0.0015, 0.004);
        this.grow  = true;
        this.r     = rand(0.6, 2.2);
        // Colour: mostly red+warm, occasionally white
        const t = Math.random();
        if (t < 0.55)      this.color = `hsl(${rand(348,360)},${rand(75,100)}%,${rand(55,72)}%)`;
        else if (t < 0.8)  this.color = `hsl(${rand(20,35)},${rand(70,95)}%,${rand(60,75)}%)`;
        else               this.color = `hsl(0,0%,${rand(85,100)}%)`;
      }
      update() {
        this.x += this.vx;
        this.y += this.vy;
        if (this.grow) {
          this.life = Math.min(this.life + this.decay * 2, this.maxL);
          if (this.life >= this.maxL) this.grow = false;
        } else {
          this.life -= this.decay;
        }
        if (this.life <= 0 || this.y < -10) this.reset();
      }
      // Avoid drawing inside the card rect
      isInsideCard() {
        if (!card) return false;
        const cr = card.getBoundingClientRect();
        const sr = canvas.getBoundingClientRect();
        const lx = cr.left - sr.left, rx = cr.right - sr.left;
        const ty = cr.top  - sr.top,  by = cr.bottom - sr.top;
        const pad = 12;
        return this.x > lx + pad && this.x < rx - pad &&
               this.y > ty + pad && this.y < by - pad;
      }
      draw() {
        if (this.isInsideCard()) return;
        ctx.save();
        ctx.globalAlpha = this.life;
        ctx.fillStyle   = this.color;
        ctx.shadowBlur  = 6;
        ctx.shadowColor = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    for (let i = 0; i < count; i++) particles.push(new Particle());

    let running = true;
    function loop() {
      if (!running || !document.getElementById('apParticleCanvas')) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => { p.update(); p.draw(); });
      requestAnimationFrame(loop);
    }
    loop();

    // Stop when gateway hides
    const observer = new MutationObserver(() => {
      const s = getScreen();
      if (s && s.style.display === 'none') { running = false; }
    });
    const s = getScreen();
    if (s) observer.observe(s, { attributes: true, attributeFilter: ['style'] });
  }

  /* ================================================================
     4. CURSOR SPOTLIGHT (desktop only)
  ================================================================ */
  function initCursorSpotlight() {
    if (IS_TOUCH()) return;
    const screen = getScreen();
    if (!screen) return;

    const spot = document.createElement('div');
    spot.className = 'ap-cursor-spot';
    screen.appendChild(spot);

    let tx = -300, ty = -300;
    let cx = -300, cy = -300;

    screen.addEventListener('mousemove', (e) => {
      const r = screen.getBoundingClientRect();
      tx = e.clientX - r.left;
      ty = e.clientY - r.top;

      // Slightly strengthen card glow when cursor near card
      const card = getContainer();
      if (card) {
        const cr = card.getBoundingClientRect();
        const dx = e.clientX - (cr.left + cr.width / 2);
        const dy = e.clientY - (cr.top  + cr.height / 2);
        const dist = Math.hypot(dx, dy);
        const near = Math.max(0, 1 - dist / 250);
        card.style.setProperty('--ap-cursor-near', near.toFixed(3));
      }
    });

    (function lerpLoop() {
      if (!document.querySelector('.ap-cursor-spot')) return;
      cx += (tx - cx) * 0.07;
      cy += (ty - cy) * 0.07;
      spot.style.transform = `translate(${cx - 150}px, ${cy - 150}px)`;
      requestAnimationFrame(lerpLoop);
    })();
  }

  /* ================================================================
     5. CARD TILT (desktop only, max 2-3°)
  ================================================================ */
  function initCardTilt() {
    if (IS_TOUCH()) return;
    const card = getContainer();
    if (!card) return;

    let targetRX = 0, targetRY = 0, curRX = 0, curRY = 0;
    const maxTilt = IS_TABLET() ? 1.5 : 2.5;
    const maxShift = 1.5;

    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const nx = (e.clientX - r.left) / r.width  - 0.5; // -0.5 to 0.5
      const ny = (e.clientY - r.top)  / r.height - 0.5;
      targetRY =  nx * maxTilt * 2;
      targetRX = -ny * maxTilt;
    });

    card.addEventListener('mouseleave', () => {
      targetRX = 0; targetRY = 0;
    });

    (function tiltLoop() {
      if (!getContainer()) return;
      curRX += (targetRX - curRX) * 0.08;
      curRY += (targetRY - curRY) * 0.08;
      const tx = curRY * maxShift;
      const ty = curRX * maxShift;
      card.style.transform =
        `perspective(900px) rotateX(${curRX}deg) rotateY(${curRY}deg) translate(${tx}px,${ty}px)`;
      requestAnimationFrame(tiltLoop);
    })();
  }

  /* ================================================================
     6. LOGO HOVER EFFECT — CSS class-based, no JS needed beyond init
  ================================================================ */
  function initLogoEffect() {
    const logo = document.querySelector('.auth-gateway-logo');
    if (!logo) return;
    logo.classList.add('ap-logo-enhanced');
  }

  /* ================================================================
     7. ENTRANCE SEQUENCE — stagger animate elements into view
  ================================================================ */
  function initEntranceSequence() {
    const selectors = [
      '.logo-glow-wrapper',          // 1. logo
      '.auth-gateway-title',         // 2. title
      '.auth-gateway-tagline',       // 3. tagline
      '.auth-gateway-subtext',       // 4. subtext
      '.auth-fast-demo-box',         // 5. test-drive
      '.auth-segmented-nav',         // 6. tabs
      '.auth-form-card:not([style*="none"])', // 7. active form
      '#gatewayLoginForm .form-group',        // 8. fields
      '#gatewayLoginForm .btn',               // 9. button
    ];

    let delay = 0;
    const stepMs = 75;

    selectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        el.classList.add('ap-entrance');
        el.style.animationDelay = `${delay}ms`;
        delay += stepMs;
      });
    });
  }

  /* ================================================================
     8. BUTTON SHEEN + ENHANCED RIPPLE
  ================================================================ */
  function initButtonEffects() {
    document.querySelectorAll('.auth-gateway-container .btn-primary').forEach(btn => {
      btn.classList.add('ap-btn-premium');

      // Sheen overlay
      if (!btn.querySelector('.ap-sheen')) {
        const sheen = document.createElement('span');
        sheen.className = 'ap-sheen';
        btn.style.position = 'relative';
        btn.style.overflow = 'hidden';
        btn.appendChild(sheen);
      }
    });
  }

  /* ================================================================
     9. INPUT FOCUS EFFECTS — via class toggle
  ================================================================ */
  function initInputEffects() {
    document.querySelectorAll('.auth-gateway-container .form-control').forEach(inp => {
      inp.classList.add('ap-input');
      inp.addEventListener('focus',  () => inp.classList.add('ap-input-focused'));
      inp.addEventListener('blur',   () => inp.classList.remove('ap-input-focused'));
    });

    // Re-apply to dynamically shown panels (register/forgot)
    const observer = new MutationObserver(() => {
      document.querySelectorAll('.auth-gateway-container .form-control:not(.ap-input)').forEach(inp => {
        inp.classList.add('ap-input');
        inp.addEventListener('focus',  () => inp.classList.add('ap-input-focused'));
        inp.addEventListener('blur',   () => inp.classList.remove('ap-input-focused'));
      });
    });
    const card = getContainer();
    if (card) observer.observe(card, { childList: true, subtree: true });
  }

  /* ================================================================
     10. TAB SWITCH ANIMATION — intercept Auth.switchGatewayTab
  ================================================================ */
  function initTabTransitions() {
    if (!window.Auth) return;
    const original = window.Auth.switchGatewayTab?.bind(window.Auth);
    if (!original) return;

    window.Auth.switchGatewayTab = function (target) {
      // Animate out current visible panel
      const panels = {
        login: 'gatewayLoginPanel',
        register: 'gatewayRegisterPanel',
        forgot: 'gatewayForgotPanel'
      };
      const currentPanel = document.querySelector('.auth-form-card:not([style*="none"])');
      if (currentPanel && currentPanel.id !== panels[target]) {
        currentPanel.classList.add('ap-panel-exit');
        setTimeout(() => {
          currentPanel.classList.remove('ap-panel-exit');
          original(target);
          // Animate in new panel
          setTimeout(() => {
            const newPanel = document.getElementById(panels[target]);
            if (newPanel) {
              newPanel.classList.add('ap-panel-enter');
              // Re-apply input effects to new panel
              newPanel.querySelectorAll('.form-control:not(.ap-input)').forEach(inp => {
                inp.classList.add('ap-input');
                inp.addEventListener('focus',  () => inp.classList.add('ap-input-focused'));
                inp.addEventListener('blur',   () => inp.classList.remove('ap-input-focused'));
              });
              // Re-apply button effects
              newPanel.querySelectorAll('.btn-primary:not(.ap-btn-premium)').forEach(btn => {
                btn.classList.add('ap-btn-premium');
                if (!btn.querySelector('.ap-sheen')) {
                  const sheen = document.createElement('span');
                  sheen.className = 'ap-sheen';
                  btn.style.position = 'relative';
                  btn.style.overflow = 'hidden';
                  btn.appendChild(sheen);
                }
              });
              setTimeout(() => newPanel.classList.remove('ap-panel-enter'), 350);
            }
          }, 30);
        }, 200);
      } else {
        original(target);
      }
    };
  }

  /* ================================================================
     11. TEST-DRIVE PANEL HOVER
  ================================================================ */
  function initTestDrivePanel() {
    const box = document.querySelector('.auth-fast-demo-box');
    if (!box) return;
    box.classList.add('ap-demo-box');

    document.querySelectorAll('.auth-fast-demo-buttons .btn').forEach(btn => {
      btn.classList.add('ap-demo-btn');
    });
  }

  /* ================================================================
     12. SPARKLE SYSTEM — random glints near card edges
  ================================================================ */
  function initSparkles() {
    const screen = getScreen();
    const card   = getContainer();
    if (!screen || !card) return;

    function spawnSparkle() {
      const cr = card.getBoundingClientRect();
      const sr = screen.getBoundingClientRect();
      // Pick a random point along card perimeter (with ±40px spread)
      const side = Math.floor(Math.random() * 4);
      let x, y;
      const spread = rand(-50, 50);
      if (side === 0) { x = rand(cr.left, cr.right) - sr.left; y = cr.top  - sr.top + spread; }
      else if (side === 1) { x = rand(cr.left, cr.right) - sr.left; y = cr.bottom - sr.top + spread; }
      else if (side === 2) { x = cr.left - sr.left + spread; y = rand(cr.top, cr.bottom) - sr.top; }
      else                  { x = cr.right - sr.left + spread; y = rand(cr.top, cr.bottom) - sr.top; }

      const el = document.createElement('div');
      el.className = 'ap-sparkle';
      el.style.cssText = `left:${x}px;top:${y}px;`;
      screen.appendChild(el);
      setTimeout(() => el.remove(), 900);
    }

    let sparkleTimer;
    function scheduleSparkle() {
      if (!getScreen()) return;
      spawnSparkle();
      sparkleTimer = setTimeout(scheduleSparkle, rand(600, 2000));
    }
    sparkleTimer = setTimeout(scheduleSparkle, 1200);
  }

  /* ================================================================
     14. BORDER SWEEP EFFECT — thin animated light on card border
  ================================================================ */
  function initBorderSweep() {
    const card = getContainer();
    if (!card || card.querySelector('.ap-border-sweep')) return;
    const sweep = document.createElement('div');
    sweep.className = 'ap-border-sweep';
    card.appendChild(sweep);
  }

  /* ─── Utility ──────────────────────────────────── */
  function rand(a, b) { return a + Math.random() * (b - a); }

  /* ─── Entry point: wait for gateway to appear ─── */
  function waitForGateway() {
    const screen = getScreen();
    if (screen && screen.style.display !== 'none') {
      init();
      return;
    }
    // Poll lightly until gateway shows (Auth module controls visibility)
    const poll = setInterval(() => {
      const s = getScreen();
      if (s && s.style.display !== 'none') {
        clearInterval(poll);
        init();
      }
    }, 120);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', waitForGateway);
  } else {
    waitForGateway();
  }
})();
