/**
 * onboarding.js - Multi-step animated onboarding wizard for AthletiQ
 * Triggered after new user registration. 8 beautiful steps.
 */

const Onboarding = {
  currentStep: 0,
  totalSteps: 8,
  data: {
    gender: null,
    age: 20,
    goal: null,
    weight_kg: 70,
    height_cm: 170,
    goal_weight_kg: 65,
    current_body_shape: null,
    goal_body_shape: null,
    workout_frequency: null,
    lifestyle_role: null
  },

  steps: [
    { id: 'gender',        title: "What's your gender?",           subtitle: "Helps us personalize your plan" },
    { id: 'age',           title: "How old are you?",              subtitle: "Age shapes your optimal training" },
    { id: 'goal',          title: "What's your main goal?",        subtitle: "We'll build your program around this" },
    { id: 'measurements',  title: "Your body measurements",        subtitle: "Track progress from day one" },
    { id: 'body_shape',    title: "Your current body shape",       subtitle: "Be honest — this is just for you" },
    { id: 'goal_shape',    title: "Your goal body shape",          subtitle: "Visualize where you want to be" },
    { id: 'frequency',     title: "How often do you work out?",   subtitle: "We'll set the right intensity" },
    { id: 'role',          title: "What's your daily lifestyle?",  subtitle: "Your activity level matters a lot" }
  ],

  start() {
    // Reset data
    this.currentStep = 0;
    this.data = { gender: null, age: 20, goal: null, weight_kg: 70, height_cm: 170,
                  goal_weight_kg: 65, current_body_shape: null, goal_body_shape: null,
                  workout_frequency: null, lifestyle_role: null };

    const wizard = document.getElementById('onboardingWizard');
    const gateway = document.getElementById('authGatewayView');
    const mainApp = document.getElementById('mainAppView');

    if (gateway) gateway.style.display = 'none';
    if (mainApp) mainApp.style.display = 'none';
    if (wizard)  wizard.style.display = 'flex';

    this.renderStep(0, 'right');
  },

  renderStep(stepIndex, direction = 'right') {
    this.currentStep = stepIndex;
    const step = this.steps[stepIndex];

    // Update progress bar
    const progress = ((stepIndex + 1) / this.totalSteps) * 100;
    const bar = document.getElementById('obProgressBar');
    if (bar) bar.style.width = progress + '%';

    const counter = document.getElementById('obStepCounter');
    if (counter) counter.textContent = `${stepIndex + 1} / ${this.totalSteps}`;

    // Update title + subtitle
    const titleEl = document.getElementById('obStepTitle');
    const subEl   = document.getElementById('obStepSubtitle');
    if (titleEl) titleEl.textContent = step.title;
    if (subEl)   subEl.textContent   = step.subtitle;

    // Render step body
    const body = document.getElementById('obStepBody');
    if (!body) return;

    // Animate out
    body.classList.remove('ob-slide-in-right', 'ob-slide-in-left', 'ob-slide-out-right', 'ob-slide-out-left');
    body.classList.add(direction === 'right' ? 'ob-slide-out-left' : 'ob-slide-out-right');

    setTimeout(() => {
      body.innerHTML = this.buildStepContent(step.id);
      body.classList.remove('ob-slide-out-right', 'ob-slide-out-left');
      body.classList.add(direction === 'right' ? 'ob-slide-in-right' : 'ob-slide-in-left');
      this.bindStepInteractions(step.id);
    }, 180);

    // Update nav buttons
    const backBtn = document.getElementById('obBackBtn');
    const nextBtn = document.getElementById('obNextBtn');
    const skipBtn = document.getElementById('obSkipBtn');

    if (backBtn) backBtn.style.visibility = stepIndex === 0 ? 'hidden' : 'visible';
    if (nextBtn) {
      nextBtn.textContent = stepIndex === this.totalSteps - 1 ? '🚀 Start Training!' : 'Next →';
    }
    // Only show skip for optional steps (measurements, body shapes)
    if (skipBtn) {
      const optionalSteps = ['measurements', 'body_shape', 'goal_shape'];
      skipBtn.style.display = optionalSteps.includes(step.id) ? 'block' : 'none';
    }
  },

  buildStepContent(stepId) {
    switch(stepId) {
      case 'gender': return this.buildGenderStep();
      case 'age':    return this.buildAgeStep();
      case 'goal':   return this.buildGoalStep();
      case 'measurements': return this.buildMeasurementsStep();
      case 'body_shape':   return this.buildBodyShapeStep('current');
      case 'goal_shape':   return this.buildBodyShapeStep('goal');
      case 'frequency':    return this.buildFrequencyStep();
      case 'role':         return this.buildRoleStep();
      default: return '';
    }
  },

  buildGenderStep() {
    const opts = [
      { val: 'male',       emoji: '♂️',  label: 'Male',       sub: 'Testosterone-optimized plan' },
      { val: 'female',     emoji: '♀️',  label: 'Female',     sub: 'Hormone-aware training' },
      { val: 'non-binary', emoji: '⚡',  label: 'Non-binary', sub: 'Personalized just for you' }
    ];
    return `<div class="ob-card-grid ob-card-grid-3">
      ${opts.map(o => `
        <div class="ob-card ob-card-tall ${this.data.gender === o.val ? 'selected' : ''}" data-field="gender" data-value="${o.val}">
          <div class="ob-card-emoji">${o.emoji}</div>
          <div class="ob-card-label">${o.label}</div>
          <div class="ob-card-sub">${o.sub}</div>
        </div>
      `).join('')}
    </div>`;
  },

  buildAgeStep() {
    return `<div class="ob-age-container">
      <div class="ob-age-display" id="obAgeDisplay">${this.data.age}</div>
      <div class="ob-age-unit">years old</div>
      <div class="ob-slider-wrap">
        <span class="ob-slider-label">13</span>
        <input type="range" class="ob-slider" id="obAgeSlider" min="13" max="80" value="${this.data.age}" step="1">
        <span class="ob-slider-label">80</span>
      </div>
      <div class="ob-age-presets">
        ${[16,20,25,30,35,40,50].map(a => `
          <button class="ob-preset-btn ${this.data.age === a ? 'active' : ''}" data-age="${a}">${a}</button>
        `).join('')}
      </div>
    </div>`;
  },

  buildGoalStep() {
    const goals = [
      { val: 'lose_weight',     emoji: '🔥', label: 'Lose Weight',     sub: 'Burn fat, get lean', color: '#ff6b35' },
      { val: 'build_muscle',    emoji: '💪', label: 'Build Muscle',     sub: 'Hypertrophy & strength', color: '#ef233c' },
      { val: 'stay_fit',        emoji: '⚡', label: 'Stay Fit',         sub: 'Maintain & improve fitness', color: '#06b6d4' },
      { val: 'maintain_weight', emoji: '⚖️', label: 'Maintain Weight',  sub: 'Keep current physique', color: '#10b981' }
    ];
    return `<div class="ob-card-grid ob-card-grid-2">
      ${goals.map(g => `
        <div class="ob-card ob-card-goal ${this.data.goal === g.val ? 'selected' : ''}" data-field="goal" data-value="${g.val}" style="--goal-color: ${g.color}">
          <div class="ob-card-emoji">${g.emoji}</div>
          <div class="ob-card-label">${g.label}</div>
          <div class="ob-card-sub">${g.sub}</div>
        </div>
      `).join('')}
    </div>`;
  },

  buildMeasurementsStep() {
    // Bathroom / body weighing scale SVG
    const scaleIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" width="44" height="44">
      <!-- Platform base -->
      <rect x="6" y="46" width="52" height="10" rx="5" fill="#ef233c" opacity="0.9"/>
      <!-- Scale body -->
      <rect x="10" y="22" width="44" height="26" rx="8" fill="#1a1a2e" stroke="#ef233c" stroke-width="1.5"/>
      <!-- Display screen -->
      <rect x="18" y="27" width="28" height="12" rx="4" fill="#060709" stroke="rgba(239,35,60,0.4)" stroke-width="1"/>
      <!-- Weight readout bars -->
      <rect x="22" y="30" width="6" height="6" rx="1" fill="#ef233c" opacity="0.85"/>
      <rect x="30" y="30" width="6" height="6" rx="1" fill="#ef233c" opacity="0.65"/>
      <rect x="38" y="30" width="4" height="6" rx="1" fill="#ef233c" opacity="0.3"/>
      <!-- Feet/grip lines on platform -->
      <line x1="20" y1="49" x2="20" y2="53" stroke="rgba(255,255,255,0.2)" stroke-width="1.5" stroke-linecap="round"/>
      <line x1="32" y1="48" x2="32" y2="53" stroke="rgba(255,255,255,0.2)" stroke-width="1.5" stroke-linecap="round"/>
      <line x1="44" y1="49" x2="44" y2="53" stroke="rgba(255,255,255,0.2)" stroke-width="1.5" stroke-linecap="round"/>
      <!-- Top dial/button -->
      <circle cx="32" cy="16" r="5" fill="#1a1a2e" stroke="#ef233c" stroke-width="1.5"/>
      <circle cx="32" cy="16" r="2" fill="#ef233c" opacity="0.7"/>
      <line x1="32" y1="21" x2="32" y2="22" stroke="#ef233c" stroke-width="1.5"/>
    </svg>`;

    // Person + height ruler SVG
    const heightIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" width="44" height="44">
      <!-- Vertical ruler -->
      <rect x="44" y="4" width="12" height="56" rx="3" fill="#1a1a2e" stroke="#ef233c" stroke-width="1.5"/>
      <!-- Ruler tick marks -->
      <line x1="44" y1="12" x2="50" y2="12" stroke="#ef233c" stroke-width="1.2" opacity="0.9"/>
      <line x1="44" y1="20" x2="52" y2="20" stroke="#ef233c" stroke-width="1.5"/>
      <line x1="44" y1="28" x2="50" y2="28" stroke="#ef233c" stroke-width="1.2" opacity="0.9"/>
      <line x1="44" y1="36" x2="52" y2="36" stroke="#ef233c" stroke-width="1.5"/>
      <line x1="44" y1="44" x2="50" y2="44" stroke="#ef233c" stroke-width="1.2" opacity="0.9"/>
      <line x1="44" y1="52" x2="52" y2="52" stroke="#ef233c" stroke-width="1.5"/>
      <!-- Height arrow line from person head to ruler -->
      <line x1="38" y1="10" x2="44" y2="10" stroke="rgba(239,35,60,0.55)" stroke-width="1" stroke-dasharray="2,2"/>
      <!-- Person: head -->
      <circle cx="24" cy="10" r="5" fill="#ef233c" opacity="0.9"/>
      <!-- Person: body -->
      <line x1="24" y1="15" x2="24" y2="36" stroke="#e2e8f0" stroke-width="3" stroke-linecap="round"/>
      <!-- Person: arms -->
      <line x1="24" y1="22" x2="15" y2="30" stroke="#e2e8f0" stroke-width="2.5" stroke-linecap="round"/>
      <line x1="24" y1="22" x2="33" y2="28" stroke="#e2e8f0" stroke-width="2.5" stroke-linecap="round"/>
      <!-- Person: legs -->
      <line x1="24" y1="36" x2="16" y2="52" stroke="#e2e8f0" stroke-width="2.5" stroke-linecap="round"/>
      <line x1="24" y1="36" x2="32" y2="52" stroke="#e2e8f0" stroke-width="2.5" stroke-linecap="round"/>
      <!-- Ground line -->
      <line x1="8" y1="58" x2="56" y2="58" stroke="rgba(239,35,60,0.35)" stroke-width="1.5" stroke-linecap="round"/>
    </svg>`;

    return `<div class="ob-measurements">
      <div class="ob-measure-row">
        <div class="ob-measure-icon ob-measure-icon-svg">${scaleIcon}</div>
        <div class="ob-measure-field">
          <label class="ob-measure-label">Current Weight</label>
          <div class="ob-measure-input-wrap">
            <input type="number" class="ob-number-input" id="obWeight" value="${this.data.weight_kg}" min="30" max="300" step="0.5">
            <span class="ob-unit">kg</span>
          </div>
        </div>
      </div>
      <div class="ob-measure-row">
        <div class="ob-measure-icon ob-measure-icon-svg">${heightIcon}</div>
        <div class="ob-measure-field">
          <label class="ob-measure-label">Height</label>
          <div class="ob-measure-input-wrap">
            <input type="number" class="ob-number-input" id="obHeight" value="${this.data.height_cm}" min="100" max="250" step="1">
            <span class="ob-unit">cm</span>
          </div>
        </div>
      </div>
      <div class="ob-measure-row">
        <div class="ob-measure-icon">🎯</div>
        <div class="ob-measure-field">
          <label class="ob-measure-label">Goal Weight</label>
          <div class="ob-measure-input-wrap">
            <input type="number" class="ob-number-input" id="obGoalWeight" value="${this.data.goal_weight_kg}" min="30" max="300" step="0.5">
            <span class="ob-unit">kg</span>
          </div>
        </div>
      </div>
      <div class="ob-bmi-display" id="obBmiDisplay"></div>
    </div>`;
  },


  buildBodyShapeStep(type) {
    const field = type === 'current' ? 'current_body_shape' : 'goal_body_shape';
    const current = this.data[field];

    // Current body shape: all 5 options with SVG silhouettes
    const currentShapes = [
      { val: 'very_slim',  label: 'Very Slim',   desc: 'Very lean, low body fat',  svgPath: 'M50,20 C44,20 40,28 40,38 L38,75 L35,100 L45,100 L48,75 L52,75 L55,100 L65,100 L62,75 L60,38 C60,28 56,20 50,20 Z' },
      { val: 'slim',       label: 'Slim',         desc: 'Athletic, toned build',    svgPath: 'M50,20 C43,20 38,28 38,39 L35,75 L32,100 L44,100 L47,75 L53,75 L56,100 L68,100 L65,75 L62,39 C62,28 57,20 50,20 Z' },
      { val: 'average',    label: 'Average',      desc: 'Normal healthy weight',    svgPath: 'M50,20 C42,20 36,29 36,40 L32,76 L28,100 L43,100 L47,76 L53,76 L57,100 L72,100 L68,76 L64,40 C64,29 58,20 50,20 Z' },
      { val: 'overweight', label: 'Overweight',   desc: 'Carrying extra weight',    svgPath: 'M50,20 C40,20 33,30 33,42 L28,78 L23,100 L41,100 L46,78 L54,78 L59,100 L77,100 L72,78 L67,42 C67,30 60,20 50,20 Z' },
      { val: 'obese',      label: 'Heavy',        desc: 'Significantly overweight', svgPath: 'M50,20 C38,20 30,32 30,45 L24,80 L18,100 L39,100 L45,80 L55,80 L61,100 L82,100 L76,80 L70,45 C70,32 62,20 50,20 Z' }
    ];

    if (type !== 'goal') {
      return `<div class="ob-body-shapes">
        ${currentShapes.map(s => `
          <div class="ob-shape-card ${current === s.val ? 'selected' : ''}" data-field="${field}" data-value="${s.val}">
            <svg viewBox="0 0 100 110" class="ob-shape-svg">
              <circle cx="50" cy="12" r="9" fill="currentColor" opacity="0.9"/>
              <path d="${s.svgPath}" fill="currentColor"/>
            </svg>
            <div class="ob-shape-label">${s.label}</div>
            <div class="ob-shape-desc">${s.desc}</div>
          </div>
        `).join('')}
      </div>`;
    }

    // ── GOAL: gender-aware physique photos (Pexels CDN — stable, free) ──
    const isFemale = this.data.gender === 'female' || this.data.gender === 'non-binary';

    // Male photos: lean runner physique / athletic gym build / muscular physique
    const malePhotos = {
      lean:     'https://images.pexels.com/photos/1552106/pexels-photo-1552106.jpeg?auto=compress&cs=tinysrgb&w=300&h=400&fit=crop',
      athletic: 'https://images.pexels.com/photos/2294361/pexels-photo-2294361.jpeg?auto=compress&cs=tinysrgb&w=300&h=400&fit=crop',
      muscular: 'https://images.pexels.com/photos/1547248/pexels-photo-1547248.jpeg?auto=compress&cs=tinysrgb&w=300&h=400&fit=crop'
    };

    // Female photos — Unsplash keyword-based (guaranteed correct subject)
    const femalePhotos = {
      lean:     'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?fit=crop&w=300&h=400&q=85',
      athletic: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?fit=crop&w=300&h=400&q=85',
      muscular: 'https://images.unsplash.com/photo-1518310383802-640c2de311b2?fit=crop&w=300&h=400&q=85'
    };





    const photos = isFemale ? femalePhotos : malePhotos;

    const goalShapes = [
      { val: 'lean',     label: 'Lean',     desc: 'Cut & defined physique',   photo: photos.lean },
      { val: 'athletic', label: 'Athletic', desc: 'Balanced & fit build',     photo: photos.athletic },
      { val: 'muscular', label: 'Muscular', desc: 'Broad, powerful & strong', photo: photos.muscular }
    ];

    return `<div class="ob-body-shapes ob-body-shapes-centered ob-goal-photo-grid">
      ${goalShapes.map(s => `
        <div class="ob-shape-card ob-shape-photo-card ${current === s.val ? 'selected' : ''}" data-field="${field}" data-value="${s.val}">
          <div class="ob-shape-photo-wrap">
            <img src="${s.photo}" alt="${s.label}" class="ob-shape-photo" loading="lazy"
              onerror="this.parentElement.style.background='#1a1a2e'"/>
            <div class="ob-shape-photo-overlay"></div>
          </div>
          <div class="ob-shape-label">${s.label}</div>
          <div class="ob-shape-desc">${s.desc}</div>
          ${current === s.val ? '<div class="ob-shape-photo-check">✓</div>' : ''}
        </div>
      `).join('')}
    </div>`;
  },




  buildFrequencyStep() {

    const freqs = [
      { val: 'beginner',   emoji: '🌱', label: 'Beginner',   sub: '1-2 days per week',  badge: 'Just starting out' },
      { val: 'regular',    emoji: '🏃', label: 'Regular',    sub: '3-4 days per week',  badge: 'Consistent athlete' },
      { val: 'dedicated',  emoji: '🔥', label: 'Dedicated',  sub: '5-6 days per week',  badge: 'Serious lifter' },
      { val: 'elite',      emoji: '⚡', label: 'Elite',      sub: 'Every day',          badge: 'No rest days' }
    ];
    return `<div class="ob-card-grid ob-card-grid-2">
      ${freqs.map(f => `
        <div class="ob-card ob-card-freq ${this.data.workout_frequency === f.val ? 'selected' : ''}" data-field="workout_frequency" data-value="${f.val}">
          <div class="ob-card-emoji">${f.emoji}</div>
          <div class="ob-card-label">${f.label}</div>
          <div class="ob-card-sub">${f.sub}</div>
          <div class="ob-card-badge">${f.badge}</div>
        </div>
      `).join('')}
    </div>`;
  },

  buildRoleStep() {
    const roles = [
      { val: 'student',       emoji: '🎓', label: 'Student',           sub: 'Campus life, flexible schedule', img: '📚' },
      { val: 'physical_job',  emoji: '🏗️', label: 'Physical Job',      sub: 'Already active all day',         img: '🔨' },
      { val: 'desk_job',      emoji: '💻', label: 'Desk Job',           sub: 'Mostly seated, low daily steps',  img: '🖥️' },
      { val: 'stay_home',     emoji: '🏠', label: 'Stay at Home',       sub: 'Flexible but less structured',   img: '🏡' }
    ];
    return `<div class="ob-card-grid ob-card-grid-2">
      ${roles.map(r => `
        <div class="ob-card ob-card-role ${this.data.lifestyle_role === r.val ? 'selected' : ''}" data-field="lifestyle_role" data-value="${r.val}">
          <div class="ob-card-emoji">${r.emoji}</div>
          <div class="ob-card-label">${r.label}</div>
          <div class="ob-card-sub">${r.sub}</div>
        </div>
      `).join('')}
    </div>`;
  },

  bindStepInteractions(stepId) {
    // Card selections
    document.querySelectorAll('.ob-card[data-field]').forEach(card => {
      card.addEventListener('click', () => {
        const field = card.dataset.field;
        const value = card.dataset.value;
        this.data[field] = value;
        // Deselect siblings
        document.querySelectorAll(`.ob-card[data-field="${field}"]`).forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        card.classList.add('ob-card-pop');
        setTimeout(() => card.classList.remove('ob-card-pop'), 300);
      });
    });

    // Body shape cards
    document.querySelectorAll('.ob-shape-card[data-field]').forEach(card => {
      card.addEventListener('click', () => {
        const field = card.dataset.field;
        const value = card.dataset.value;
        this.data[field] = value;
        document.querySelectorAll(`.ob-shape-card[data-field="${field}"]`).forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });

    // Age slider
    if (stepId === 'age') {
      const slider  = document.getElementById('obAgeSlider');
      const display = document.getElementById('obAgeDisplay');
      if (slider) {
        slider.addEventListener('input', () => {
          this.data.age = parseInt(slider.value);
          if (display) display.textContent = slider.value;
          document.querySelectorAll('.ob-preset-btn').forEach(b => {
            b.classList.toggle('active', parseInt(b.dataset.age) === this.data.age);
          });
        });
      }
      document.querySelectorAll('.ob-preset-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          this.data.age = parseInt(btn.dataset.age);
          if (slider)  slider.value = this.data.age;
          if (display) display.textContent = this.data.age;
          document.querySelectorAll('.ob-preset-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
        });
      });
    }

    // Measurements inputs
    if (stepId === 'measurements') {
      const weightIn = document.getElementById('obWeight');
      const heightIn = document.getElementById('obHeight');
      const goalWtIn = document.getElementById('obGoalWeight');
      const bmiEl    = document.getElementById('obBmiDisplay');

      // ── BMI Body Visualizer ──────────────────────────────────────────
      // Each profile: body width multiplier, belly protrusion, hip width
      const BMI_PROFILES = {
        underweight: {
          label: 'Underweight', color: '#60a5fa', emoji: '🔵',
          desc: 'Below healthy range — build strength',
          // SVG body path for very thin person
          bodyW: 11, bellyX: 0, hipW: 14, neckW: 6, shoulderW: 22
        },
        normal: {
          label: 'Normal', color: '#22c55e', emoji: '🟢',
          desc: 'Healthy range — maintain your physique',
          bodyW: 14, bellyX: 0, hipW: 18, neckW: 7, shoulderW: 26
        },
        overweight: {
          label: 'Overweight', color: '#f59e0b', emoji: '🟡',
          desc: 'Above healthy range — time to cut',
          bodyW: 20, bellyX: 5, hipW: 26, neckW: 9, shoulderW: 30
        },
        obese: {
          label: 'Obese', color: '#ef4444', emoji: '🔴',
          desc: 'High health risk — start your journey',
          bodyW: 28, bellyX: 11, hipW: 34, neckW: 11, shoulderW: 34
        }
      };

      function getBmiProfile(bmi) {
        if (bmi < 18.5) return 'underweight';
        if (bmi < 25)   return 'normal';
        if (bmi < 30)   return 'overweight';
        return 'obese';
      }

      // Build smooth SVG body path from profile params
      function buildBodyPath(p) {
        const cx = 50; // center x
        const headY = 10, headR = 8;
        const neckTop = headY + headR;
        const neckBot = neckTop + 7;
        const shoulderY = neckBot + 2;
        const chestBot  = shoulderY + 18;
        const waistY    = chestBot + 6;
        const hipY      = waistY + 8;
        const legSplitY = hipY + 20;
        const footY     = legSplitY + 22;

        const sw  = p.shoulderW;   // shoulder half-width
        const bw  = p.bodyW;       // chest/torso half-width
        const bx  = p.bellyX;      // belly protrusion
        const hw  = p.hipW;        // hip half-width
        const nw  = p.neckW / 2;   // neck half-width
        const lw  = hw * 0.48;     // leg half-width

        return `
          M ${cx - nw} ${neckTop}
          C ${cx - nw} ${neckBot}  ${cx - sw} ${shoulderY}  ${cx - sw} ${shoulderY}
          C ${cx - bw - bx} ${chestBot}  ${cx - bw - bx} ${waistY}  ${cx - hw} ${hipY}
          L ${cx - lw} ${legSplitY}
          L ${cx - lw + 3} ${footY}
          L ${cx + lw - 3} ${footY}
          L ${cx + lw} ${legSplitY}
          L ${cx + hw} ${hipY}
          C ${cx + bw + bx} ${waistY}  ${cx + bw + bx} ${chestBot}  ${cx + sw} ${shoulderY}
          C ${cx + sw} ${shoulderY}  ${cx + nw} ${neckBot}  ${cx + nw} ${neckTop}
          Z
        `;
      }

      // Render the full BMI visualizer HTML
      function renderBMIVisualizer(bmi, profileKey) {
        const p = BMI_PROFILES[profileKey];
        const path = buildBodyPath(p);
        return `
          <div class="bmi-viz-wrap">
            <div class="bmi-viz-figure">
              <svg id="bmiBodySvg" viewBox="0 0 100 120" xmlns="http://www.w3.org/2000/svg" width="90" height="108">
                <!-- Subtle glow behind body -->
                <ellipse cx="50" cy="60" rx="${BMI_PROFILES[profileKey].hipW + 8}" ry="48"
                  fill="${p.color}" opacity="0.08"/>
                <!-- Body silhouette -->
                <path id="bmiBodyPath" d="${path}"
                  fill="${p.color}" opacity="0.88"
                  style="transition: d 0.5s cubic-bezier(0.34,1.56,0.64,1), fill 0.4s ease"/>
                <!-- Head -->
                <circle id="bmiHead" cx="50" cy="10" r="8"
                  fill="${p.color}" opacity="0.92"
                  style="transition: r 0.4s ease, fill 0.4s ease"/>
                <!-- Ground shadow -->
                <ellipse cx="50" cy="106" rx="${BMI_PROFILES[profileKey].hipW * 0.9}" ry="4"
                  fill="${p.color}" opacity="0.15"/>
              </svg>
            </div>
            <div class="bmi-viz-info">
              <div class="bmi-viz-number" style="color:${p.color}">BMI: ${bmi}</div>
              <div class="bmi-viz-badge" style="background:${p.color}22; border-color:${p.color}55; color:${p.color}">
                ${p.emoji} ${p.label}
              </div>
              <div class="bmi-viz-desc">${p.desc}</div>
            </div>
          </div>
        `;
      }

      // Live-update the visualizer smoothly
      function updateBMI() {
        const w = parseFloat(weightIn?.value) || 70;
        const h = parseFloat(heightIn?.value) || 170;
        this.data.weight_kg      = w;
        this.data.height_cm      = h;
        this.data.goal_weight_kg = parseFloat(goalWtIn?.value) || 65;
        const bmi = parseFloat((w / ((h / 100) ** 2)).toFixed(1));
        const profileKey = getBmiProfile(bmi);

        if (!bmiEl) return;

        // First render — inject full HTML
        if (!bmiEl.querySelector('.bmi-viz-wrap')) {
          bmiEl.innerHTML = renderBMIVisualizer(bmi, profileKey);
          return;
        }

        // Subsequent updates — morph SVG + update text in-place
        const p    = BMI_PROFILES[profileKey];
        const path = buildBodyPath(p);

        const bodyPath = bmiEl.querySelector('#bmiBodyPath');
        const headEl   = bmiEl.querySelector('#bmiHead');
        const numEl    = bmiEl.querySelector('.bmi-viz-number');
        const badgeEl  = bmiEl.querySelector('.bmi-viz-badge');
        const descEl   = bmiEl.querySelector('.bmi-viz-desc');

        if (bodyPath) { bodyPath.setAttribute('d', path); bodyPath.setAttribute('fill', p.color); }
        if (headEl)   { headEl.setAttribute('fill', p.color); }
        if (numEl)    { numEl.textContent = `BMI: ${bmi}`; numEl.style.color = p.color; }
        if (badgeEl)  {
          badgeEl.textContent = `${p.emoji} ${p.label}`;
          badgeEl.style.background   = `${p.color}22`;
          badgeEl.style.borderColor  = `${p.color}55`;
          badgeEl.style.color        = p.color;
        }
        if (descEl)   { descEl.textContent = p.desc; }
      }

      const boundUpdate = updateBMI.bind(this);
      if (weightIn) weightIn.addEventListener('input', boundUpdate);
      if (heightIn) heightIn.addEventListener('input', boundUpdate);
      if (goalWtIn) goalWtIn.addEventListener('input', () => { this.data.goal_weight_kg = parseFloat(goalWtIn.value) || 65; });
      boundUpdate();
    }
  },


  next() {
    // Validate required steps
    const step = this.steps[this.currentStep];
    const required = { gender: 'gender', goal: 'goal', frequency: 'workout_frequency', role: 'lifestyle_role' };
    if (required[step.id] && !this.data[required[step.id]]) {
      showToast('Please make a selection to continue!', 'error');
      // Shake the cards
      const body = document.getElementById('obStepBody');
      if (body) { body.classList.add('ob-shake'); setTimeout(() => body.classList.remove('ob-shake'), 500); }
      return;
    }

    // Collect measurements before leaving that step
    if (step.id === 'measurements') {
      const w = document.getElementById('obWeight');
      const h = document.getElementById('obHeight');
      const g = document.getElementById('obGoalWeight');
      if (w) this.data.weight_kg      = parseFloat(w.value) || 70;
      if (h) this.data.height_cm      = parseFloat(h.value) || 170;
      if (g) this.data.goal_weight_kg = parseFloat(g.value) || 65;
    }

    if (this.currentStep < this.totalSteps - 1) {
      this.renderStep(this.currentStep + 1, 'right');
    } else {
      this.submit();
    }
  },

  back() {
    if (this.currentStep > 0) {
      this.renderStep(this.currentStep - 1, 'left');
    }
  },

  skip() {
    if (this.currentStep < this.totalSteps - 1) {
      this.renderStep(this.currentStep + 1, 'right');
    } else {
      this.submit();
    }
  },

  async submit() {
    const nextBtn = document.getElementById('obNextBtn');
    if (nextBtn) { nextBtn.textContent = 'Saving...'; nextBtn.disabled = true; }

    try {
      await API.saveOnboarding(this.data);
    } catch(e) {
      console.warn('Onboarding save failed silently:', e);
    }

    // Animate finish
    const wizard = document.getElementById('onboardingWizard');
    if (wizard) {
      wizard.classList.add('ob-finish-flash');
      setTimeout(() => {
        wizard.style.display = 'none';
        wizard.classList.remove('ob-finish-flash');
        const mainApp = document.getElementById('mainAppView');
        if (mainApp) mainApp.style.display = 'block';
        if (window.Auth && Auth.currentUser) Auth.updateNavUI(Auth.currentUser);
        if (window.App) App.loadAllData();
        showToast("🔥 Profile set! Time to CONQUER.", 'success');
      }, 600);
    }
  }
};

window.Onboarding = Onboarding;
